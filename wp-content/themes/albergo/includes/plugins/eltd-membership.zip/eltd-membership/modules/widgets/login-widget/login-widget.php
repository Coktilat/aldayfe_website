<?php

class ElatedMembershipLoginRegister extends WP_Widget {

	public function __construct() {
		parent::__construct(
			'eltd_login_register_widget',
			esc_html__( 'Elated Login Widget', 'eltd-membership' ),
			array( 'description' => esc_html__( 'Login and register membership widget', 'eltd-membership' ) )
		);
	}
	
	public function widget( $args, $instance ) {
		$additional_class = is_user_logged_in() ? 'eltd-user-logged-in' : 'eltd-user-not-logged-in';
		
		echo '<div class="widget eltd-login-register-widget ' . esc_attr( $additional_class ) . '">';
        if ( ! is_user_logged_in() ) {
            echo eltd_membership_get_module_template_part( 'widgets', 'login-widget', 'login-widget-template', 'logged-out' );
        } else {
            echo eltd_membership_get_module_template_part( 'widgets', 'login-widget', 'login-widget-template', 'logged-in' );
        }
		echo '</div>';
	}
}

if ( ! function_exists( 'eltd_membership_login_widget_load' ) ) {
	function eltd_membership_login_widget_load() {
		register_widget( 'ElatedMembershipLoginRegister' );
	}
	
	add_action( 'widgets_init', 'eltd_membership_login_widget_load' );
}

