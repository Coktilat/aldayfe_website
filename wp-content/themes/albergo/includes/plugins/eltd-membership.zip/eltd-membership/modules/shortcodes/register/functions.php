<?php

if ( ! function_exists( 'eltd_membership_add_register_shortcodes' ) ) {
	function eltd_membership_add_register_shortcodes( $shortcodes_class_name ) {
		$shortcodes = array(
			'ElatedMembership\Shortcodes\ElatedUserRegister\ElatedUserRegister'
		);
		
		$shortcodes_class_name = array_merge( $shortcodes_class_name, $shortcodes );
		
		return $shortcodes_class_name;
	}
	
	add_filter( 'eltd_membership_filter_add_vc_shortcode', 'eltd_membership_add_register_shortcodes' );
}