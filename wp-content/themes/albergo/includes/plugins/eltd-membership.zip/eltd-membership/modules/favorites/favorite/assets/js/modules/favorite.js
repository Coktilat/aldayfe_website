(function($) {
    'use strict';

    var membershipFavorites = {};
    eltd.modules.membershipFavorites = membershipFavorites;

    membershipFavorites.eltdOnDocumentReady = eltdOnDocumentReady;

    $(document).ready(eltdOnDocumentReady);
    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function eltdOnDocumentReady() {
        eltdMembershipAddToWishlist();
        eltdMembershipAddToWishlistTriggerEvent();
    }

    function eltdMembershipAddToWishlist(){

        $('.eltd-membership-item-favorites').on('click',function(e) {
            e.preventDefault();
            var item = $(this),
                itemID;

            if(typeof item.data('item-id') !== 'undefined') {
                itemID = item.data('item-id');
            }

            eltdMembershipWhishlistAdding(item, itemID);

        });

    }

    function eltdMembershipWhishlistAdding(item, itemID){

        var ajaxData = {
            action: 'eltd_membership_add_item_to_favorites',
            item_id : itemID
        };

        $.ajax({
            type: 'POST',
            data: ajaxData,
            url: eltdGlobalVars.vars.eltdAjaxUrl,
            success: function (data) {
                var response = JSON.parse(data);
                if(response.status == 'success'){
                    if(!item.hasClass('eltd-icon-only')) {
                        item.find('span').text(response.data.message);
                    }
                    item.find('.eltd-favorites-icon').removeClass('fa-heart fa-heart-o').addClass(response.data.icon);
                }
            }
        });

        return false;

    }

    function eltdMembershipAddToWishlistTriggerEvent() {
        $( document.body ).on( 'eltd_membership_favorites_trigger', function() {
            eltdMembershipAddToWishlist();
        });
    }


})(jQuery);