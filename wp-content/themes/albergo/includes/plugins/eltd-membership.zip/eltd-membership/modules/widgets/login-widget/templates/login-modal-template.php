<div class="eltd-login-register-holder">
	<div class="eltd-login-register-content">
		<ul>
			<li><a href="#eltd-login-content"><?php esc_html_e( 'Login', 'eltd-membership' ); ?></a></li>
			<li><a href="#eltd-register-content"><?php esc_html_e( 'Register', 'eltd-membership' ); ?></a></li>
		</ul>
		<div class="eltd-login-content-inner" id="eltd-login-content">
			<div class="eltd-wp-login-holder"><?php echo eltd_membership_execute_shortcode( 'eltd_user_login', array() ); ?></div>
		</div>
		<div class="eltd-register-content-inner" id="eltd-register-content">
			<div class="eltd-wp-register-holder"><?php echo eltd_membership_execute_shortcode( 'eltd_user_register', array() ) ?></div>
		</div>
	</div>
</div>