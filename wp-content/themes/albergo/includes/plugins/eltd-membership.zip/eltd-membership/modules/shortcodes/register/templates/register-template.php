<div class="eltd-social-register-holder">
	<form method="post" class="eltd-register-form">
		<fieldset>
			<div>
				<input type="text" name="user_register_name" id="user_register_name" placeholder="<?php esc_attr_e( 'User Name', 'eltd-membership' ) ?>" value="" required
				       pattern=".{3,}" title="<?php esc_attr_e( 'Three or more characters', 'eltd-membership' ); ?>"/>
			</div>
			<div>
				<input type="email" name="user_register_email" id="user_register_email" placeholder="<?php esc_attr_e( 'Email', 'eltd-membership' ) ?>" value="" required />
			</div>
            <div>
                <input type="password" name="user_register_password" id="user_register_password" placeholder="<?php esc_attr_e('Password','eltd-membership') ?>" value="" required />
            </div>
            <div>
                <input type="password" name="user_register_confirm_password" id="user_register_confirm_password" placeholder="<?php esc_attr_e('Repeat Password','eltd-membership') ?>" value="" required />
            </div>
            <?php do_action('eltd_membership_additional_registration_field'); ?>
			<div class="eltd-register-button-holder">
				<?php
				if ( eltd_membership_theme_installed() ) {
					echo albergo_elated_get_button_html( array(
						'html_type' => 'button',
						'text'      => esc_html__( 'Register', 'eltd-membership' ),
						'type'      => 'solid',
						'size'      => 'small'
					) );
				} else {
					echo '<button type="submit">' . esc_html__( 'Register', 'eltd-membership' ) . '</button>';
				}
				wp_nonce_field( 'eltd-ajax-register-nonce', 'eltd-register-security' ); ?>
			</div>
		</fieldset>
	</form>
	<?php do_action( 'eltd_membership_action_login_ajax_response' ); ?>
</div>