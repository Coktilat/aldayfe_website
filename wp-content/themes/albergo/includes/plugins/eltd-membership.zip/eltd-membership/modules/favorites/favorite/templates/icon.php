<a href="javascript:void(0)" class="eltd-membership-item-favorites eltd-icon-only" data-item-id="<?php echo esc_attr($item_id); ?>">
    <i class="eltd-favorites-icon fa <?php echo esc_attr($icon); ?>" aria-hidden="true"></i>
</a>