<a href="javascript:void(0)" class="eltd-membership-item-favorites" data-item-id="<?php echo esc_attr($item_id); ?>">
    <i class="eltd-favorites-icon fa <?php echo esc_attr( $icon ); ?>"></i>
    <span class="eltd-favorites-text">
        <?php echo esc_attr( $favorites_text ); ?>
    </span>
</a>
