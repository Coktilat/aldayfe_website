<div class="eltd-logged-out-user">
    <div class="eltd-logged-out-user-inner">
        <a href="#" class="eltd-login-opener">
            <span class="eltd-login-text"><?php esc_html_e( 'Login / Register', 'eltd-membership' ); ?></span>
        </a>
    </div>
</div>