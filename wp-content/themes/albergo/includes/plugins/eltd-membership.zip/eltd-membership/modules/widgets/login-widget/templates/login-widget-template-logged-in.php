<?php
$current_user    = wp_get_current_user();
$name            = $current_user->display_name;
$current_user_id = $current_user->ID;
?>
<div class="eltd-logged-in-user">
    <div class="eltd-logged-in-user-inner">
        <span>
            <?php if ( eltd_membership_theme_installed() ) {
                $profile_image = get_user_meta( $current_user_id, 'social_profile_image', true );
                if ( $profile_image == '' ) {
                    $profile_image = get_avatar( $current_user_id, 28 );
                } else {
                    $profile_image = '<img src="' . esc_url( $profile_image ) . '" />';
                }
                echo eltd_membership_kses_img( $profile_image );
            } ?>
            <span class="eltd-logged-in-user-name"><?php echo esc_html( $name ); ?></span>
            <?php if ( eltd_membership_theme_installed() ) {
                echo albergo_elated_icon_collections()->renderIcon( 'icon-arrows-down', 'font_elegant' );
            } ?>
        </span>
    </div>
</div>
<ul class="eltd-login-dropdown">
	<?php
	$nav_items = eltd_membership_get_dashboard_navigation_items();
    $logout_url = home_url( '/' );
	foreach ( $nav_items as $nav_item ) { ?>
		<li>
			<a href="<?php echo $nav_item['url']; ?>">
				<span><?php echo $nav_item['text']; ?></span>
			</a>
		</li>
	<?php } ?>
	<li>
		<a href="<?php echo wp_logout_url( $logout_url ); ?>">
            <span><?php esc_html_e( 'Log Out', 'eltd-membership' ); ?></span>
		</a>
	</li>
</ul>