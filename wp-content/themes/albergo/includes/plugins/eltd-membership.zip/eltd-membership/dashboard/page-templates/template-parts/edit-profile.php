<?php 

if ( !function_exists('eltd_membership_dashboard_edit_profile_fields') ) {
	function eltd_membership_dashboard_edit_profile_fields($params){

		extract($params);

		$edit_profile = albergo_elated_add_dashboard_fields(array(
			'name' => 'edit_profile',
		));

		$edit_profile_form = albergo_elated_add_dashboard_form(array(
			'name' => 'edit_profile_form',
			'form_id'   => 'eltd-membership-update-profile-form',
			'form_action' => 'eltd_membership_update_user_profile',
			'parent' => $edit_profile,
			'button_label' => esc_html__('UPDATE PROFILE','eltd-membership'),
			'button_args' => array(
				'data-updating-text' => esc_html__('UPDATING PROFILE', 'eltd-membership'),
				'data-updated-text' => esc_html__('PROFILE UPDATED', 'eltd-membership'),
			)
		));

		$edit_profile_name_group = albergo_elated_add_dashboard_group(array(
			'name' => 'edit_profile_name_group',
			'parent' => $edit_profile_form,
		));

		albergo_elated_add_dashboard_field(array(
			'type' => 'text',
			'name' => 'first_name',
			'label' => esc_html__('First Name','eltd-membership'),
			'parent' => $edit_profile_name_group,
			'value' => $first_name
		));
		
		albergo_elated_add_dashboard_field(array(
			'type' => 'text',
			'name' => 'last_name',
			'label' => esc_html__('Last Name','eltd-membership'),
			'parent' => $edit_profile_name_group,
			'value' => $last_name
		));

		albergo_elated_add_dashboard_field(array(
			'type' => 'text',
			'name' => 'email',
			'label' => esc_html__('Email','eltd-membership'),
			'parent' => $edit_profile_form,
			'value' => $email,
			'args' => array(
				'input_type' => 'email'
			)
		));

		albergo_elated_add_dashboard_field(array(
			'type' => 'text',
			'name' => 'url',
			'label' => esc_html__('Website','eltd-membership'),
			'parent' => $edit_profile_form,
			'value' => $website
		));

		albergo_elated_add_dashboard_field(array(
			'type' => 'text',
			'name' => 'description',
			'label' => esc_html__('Description','eltd-membership'),
			'parent' => $edit_profile_form,
			'value' => $description
		));

		albergo_elated_add_dashboard_field(array(
			'type' => 'text',
			'name' => 'password',
			'label' => esc_html__('Password','eltd-membership'),
			'parent' => $edit_profile_form,
			'args' => array(
				'input_type' => 'password'
			)
		));

		albergo_elated_add_dashboard_field(array(
			'type' => 'text',
			'name' => 'password2',
			'label' => esc_html__('Repeat Password','eltd-membership'),
			'parent' => $edit_profile_form,
			'args' => array(
				'input_type' => 'password'
			)
		));

		$edit_profile->render();
	}
}
?>

<div class="eltd-membership-dashboard-page">
	<div>
		<?php eltd_membership_dashboard_edit_profile_fields($params); ?>
		<?php do_action( 'eltd_membership_action_login_ajax_response' ); ?>
	</div>
</div>