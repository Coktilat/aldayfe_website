<?php

get_header();

albergo_elated_get_title();

do_action('albergo_elated_before_main_content');

eltd_core_get_single_team();

get_footer();