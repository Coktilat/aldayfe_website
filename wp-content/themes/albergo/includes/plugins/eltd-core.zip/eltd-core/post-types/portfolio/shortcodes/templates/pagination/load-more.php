<?php if($query_results->max_num_pages > 1) {
	$holder_styles = $this_object->getLoadMoreStyles($params);
	?>
	<div class="eltd-pl-loading">
		<div class="eltd-pl-loading-bounce1"></div>
		<div class="eltd-pl-loading-bounce2"></div>
		<div class="eltd-pl-loading-bounce3"></div>
	</div>
	<div class="eltd-pl-load-more-holder">
		<div class="eltd-pl-load-more" <?php albergo_elated_inline_style($holder_styles); ?>>
			<?php 
				echo albergo_elated_get_button_html(array(
					'link' => 'javascript: void(0)',
					'size' => 'large',
					'text' => esc_html__('LOAD MORE', 'eltd-core')
				));
			?>
		</div>
	</div>
<?php }