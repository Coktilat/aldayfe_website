<div class="eltd-testimonial-content" id="eltd-testimonials-<?php echo esc_attr( $current_id ) ?>">
	<div class="eltd-testimonial-text-holder">
		<?php if ( ! empty( $title ) ) { ?>
			<h2 itemprop="name" class="eltd-testimonial-title entry-title"><?php echo esc_html( $title ); ?></h2>
		<?php } ?>
		<?php if ( ! empty( $text ) ) { ?>
			<p class="eltd-testimonial-text"><?php echo esc_html( $text ); ?></p>
		<?php } ?>
		<?php if ( has_post_thumbnail() ) { ?>
			<div class="eltd-testimonial-image">
				<?php echo get_the_post_thumbnail( get_the_ID(), array( 66, 66 ) ); ?>
			</div>
		<?php } ?>
		<?php if ( ! empty( $author ) ) { ?>
			<h4 class="eltd-testimonial-author">
				<span class="eltd-testimonials-author-name"><?php echo esc_html( $author ); ?></span>
			</h4>
		<?php } ?>
		<?php if ( ! empty( $position ) ) { ?>
			<h5 class="eltd-testimonials-author-job"><?php echo esc_html( $position ); ?></h5>
		<?php } ?>
	</div>
</div>