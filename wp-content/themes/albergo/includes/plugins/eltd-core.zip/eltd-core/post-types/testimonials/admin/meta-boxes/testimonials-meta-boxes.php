<?php

if ( ! function_exists( 'eltd_core_map_testimonials_meta' ) ) {
	function eltd_core_map_testimonials_meta() {
		$testimonial_meta_box = albergo_elated_add_meta_box(
			array(
				'scope' => array( 'testimonials' ),
				'title' => esc_html__( 'Testimonial', 'eltd-core' ),
				'name'  => 'testimonial_meta'
			)
		);
		
		albergo_elated_add_meta_box_field(
			array(
				'name'        => 'eltd_testimonial_title',
				'type'        => 'text',
				'label'       => esc_html__( 'Title', 'eltd-core' ),
				'description' => esc_html__( 'Enter testimonial title', 'eltd-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		albergo_elated_add_meta_box_field(
			array(
				'name'        => 'eltd_testimonial_text',
				'type'        => 'text',
				'label'       => esc_html__( 'Text', 'eltd-core' ),
				'description' => esc_html__( 'Enter testimonial text', 'eltd-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		albergo_elated_add_meta_box_field(
			array(
				'name'        => 'eltd_testimonial_author',
				'type'        => 'text',
				'label'       => esc_html__( 'Author', 'eltd-core' ),
				'description' => esc_html__( 'Enter author name', 'eltd-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
		
		albergo_elated_add_meta_box_field(
			array(
				'name'        => 'eltd_testimonial_author_position',
				'type'        => 'text',
				'label'       => esc_html__( 'Author Position', 'eltd-core' ),
				'description' => esc_html__( 'Enter author job position', 'eltd-core' ),
				'parent'      => $testimonial_meta_box,
			)
		);
	}
	
	add_action( 'albergo_elated_meta_boxes_map', 'eltd_core_map_testimonials_meta', 95 );
}