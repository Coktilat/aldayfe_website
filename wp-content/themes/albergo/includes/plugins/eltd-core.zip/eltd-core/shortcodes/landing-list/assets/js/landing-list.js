(function($) {
    'use strict';
	
	var landingList = {};
	eltd.modules.landingList = landingList;
	
	landingList.eltdLandingListAppear = eltdLandingListAppear;
	
	
	landingList.eltdOnWindowLoad = eltdOnWindowLoad;
	
	$(window).load(eltdOnWindowLoad);
	
	/*
	 ** All functions to be called on $(window).load() should be in this function
	 */
	function eltdOnWindowLoad() {
		eltdLandingListAppear();
	}
	
	/*
	 ** Init Image Gallery shortcode - Masonry layout
	 */
	function eltdLandingListAppear(){
		var item = $('.eltd-landing-item');
		
		if(item.length){
			item.each(function(){
				var thisItem = $(this);

				thisItem.appear(function() {

					thisItem.addClass('eltd-appear');

				},{accX: 0, accY: eltdGlobalVars.vars.eltdElementAppearAmount});
			
			});
		}
	}

})(jQuery);