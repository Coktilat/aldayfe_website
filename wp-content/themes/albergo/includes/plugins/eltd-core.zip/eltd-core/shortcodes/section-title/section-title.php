<?php
namespace ElatedCore\CPT\Shortcodes\SectionTitle;

use ElatedCore\Lib;

class SectionTitle implements Lib\ShortcodeInterface {
	private $base; 
	
	function __construct() {
		$this->base = 'eltd_section_title';

		add_action('vc_before_init', array($this, 'vcMap'));
	}
	
	/**
	* Returns base for shortcode
	* @return string
	 */
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if(function_exists('vc_map')) {
			vc_map(
				array(
					'name'                      => esc_html__( 'Elated Section Title', 'eltd-core' ),
					'base'                      => $this->base,
					'category'                  => esc_html__( 'by ELATED', 'eltd-core' ),
					'icon'                      => 'icon-wpb-section-title extended-custom-icon',
					'allowed_container_element' => 'vc_row',
					'params'                    => array(
						array(
							'type'        => 'dropdown',
							'param_name'  => 'position',
							'heading'     => esc_html__( 'Horizontal Position', 'eltd-core' ),
							'value'       => array(
								esc_html__( 'Default', 'eltd-core' ) => '',
								esc_html__( 'Left', 'eltd-core' )    => 'left',
								esc_html__( 'Center', 'eltd-core' )  => 'center',
								esc_html__( 'Right', 'eltd-core' )   => 'right'
							),
							'save_always' => true
						),
						array(
							'type'       => 'textfield',
							'param_name' => 'holder_padding_left',
							'heading'    => esc_html__( 'Holder Left Padding (px or %)', 'eltd-core' )
						),
						array(
							'type'       => 'textfield',
							'param_name' => 'holder_padding_right',
							'heading'    => esc_html__( 'Holder Right Padding (px or %)', 'eltd-core' )
						),
						array(
							'type'        => 'textfield',
							'param_name'  => 'title',
							'heading'     => esc_html__( 'Title', 'eltd-core' ),
							'admin_label' => true
						),
						array(
							'type'        => 'textfield',
							'param_name'  => 'title_before',
							'heading'     => esc_html__( 'Text Before Title', 'eltd-core' ),
							'admin_label' => true,
							'dependency'  => array( 'element' => 'title', 'not_empty' => true )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'title_tag',
							'heading'     => esc_html__( 'Title Tag', 'eltd-core' ),
							'value'       => array_flip( albergo_elated_get_title_tag( true ) ),
							'save_always' => true,
							'dependency'  => array( 'element' => 'title', 'not_empty' => true )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'title_transform',
							'heading'     => esc_html__( 'Title Transform', 'eltd-core' ),
							'value'       => array_flip( albergo_elated_get_text_transform_array( true ) ),
							'dependency'  => array( 'element' => 'title', 'not_empty' => true )
						),
						array(
							'type'       => 'colorpicker',
							'param_name' => 'title_color',
							'heading'    => esc_html__( 'Title Color', 'eltd-core' ),
							'dependency' => array( 'element' => 'title', 'not_empty' => true )
						),
						array(
							'type'       => 'textfield',
							'param_name' => 'title_margin_top',
							'heading'    => esc_html__( 'Title Top Margin (px)', 'eltd-core' ),
							'dependency' => array( 'element' => 'title', 'not_empty' => true )
						),
						array(
							'type'       => 'textfield',
							'param_name' => 'title_margin_bottom',
							'heading'    => esc_html__( 'Title Bottom Margin (px)', 'eltd-core' ),
							'dependency' => array( 'element' => 'title', 'not_empty' => true )
						),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'subtitle',
                            'heading'     => esc_html__( 'Subtitle', 'eltd-core' ),
                            'admin_label' => true
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'subtitle_tag',
                            'heading'     => esc_html__( 'Subtitle Tag', 'eltd-core' ),
                            'value'       => array_flip( albergo_elated_get_title_tag( true ) ),
                            'save_always' => true,
                            'dependency'  => array( 'element' => 'subtitle', 'not_empty' => true )
                        ),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'subtitle_transform',
							'heading'     => esc_html__( 'SubTitle Transform', 'eltd-core' ),
							'value'       => array_flip( albergo_elated_get_text_transform_array( true ) ),
							'dependency'  => array( 'element' => 'subtitle', 'not_empty' => true )
						),
                        array(
                            'type'       => 'colorpicker',
                            'param_name' => 'subtitle_color',
                            'heading'    => esc_html__( 'Subtitle Color', 'eltd-core' ),
                            'dependency' => array( 'element' => 'subtitle', 'not_empty' => true )
                        ),
						array(
							'type'       => 'textarea',
							'param_name' => 'text',
							'heading'    => esc_html__( 'Text', 'eltd-core' )
						),
						array(
							'type'       => 'colorpicker',
							'param_name' => 'text_color',
							'heading'    => esc_html__( 'Text Color', 'eltd-core' ),
							'dependency' => array( 'element' => 'text', 'not_empty' => true )
						),
						array(
							'type'       => 'textfield',
							'param_name' => 'text_font_size',
							'heading'    => esc_html__( 'Text Font Size (px)', 'eltd-core' ),
							'dependency' => array( 'element' => 'text', 'not_empty' => true )
						),
						array(
							'type'       => 'textfield',
							'param_name' => 'text_line_height',
							'heading'    => esc_html__( 'Text Line Height (px)', 'eltd-core' ),
							'dependency' => array( 'element' => 'text', 'not_empty' => true )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'text_font_weight',
							'heading'     => esc_html__( 'Text Font Weight', 'eltd-core' ),
							'value'       => array_flip( albergo_elated_get_font_weight_array( true ) ),
							'save_always' => true,
							'dependency' => array( 'element' => 'text', 'not_empty' => true )
						),
						array(
							'type'       => 'textfield',
							'param_name' => 'text_margin',
							'heading'    => esc_html__( 'Text Margin', 'eltd-core' ),
							'description' => esc_html__( 'Insert margin in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'eltd-core' ),
							'dependency' => array( 'element' => 'text', 'not_empty' => true )
						),
						array(
							'type'       => 'textarea',
							'param_name' => 'text_price',
							'heading'    => esc_html__( 'Price', 'eltd-core' )
						),
						array(
							'type'       => 'colorpicker',
							'param_name' => 'text_price_color',
							'heading'    => esc_html__( 'Price Color', 'eltd-core' ),
							'dependency' => array( 'element' => 'text_price', 'not_empty' => true )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'separator',
							'heading'    => esc_html__( 'Enable Separator', 'eltd-core' ),
							'value'      => array_flip(albergo_elated_get_yes_no_select_array(false, false)),
							'save_always' => true
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'separator_skin',
							'heading'     => esc_html__( 'Separator Skin Color', 'eltd-core' ),
							'value'       => array(
								esc_html__( 'Main Color', 'eltd-core' )            => '',
								esc_html__( 'Inherit From Title', 'eltd-core' )    => 'inherit'
							),
							'dependency'  => array( 'element' => 'separator', 'value' => array('yes') ),
							'save_always' => true,
							'admin_label' => true
						)
					)
				)
			);
		}
	}

	public function render($atts, $content = null) {
		$args = array(
			'position'                    => '',
			'holder_padding_left'         => '',
			'holder_padding_right'        => '',
			'title'                       => '',
			'title_before'                => '',
			'title_tag'                   => 'h2',
			'title_transform'             => '',
			'title_color'                 => '',
			'title_margin_top'            => '',
			'title_margin_bottom'         => '',
            'subtitle'                    => '',
            'subtitle_tag'                => 'h6',
            'subtitle_transform'          => '',
            'subtitle_color'              => '',
			'text'                        => '',
			'text_color'                  => '',
			'text_font_size'              => '',
			'text_line_height'            => '',
			'text_font_weight'            => '',
			'text_margin'                 => '',
			'text_price'                  => '',
			'text_price_color'            => '',
			'separator'                   => 'no',
			'separator_skin'              => ''
        );
		$params = shortcode_atts($args, $atts);

		$params['holder_class']     = $this->getHolderClasses($params);
		$params['holder_styles']    = $this->getHolderStyles($params);
		$params['title_tag']        = !empty($params['title_tag']) ? $params['title_tag'] : $args['title_tag'];
		$params['title_styles']     = $this->getTitleStyles($params);
		$params['subtitle_tag']     = !empty($params['subtitle_tag']) ? $params['subtitle_tag'] : $args['subtitle_tag'];
		$params['subtitle_styles']  = $this->getSubtitleStyles($params);
		$params['text_styles']      = $this->getTextStyles($params);
		$params['price_styles']     = $this->getPriceStyles($params);
		$params['title_align']      = $params['position'] ? 'eltd-title-'.$params['position'] : '';

		$params['currency'] = '$'; // default currency if woocommerce is not installed
		if ( albergo_elated_is_woocommerce_installed() ) {
			$params['currency'] = get_woocommerce_currency_symbol( get_woocommerce_currency() );
		}


		$html = eltd_core_get_shortcode_module_template_part('templates/section-title', 'section-title', '', $params);
		
		return $html;
	}

	private function getHolderClasses($params) {
		$classes = array();

		$classes[] = $params['separator'] === 'no' ? 'eltd-separator-disabled' : '';
		$classes[] = !empty($params['separator_skin']) ? 'eltd-separator-inherit-color' : '';
		$classes[] = !empty($params['position']) ? 'eltd-st-text-position-'.$params['position'] : '';

		return implode(' ', $classes);
	}
	
	private function getHolderStyles($params) {
		$styles = array();
		
		if (!empty($params['holder_padding_left'])) {
			$styles[] = 'padding-left: '.$params['holder_padding_left'];
		}

		if (!empty($params['holder_padding_right'])) {
			$styles[] = 'padding-right: '.$params['holder_padding_right'];
		}
		
		if (!empty($params['position'])) {
			$styles[] = 'text-align: '.$params['position'];
		}
		
		return implode(';', $styles);
	}
	
	private function getTitleStyles($params) {
		$styles = array();

		if (!empty($params['title_color'])) {
			$styles[] = 'color: '.$params['title_color'];
		}

		if (!empty($params['title_transform'])) {
			$styles[] = 'text-transform: '.$params['title_transform'];
		}

		if (!empty($params['title_margin_top'])) {
			$styles[] = 'margin-top: '.albergo_elated_filter_px($params['title_margin_top']).'px';
		}

		if (!empty($params['title_margin_bottom'])) {
			$styles[] = 'margin-bottom: '.albergo_elated_filter_px($params['title_margin_bottom']).'px';
		}
		
		return implode(';', $styles);
	}

	private function getSubtitleStyles($params) {
		$styles = array();

		if (!empty($params['subtitle_color'])) {
			$styles[] = 'color: '.$params['subtitle_color'];
		}

		if (!empty($params['subtitle_transform'])) {
			$styles[] = 'text-transform: '.$params['subtitle_transform'];
		}

		return implode(';', $styles);
	}

	private function getTextStyles($params) {
		$styles = array();
		
		if (!empty($params['text_color'])) {
			$styles[] = 'color: '.$params['text_color'];
		}
		
		if (!empty($params['text_font_size'])) {
			$styles[] = 'font-size: '.albergo_elated_filter_px($params['text_font_size']).'px';
		}
		
		if (!empty($params['text_line_height'])) {
			$styles[] = 'line-height: '.albergo_elated_filter_px($params['text_line_height']).'px';
		}
		
		if (!empty($params['text_font_weight'])) {
			$styles[] = 'font-weight: '.$params['text_font_weight'];
		}

		if (!empty($params['text_margin'])) {
			$styles[] = 'margin: ' . $params['text_margin'];
		}


		return implode(';', $styles);
	}

	private function getPriceStyles($params) {
		$styles = array();

		if (!empty($params['text_price_color'])) {
			$styles[] = 'color: '.$params['text_price_color'];
		}

		return implode(';', $styles);
	}

}