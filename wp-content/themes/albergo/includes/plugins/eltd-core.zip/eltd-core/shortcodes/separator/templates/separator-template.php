<div class="eltd-separator-holder clearfix <?php echo esc_attr($holder_classes); ?>">
	<div class="eltd-separator" <?php echo albergo_elated_get_inline_style($holder_styles); ?>></div>
</div>
