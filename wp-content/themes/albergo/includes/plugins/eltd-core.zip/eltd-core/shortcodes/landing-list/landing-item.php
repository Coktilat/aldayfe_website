<?php

namespace ElatedCore\CPT\Shortcodes\LandingItem;

use ElatedCore\Lib;

class LandingItem implements Lib\ShortcodeInterface {
	private $base;

	function __construct() {
		$this->base = 'eltd_landing_item';
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}

	public function getBase() {
		return $this->base;
	}

	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map( array(
					"name"                      => esc_html__( 'Elated Landing Item', 'eltd-core' ),
					"base"                      => $this->base,
					"icon"                      => "icon-wpb-landing-item extended-custom-icon",
					"category"                  => esc_html__( 'by ELATED', 'eltd-core' ),
					'allowed_container_element' => 'vc_row',
					"as_child"                  => array( 'only' => 'eltd_landing_list' ),
					"params"                    => array(
						array(
							'type'        => 'textfield',
							'param_name'  => 'title',
							'heading'     => esc_html__( 'Title', 'eltd-core' ),
							'description' => esc_html__( 'Enter title', 'eltd-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'title_tag',
							'heading'    => esc_html__( 'Title Tag', 'eltd-core' ),
							'value'      => array_flip( albergo_elated_get_title_tag( true, array( 'p' => 'p' ) ) ),
							'dependency' => array( 'element' => 'title', 'not_empty' => true )
						),
						array(
							'type'        => 'textfield',
							'param_name'  => 'subtitle',
							'heading'     => esc_html__( 'Text', 'eltd-core' ),
							'description' => esc_html__( 'Enter text', 'eltd-core' )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'subtitle_tag',
							'heading'    => esc_html__( 'Text Tag', 'eltd-core' ),
							'value'      => array_flip( albergo_elated_get_title_tag( true, array( 'p' => 'p' ) ) ),
							'dependency' => array( 'element' => 'subtitle', 'not_empty' => true )
						),
						array(
							'type'        => 'attach_image',
							'param_name'  => 'image',
							'heading'     => esc_html__( 'Image', 'eltd-core' ),
							'description' => esc_html__( 'Select image from media library', 'eltd-core' )
						),
						array(
							'type'        => 'textfield',
							'param_name'  => 'image_size',
							'heading'     => esc_html__( 'Image Size', 'eltd-core' ),
							'description' => esc_html__( 'Enter image size. Example: thumbnail, medium, large, full 
							or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height).
							Leave empty to use "thumbnail" size', 'eltd-core' ),
							'dependency'  => array( 'element' => 'subtitle', 'not_empty' => true )
						),
						array(
							'type'       => 'textfield',
							'param_name' => 'custom_link',
							'heading'    => esc_html__( 'Custom Link', 'eltd-core' ),
							'dependency' => Array( 'element' => 'image_behavior', 'value' => array( 'custom-link' ) )
						),
						array(
							'type'       => 'dropdown',
							'param_name' => 'custom_link_target',
							'heading'    => esc_html__( 'Custom Link Target', 'eltd-core' ),
							'value'      => array_flip( albergo_elated_get_link_target_array() ),
							'dependency' => Array( 'element' => 'image_behavior', 'value' => array( 'custom-link' ) )
						),
					)
				) );
		}
	}

	public function render( $atts, $content = null ) {
		$default_atts = array(
			'title'                 => '',
			'title_tag'             => 'h4',
			'subtitle'              => '',
			'subtitle_tag'          => 'p',
			'image'                 => '',
			'image_size'            => 'full',
			'custom_link'           => '',
			'custom_link_target'    => '_self',

		);
		$params       = shortcode_atts( $default_atts, $atts );

		$params['content']            = $content;
		$params['title_tag']          = ! empty( $params['title_tag'] ) ? $params['title_tag'] : $default_atts['title_tag'];
		$params['subtitle_tag']       = ! empty( $params['subtitle_tag'] ) ? $params['subtitle_tag'] : $default_atts['subtitle_tag'];
		$params['image']              = $this->getImage( $params );
		$params['image_size']         = $this->getImageSize( $params['image_size'] );
		$params['custom_link_target'] = ! empty( $params['custom_link_target'] ) ? $params['custom_link_target'] : $default_atts['custom_link_target'];

		$output = eltd_core_get_shortcode_module_template_part( 'templates/landing-item-template', 'landing-list', '', $params );

		return $output;
	}

	private function getImage( $params ) {
		$image = array();

		if ( ! empty( $params['image'] ) ) {
			$id = $params['image'];

			$image['image_id'] = $id;
			$image_original    = wp_get_attachment_image_src( $id, 'full' );
			$image['url']      = $image_original[0];
			$image['alt']      = get_post_meta( $id, '_wp_attachment_image_alt', true );
		}

		return $image;
	}

	private function getImageSize( $image_size ) {
		$image_size = trim( $image_size );
		//Find digits
		preg_match_all( '/\d+/', $image_size, $matches );
		if ( in_array( $image_size, array( 'thumbnail', 'thumb', 'medium', 'large', 'full' ) ) ) {
			return $image_size;
		} elseif ( ! empty( $matches[0] ) ) {
			return array(
				$matches[0][0],
				$matches[0][1]
			);
		} else {
			return 'thumbnail';
		}
	}

}