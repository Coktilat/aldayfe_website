<div class="eltd-image-marquee-holder">
    <div class="eltd-image-marquee">
        <div class="eltd-image eltd-original">
            <img src="<?php echo wp_get_attachment_url($image); ?>" alt="<?php echo get_the_title($image) ?>" />
        </div>
        <div class="eltd-image eltd-aux">
            <img src="<?php echo wp_get_attachment_url($image); ?>" alt="<?php echo get_the_title($image) ?>" />
        </div>
    </div>
	<?php if ( ! empty( $logo_image ) || ! empty( $text ) ) { ?>
        <div class="eltd-image-marquee-text-holder">
			<?php if ( ! empty( $logo_image ) ) { ?>
                <div class="eltd-image-marquee-logo">
                    <img src="<?php echo wp_get_attachment_url( $logo_image ); ?>"
                         alt="<?php echo get_the_title( $logo_image ) ?>"/>
                </div>
			<?php } ?>
			<?php if ( ! empty( $text ) ) { ?>
                <p class="eltd-image-marquee-text"><?php echo esc_html( $text ); ?></p>
			<?php } ?>
        </div>
	<?php } ?>
</div>