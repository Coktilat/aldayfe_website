<div class="eltd-social-share-holder eltd-dropdown">
	<a href="javascript:void(0)" target="_self" class="eltd-social-share-dropdown-opener">
		<i class="icon-basic-share"></i>
        <span class="eltd-social-share-title"><?php esc_html_e('Share this', 'eltd-core') ?></span>
	</a>
	<div class="eltd-social-share-dropdown">
		<ul>
			<?php foreach ($networks as $net) {
				echo wp_kses($net, array(
					'li'   => array(
						'class' => true
					),
					'a'    => array(
						'itemprop' => true,
						'class'    => true,
						'href'     => true,
						'target'   => true,
						'onclick'  => true
					),
					'img'  => array(
						'itemprop' => true,
						'class'    => true,
						'src'      => true,
						'alt'      => true
					),
					'span' => array(
						'class' => true
					)
				));
			} ?>
		</ul>
	</div>
</div>