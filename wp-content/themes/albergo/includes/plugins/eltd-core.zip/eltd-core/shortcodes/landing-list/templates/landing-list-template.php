<div class="eltd-landing-items-holder <?php echo esc_attr($holder_classes); ?> clearfix">
    <div class="eltd-outer-space">
	    <?php echo do_shortcode($content); ?>
    </div>
</div>