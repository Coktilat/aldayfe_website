<?php

include_once ELATED_CORE_SHORTCODES_PATH . '/landing-list/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/landing-list/landing-list.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/landing-list/landing-item.php';