<div class="eltd-banner-holder <?php echo esc_attr($holder_classes); ?>">
    <div class="eltd-banner-image">
        <?php echo wp_get_attachment_image($image, 'full'); ?>
    </div>
    <div class="eltd-banner-text-holder" <?php echo albergo_elated_get_inline_style($overlay_styles); ?>>
	    <div class="eltd-banner-text-outer">
		    <div class="eltd-banner-text-inner">
		        <?php if(!empty($title)) { ?>
		            <<?php echo esc_attr($title_tag); ?> class="eltd-banner-title" <?php echo albergo_elated_get_inline_style($title_styles); ?>>
		                <?php echo wp_kses($title, array('span' => array('class' => true))); ?>
	                </<?php echo esc_attr($title_tag); ?>>
		        <?php } ?>
                <?php if(!empty($subtitle)) { ?>
                    <<?php echo esc_attr($subtitle_tag); ?> class="eltd-banner-subtitle" <?php echo albergo_elated_get_inline_style($subtitle_styles); ?>>
                        <?php echo esc_html($subtitle); ?>
                    </<?php echo esc_attr($subtitle_tag); ?>>
                <?php } ?>
				<?php if(!empty($link) && !empty($link_text)) {
					echo albergo_elated_get_button_html(
                        array_merge(
                            array(
                                'type'         => 'simple',
                                'size'         => 'medium',
                                'link'         => $link,
                                'target'       => $target,
                                'text'         => $link_text,
                                'custom_class' => 'eltd-blog-list-button',
                                //'line_position' => isset($line_position) ? $line_position : ''
                            ),
                            $button_params
                        )
                    );
                } ?>
			</div>
		</div>
	</div>
	<?php if (!empty($link)) { ?>
        <a itemprop="url" class="eltd-banner-link" href="<?php echo esc_url($link); ?>" target="<?php echo esc_attr($target); ?>"></a>
    <?php } ?>
</div>