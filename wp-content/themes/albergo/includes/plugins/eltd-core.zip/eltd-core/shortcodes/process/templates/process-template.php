<div class="eltd-process-holder <?php echo esc_attr( $holder_classes ); ?>">
	<div class="eltd-mark-horizontal-holder">
		<?php for ( $i = 1; $i <= $number_of_items; $i ++ ) { ?>
			<div class="eltd-process-mark">
				<div class="eltd-process-line"></div>
				<div class="eltd-process-circle"><?php echo esc_attr( $i ); ?></div>
			</div>
		<?php } ?>
	</div>
	<div class="eltd-mark-vertical-holder">
		<?php for ( $i = 1; $i <= $number_of_items; $i ++ ) { ?>
			<div class="eltd-process-mark">
				<div class="eltd-process-line"></div>
				<div class="eltd-process-circle"><?php echo esc_attr( $i ); ?></div>
			</div>
		<?php } ?>
	</div>
	<div class="eltd-process-inner">
		<?php echo do_shortcode( $content ); ?>
	</div>
</div>