<?php
/**
 * Highlight shortcode template
 */
?>

<span class="eltd-highlight" <?php albergo_elated_inline_style($highlight_style);?>>
	<?php echo esc_html($content);?>
</span>