<div class="eltd-landing-item eltd-item-space">
    <div class="eltd-landing-item-inner">
        <?php if ( ! empty( $params['image'] ) ) { ?>

                <div class="eltd-landing-item-image">
                    <?php if(($custom_link) != '') { ?>
                    <a itemprop="url" href="<?php echo esc_url($custom_link); ?>" target="<?php echo esc_attr($custom_link_target); ?>"></a>
                        <?php } ?>
                    <?php if(is_array($image_size) && count($image_size)) : ?>
                        <?php echo albergo_elated_generate_thumbnail($image['image_id'], null, $image_size[0], $image_size[1]); ?>
                    <?php else: ?>
                        <?php echo wp_get_attachment_image($image['image_id'], $image_size); ?>
                    <?php endif; ?>
                </div>
        <?php } ?>
        <div class="eltd-landing-item-text">
            <<?php echo esc_attr( $title_tag ); ?> class="eltd-li-title">
            <?php if(($custom_link) != '') { ?>
            <a itemprop="url" href="<?php echo esc_url($custom_link); ?>" target="<?php echo esc_attr($custom_link_target); ?>">
            <?php } ?>
                <span class="eltd-landing-item-title"><?php echo esc_html( $title ); ?></span>
            <?php if(!empty($custom_link)) { ?>
            </a>
            <?php } ?>
            </<?php echo esc_attr( $title_tag ); ?>>

            <<?php echo esc_attr( $subtitle_tag ); ?> class="eltd-li-subtitle">
                <span class="eltd-landing-item-subtitle"><?php echo esc_html( $subtitle ); ?></span>
            </<?php echo esc_attr( $subtitle_tag ); ?>>
        </div>

    </div>
</div>

