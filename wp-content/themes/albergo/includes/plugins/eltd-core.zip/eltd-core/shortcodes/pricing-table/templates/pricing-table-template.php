<div class="eltd-price-table eltd-item-space <?php echo esc_attr($holder_classes); ?>">
	<div class="eltd-pt-inner" <?php echo albergo_elated_get_inline_style($holder_styles); ?>>
		 <?php 	if ( ! empty( $params['image'] ) ) {  ?>
			<div class="eltd-pt-image">
				<?php if(is_array($image_size) && count($image_size)) : ?>
					<?php echo albergo_elated_generate_thumbnail($image['image_id'], null, $image_size[0], $image_size[1]); ?>
					<?php else: ?>
					<?php echo wp_get_attachment_image($image['image_id'], $image_size); ?>
				<?php endif; ?>
			</div>
		<?php }?>
		<ul>
			<li class="eltd-pt-title-holder">
					<h4 class="eltd-pt-title" <?php echo albergo_elated_get_inline_style($title_styles); ?>><?php echo esc_html($title); ?></h4>
			</li>
			<li class="eltd-pt-content">
				<?php echo do_shortcode($content); ?>
			</li>
			<li class="eltd-pt-prices">
				<?php if(isset($currency) && $currency != '') { ?>
				<sup class="eltd-pt-value" <?php echo albergo_elated_get_inline_style($currency_styles); ?>><?php echo esc_html($currency); ?></sup>
				<?php } ?>
				<?php if(isset($price) && $price != '') { ?>
                <span class="eltd-pt-price" <?php echo albergo_elated_get_inline_style($price_styles); ?>><?php echo esc_html($price); ?></span>
				<?php } ?>
                <?php if(isset($price_period) && $price_period != '') { ?>
				<h6 class="eltd-pt-mark" <?php echo albergo_elated_get_inline_style($price_period_styles); ?>><?php echo esc_html($price_period); ?></h6>
                <?php } ?>
			</li>
			<?php 
			if(!empty($button_text)) { ?>
				<li class="eltd-pt-button">
					<?php echo albergo_elated_get_button_html(array(
						'link' => $link,
						'text' => $button_text,
						'type' => $button_type,
                        'size' => 'large',
						'line_position' => 'center'
					)); ?>
				</li>				
			<?php } ?>
		</ul>
	</div>
</div>