<?php
namespace ElatedCore\CPT\Shortcodes\LandingList;

use ElatedCore\Lib;

class LandingList implements Lib\ShortcodeInterface {
	private $base;
	
	function __construct() {
		$this->base = 'eltd_landing_list';
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'                    => esc_html__( 'Elated Landing List', 'eltd-core' ),
					'base'                    => $this->base,
					'as_parent'               => array( 'only' => 'eltd_landing_item' ),
					'content_element'         => true,
					'category'                => esc_html__( 'by ELATED', 'eltd-core' ),
					'icon'                    => 'icon-wpb-landing-list extended-custom-icon',
					'show_settings_on_create' => true,
					'js_view'                 => 'VcColumnView',
					'params'                  => array(
						array(
							'type'        => 'textfield',
							'param_name'  => 'custom_class',
							'heading'     => esc_html__( 'Custom CSS Class', 'eltd-core' ),
							'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'eltd-core' )
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'number_of_columns',
							'heading'     => esc_html__( 'Number of Columns', 'eltd-core' ),
							'value'       => array(
								esc_html__( 'Default', 'eltd-core' ) => '',
								esc_html__( 'One', 'eltd-core' )     => '1',
								esc_html__( 'Two', 'eltd-core' )     => '2',
								esc_html__( 'Three', 'eltd-core' )   => '3',
								esc_html__( 'Four', 'eltd-core' )    => '4',
								esc_html__( 'Five', 'eltd-core' )    => '5'
							),
							'description' => esc_html__( 'Default value is Two', 'eltd-core' ),
							'admin_label' => true
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'space_between_list',
							'heading'     => esc_html__( 'Space Between Items', 'eltd-core' ),
							'value'       => array_flip( albergo_elated_get_space_between_items_array() ),
							'save_always' => true
						),
						array(
							'type'        => 'dropdown',
							'param_name'  => 'enable_image_shadow',
							'heading'     => esc_html__( 'Enable Image Shadow', 'eltd-core' ),
							'value'       => array_flip( albergo_elated_get_yes_no_select_array( false ) ),
							'save_always' => true
						),
					)
				)
			);
		}
	}

	public function render( $atts, $content = null ) {
		$default_atts = array(
			'custom_class'          => '',
			'number_of_columns'     => '2',
			'space_between_items'   => 'huge',
			'enable_image_shadow'   => 'no',

		);
		$params = shortcode_atts( $default_atts, $atts );

		$params['holder_classes'] = $this->getHolderClasses( $params );
		$params['content']        = $content;
		
		$output = eltd_core_get_shortcode_module_template_part( 'templates/landing-list-template', 'landing-list', '', $params );
		
		return $output;
	}
	
	private function getHolderClasses( $params )
	{
		$holder_classes = array('eltd-landing-list-default');

		$holder_classes[] = !empty($params['custom_class']) ? esc_attr($params['custom_class']) : '';

		$holder_classes[] = !empty($params['space_between_items']) ? 'eltd-' . $params['space_between_items'] . '-space' : 'eltd-normal-space';

		$number_of_columns = $params['number_of_columns'];
		switch ($number_of_columns):
			case '1':
				$holder_classes[] = 'eltd-li-one-column';
				break;
			case '2':
				$holder_classes[] = 'eltd-li-two-columns';
				break;
			case '3':
				$holder_classes[] = 'eltd-li-three-columns';
				break;
			case '4':
				$holder_classes[] = 'eltd-li-four-columns';
				break;
			case '5':
				$holder_classes[] = 'eltd-li-five-columns';
				break;
			default:
				$holder_classes[] = 'eltd-li-two-columns';
				break;
		endswitch;

		$holder_classes[] = $params['enable_image_shadow'] === 'yes' ? 'eltd-has-shadow' : '';



		return implode( ' ', $holder_classes );
	}


}
