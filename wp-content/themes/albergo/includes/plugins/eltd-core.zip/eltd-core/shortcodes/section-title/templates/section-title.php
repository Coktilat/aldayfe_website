<div class="eltd-section-title-holder <?php echo esc_attr($holder_class); ?>" <?php echo albergo_elated_get_inline_style($holder_styles); ?>>
    <div class="eltd-section-title-inner">
        <?php if(!empty($subtitle)) { ?>
            <<?php echo esc_attr($subtitle_tag); ?> class="eltd-st-subtitle" <?php echo albergo_elated_get_inline_style($subtitle_styles); ?>>
                <span><?php echo esc_html($subtitle); ?></span>
            </<?php echo esc_attr($subtitle_tag); ?>>
        <?php } ?>
        <?php if(!empty($title)) { ?>
            <<?php echo esc_attr($title_tag); ?> class="eltd-st-title <?php echo esc_attr($title_align); ?>" <?php echo albergo_elated_get_inline_style($title_styles); ?>>
                <span class="eltd-st-before"><?php echo esc_html($title_before); ?></span>
                <span><?php echo esc_html($title); ?></span>
            </<?php echo esc_attr($title_tag); ?>>
        <?php } ?>
        <?php if(!empty($text)) { ?>
            <p class="eltd-st-text" <?php echo albergo_elated_get_inline_style($text_styles); ?>><?php echo esc_html($text); ?></p>
        <?php } ?>
        <?php if(!empty($text_price)) { ?>
            <p class="eltd-st-price" <?php echo albergo_elated_get_inline_style($price_styles); ?>>
                <span class="eltd-st-currency"><?php echo esc_attr($currency); ?></span><?php echo esc_html($text_price); ?>
                <span class="eltd-st-per-night"><?php esc_html_e('/ night', 'eltd-core'); ?></span>
            </p>
        <?php } ?>
    </div>
</div>