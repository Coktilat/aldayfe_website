<li class="eltd-tl-item eltd-item-space">
    <div class="eltd-tli-inner">
        <div class="eltd-tli-content">
            <div class="eltd-twitter-content-top">
                <div class="eltd-twitter-user clearfix">
                    <div class="eltd-twitter-image">
                        <img src="<?php echo esc_html( $twitter_api->getHelper()->getTweetProfileImage( $tweet ) ); ?>" alt="<?php echo esc_html( $twitter_api->getHelper()->getTweetProfileName( $tweet ) ); ?>"/>
                    </div>
                    <div class="eltd-twitter-name">
                        <div class="eltd-twitter-autor">
                            <h5>
                                <?php echo esc_html( $twitter_api->getHelper()->getTweetProfileName( $tweet ) ); ?>
                            </h5>
                        </div>
                        <div class="eltd-twitter-profile">
                            <a href="<?php echo esc_url( $twitter_api->getHelper()->getTweetProfileURL( $tweet ) ); ?>" target="_blank" itemprop="url">
                                <?php echo esc_html( $twitter_api->getHelper()->getTweetProfileScreenName( $tweet ) ); ?>
                            </a>
                        </div>
                    </div>
                </div>
                <i class="eltd-twitter-icon social_twitter"></i>
            </div>
            <div class="eltd-twitter-content-bottom">
                <div class="eltd-tweet-text">
                    <?php echo wp_kses_post( $twitter_api->getHelper()->getTweetText( $tweet ) ); ?>
                </div>
            </div>
            <a class="eltd-twitter-link-over" href="<?php echo esc_url( $twitter_api->getHelper()->getTweetProfileURL( $tweet ) ); ?>" target="_blank" itemprop="url"></a>
        </div>
    </div>
</li>