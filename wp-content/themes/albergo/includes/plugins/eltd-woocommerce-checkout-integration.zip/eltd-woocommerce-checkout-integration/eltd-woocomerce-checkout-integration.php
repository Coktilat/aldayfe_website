<?php
/*
Plugin Name: Elated Woocommerce Checkout Integration
Description: Plugin that adds custom post type to woocommerce checkout
Author: Elated Themes
Version: 1.0.1
*/
include_once 'load.php';

if ( ! function_exists( 'eltd_checkout_load_checkout_plugin' ) ) {
	function eltd_checkout_load_checkout_plugin() {
		include_once 'payment/class-wc-product-eltd.php';
		include_once 'payment/class-wc-eltd-data-store-cpt.php';
		include_once 'payment/class-wc-order-item-eltd.php';
		include_once 'payment/class-wc-order-item-eltd-store.php';
	}

	add_action( 'plugins_loaded', 'eltd_checkout_load_checkout_plugin', 99 );
}


