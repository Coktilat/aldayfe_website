<?php
/*
Plugin Name: Elated Hotel
Description: Plugin that adds post types for Hotel extension
Author: Elated Themes
Version: 1.0.3
*/

include_once 'load.php';

define('ELTD_HOTEL_MAIN_FILE_PATH', __FILE__);

use ElatedHotel\DatabaseSetup\TablesSetup;
use ElatedHotel\CPT\HotelRoom\Lib\PageTemplater;
use ElatedHotel\CPT\HotelRoom\Lib\BookingHandler;

add_action('after_setup_theme', array(ElatedHotel\CPT\PostTypesRegister::getInstance(), 'register'));

TablesSetup::getInstance()->initialize();
PageTemplater::getInstance()->initialize();
BookingHandler::getInstance()->initialize();

if(!function_exists('eltd_hotel_load_assets')) {
	function eltd_hotel_load_assets() {

		$array_deps_css            = array();
		$array_deps_css_responsive = array();
		$array_deps_js             = array();

		if ( eltd_hotel_theme_installed() ) {
			$array_deps_css[]            = 'albergo_elated_modules';
			$array_deps_css_responsive[] = 'albergo_elated_modules_responsive';
			$array_deps_js[]             = 'albergo_elated_modules';
			$array_deps_js[]             = 'albergo_elated_google_map_api';
			$array_deps_js[]             = 'select2';
			$array_deps_js[]             = 'rangeslider';
		}

		wp_enqueue_style('eltd_hotel_style', plugins_url('/assets/css/hotel.css', __FILE__), $array_deps_css);
        if(albergo_elated_is_responsive_on()) {
            wp_enqueue_style('eltd_hotel_responsive_style', plugins_url('/assets/css/hotel-responsive.css', __FILE__), $array_deps_css_responsive);
        }

		wp_enqueue_script('jquery-ui-datepicker');
		wp_enqueue_script( 'rangeslider', ELTD_HOTEL_URL_PATH.'assets/js/plugins/rangeslider.min.js', array('jquery'), false, true );
		wp_enqueue_script( 'select2', ELTD_HOTEL_URL_PATH.'assets/js/plugins/select2.min.js', array('jquery'), false, true );

		wp_enqueue_script( 'jquery-ui-slider' );
		if(wp_is_mobile()) {
			wp_enqueue_script( 'jquery-touch-punch' );
		}

		//wp_enqueue_style( 'eltd-jquery-ui', get_template_directory_uri() . '/framework/admin/assets/css/jquery-ui/jquery-ui.css' );

		wp_enqueue_script('eltd-hotel-script', plugins_url('/assets/js/hotel.js', __FILE__), $array_deps_js, false, true);
	}

	add_action('wp_enqueue_scripts', 'eltd_hotel_load_assets');
}

if(!function_exists('eltd_hotel_load_admin_assets')) {
	function eltd_hotel_load_admin_assets() {

		wp_enqueue_script('jquery-ui-datepicker');
		wp_enqueue_style( 'eltd-jquery-ui', get_template_directory_uri() . '/framework/admin/assets/css/jquery-ui/jquery-ui.css' );
	}

	add_action('admin_enqueue_scripts', 'eltd_hotel_load_admin_assets');
}

if ( ! function_exists( 'eltd_hotel_style_dynamics_deps' ) ) {
    function eltd_hotel_style_dynamics_deps( $deps ) {
        $style_dynamic_deps_array = array();
        $style_dynamic_deps_array[] = 'eltd_hotel_style';

        if(albergo_elated_is_responsive_on()) {
            $style_dynamic_deps_array[] = 'eltd_hotel_responsive_style';
        }

        return array_merge($deps, $style_dynamic_deps_array);
    }

    add_filter('albergo_elated_style_dynamic_deps','eltd_hotel_style_dynamics_deps');
}

if(!function_exists('eltd_hotel_add_maps_extensions')) {
	function eltd_hotel_add_maps_extensions($extensions) {
		$items = array(
			'geometry',
			'places'
		);
		$extensions = array_unique( array_merge( $extensions, $items ) );

		return $extensions;
	}
	add_filter('albergo_elated_google_maps_extensions_array', 'eltd_hotel_add_maps_extensions', 10, 1);
}

if(!function_exists('eltd_hotel_enable_maps_in_admin')) {
	/**
	 * Loads plugin text domain so it can be used in translation
	 */
	function eltd_hotel_enable_maps_in_admin() {
		return true;
	}

	add_action('albergo_elated_google_maps_in_backend', 'eltd_hotel_enable_maps_in_admin');
}