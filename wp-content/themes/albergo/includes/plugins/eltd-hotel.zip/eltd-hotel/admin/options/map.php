<?php

if(eltd_hotel_theme_installed()) {
	if(!function_exists('albergo_elated_hotel_map_map')) {

		function albergo_elated_hotel_map_map() {


			albergo_elated_add_admin_page(array(
				'title' => esc_html__('Hotel', 'eltd-hotel'),
				'slug'  => '_hotel',
				'icon'  => 'fa fa-building-o'
			));

			$reviews_panel = albergo_elated_add_admin_panel(array(
				'title' => esc_html__('Reviews', 'eltd-hotel'),
				'name'  => 'panel_reviews',
				'page'  => '_hotel'
			));

			albergo_elated_add_admin_field(array(
				'parent'        => $reviews_panel,
				'type'          => 'text',
				'name'          => 'hotel_reviews_section_title',
				'default_value' => '',
				'label'         => esc_html__('Reviews Section Title', 'eltd-hotel'),
				'description'   => esc_html__('Enter title that you want to show before average rating for each hotel room', 'eltd-hotel'),
			));

			albergo_elated_add_admin_field(array(
				'parent'        => $reviews_panel,
				'type'          => 'textarea',
				'name'          => 'hotel_reviews_section_subtitle',
				'default_value' => '',
				'label'         => esc_html__('Reviews Section Subtitle', 'eltd-hotel'),
				'description'   => esc_html__('Enter subtitle that you want to show before average rating for each hotel room', 'eltd-hotel'),
			));

			do_action('eltd_hotel_room_action_single_fields');
		}


		add_action('albergo_elated_options_map', 'albergo_elated_hotel_map_map', 14); //one after elements
	}
}