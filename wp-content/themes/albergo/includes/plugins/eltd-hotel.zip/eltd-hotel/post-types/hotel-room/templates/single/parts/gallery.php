<?php
$image_gallery_val = get_post_meta(get_the_ID(), 'eltd_hotel_gallery_images', true);

if($image_gallery_val !== '') : ?>
	<div class="eltd-hotel-room-label-items-holder">
		<div class="eltd-hotel-room-gallery-item-holder">

			<h4 >
				<?php esc_html_e('From our gallery', 'eltd-rooms'); ?>
			</h4>

			<div class="eltd-hotel-room-gallery clearfix">
				<?php
				$image_gallery_array = explode(',', $image_gallery_val);
				if(isset($image_gallery_array) && count($image_gallery_array)) : ?>

					<?php for($i = 0; $i < count($image_gallery_array); $i++) : ?>
						<?php if(isset($image_gallery_array[$i])) : ?>
							<div class="eltd-hotel-room-gallery-item">
								<a href="<?php echo wp_get_attachment_url($image_gallery_array[$i]) ?>" data-rel="prettyPhoto[gallery_excerpt_pretty_photo]">
									<?php echo wp_get_attachment_image($image_gallery_array[$i], 'albergo_elated_square'); ?>
								</a>
							</div>
						<?php endif; ?>
					<?php endfor; ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
<?php endif; ?>