<div class="eltd-hrp-holder <?php echo esc_html($holder_classes) ?>">

<?php foreach($rooms as $room) : ?>

    <div class="eltd-hrp <?php echo esc_html($room['class_name']); ?>">
        <div class="eltd-hrp-inner">
            <div class="eltd-hrp-image">
                <a class="eltd-hrp-link" itemprop="url" href="<?php echo get_the_permalink($room['room_id']); ?>" title="<?php the_title_attribute(); ?>">
                    <div class="eltd-hrp-trim" <?php echo albergo_elated_get_inline_style($trim_styles); ?>></div>
                    <?php
                        if($room['enable_custom_image'] == 'no') {
                            echo get_the_post_thumbnail($room['room_id'], $room['image_size']);
                        }
                        else {
                            echo wp_get_attachment_image($room['custom_image'], 'full');
                        }
                    ?>
                </a>
            </div>
            <div class="eltd-hrp-text-wrapper clearfix">
                <<?php echo esc_attr($title_tag); ?> itemprop="name" class="entry-title eltd-hrp-title">
                    <a itemprop="url" href="<?php echo get_the_permalink($room['room_id']); ?>"><?php echo get_the_title($room['room_id']); ?></a>
                </<?php echo esc_attr($title_tag); ?>>
            <div class="eltd-hrp-price-wrapper">
                 <span class="eltd-hrp-price">
                    <span class="eltd-hrp-price-currency"><?php echo esc_attr( $currency ) ?></span><span><?php echo esc_attr( $room['room_price'] ) ?></span>
                </span>
            </div>
        </div>
        </div>
    </div>
<?php endforeach; ?>

</div>
