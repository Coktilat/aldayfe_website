<?php extract( apply_filters( 'albergo_elated_hotel_single_price_params', array() ) ); ?>
<div class="eltd-hr-single-title-holder">
    <div class="eltd-grid-row">
        <div class="eltd-grid-col-9">
            <div class="eltd-hr-single-title-inner">
                <h4 class="eltd-hotel-room-single-title">
                    <?php the_title(); ?>
                </h4>
                <?php if ( $price ) { ?>
                <div class="eltd-hotel-room-single-price">
                    <span class="eltd-single-price-currency"><?php echo esc_attr( $currency ) ?></span><span class="eltd-single-price"><?php echo esc_attr( $price ) ?></span>
                    <span class="eltd-single-price-per"><?php esc_html_e('/ night', 'eltd-hotel'); ?></span>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>