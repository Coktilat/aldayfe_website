<?php
if ( ( eltd_hotel_room_check_availability( $params )['flag'] )) { ?>
    <article class="eltd-hrl-item <?php echo esc_attr( $this_object->getArticleClasses( $params ) ); ?>"
             id="<?php echo esc_attr( get_the_ID() ); ?>">
        <div class="eltd-hrl-item-inner">
			<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'layout-collections/' . $type, '', $params ); ?>
        </div>
    </article>
<?php } ?>