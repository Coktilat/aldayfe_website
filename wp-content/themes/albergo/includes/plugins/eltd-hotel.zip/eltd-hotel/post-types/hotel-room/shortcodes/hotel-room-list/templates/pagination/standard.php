<?php
if ( $query_results->max_num_pages > 1 ) {?>
	<div class="eltd-hrl-loading">
		<div class="eltd-hrl-loading-bounce1"></div>
		<div class="eltd-hrl-loading-bounce2"></div>
		<div class="eltd-hrl-loading-bounce3"></div>
	</div>
	<?php
	$pages = $query_results->max_num_pages;
	$paged = $query_results->query['paged'];
	
	if ( $pages > 1 ) { ?>
		<div class="eltd-hrl-standard-pagination">
			<ul>
				<li class="eltd-hrl-pag-prev">
					<a href="#" data-paged="1"><span class="eltd-custom-prev-icon">
						<span class="custom-line-top"></span><span class="custom-line-bottom"></span>
					</span>
						<?php echo '<span class="eltd-hrl-single-nav-label">' .esc_html__('previous', 'albergo'). '</span>' ?>
					</a>
				</li>
				<?php for ( $i = 1; $i <= $pages; $i ++ ) { ?>
					<?php
					$active_class = '';
					if ( $paged == $i ) {
						$active_class = 'eltd-hrl-pag-active';
					}
					?>
					<li class="eltd-hrl-pag-number <?php echo esc_attr( $active_class ); ?>">
						<a href="#" data-paged="<?php echo esc_attr( $i ); ?>"><?php echo esc_html( $i ); ?></a>
					</li>
				<?php } ?>
				<li class="eltd-hrl-pag-next ">
					<a href="#" data-paged="2">
						<?php echo '<span class="eltd-hrl-single-nav-label">' .esc_html__('next', 'albergo'). '</span>' ?>
						<span class="eltd-custom-next-icon">
						<span class="custom-line-top"></span><span class="custom-line-bottom"></span>
					</span></a>
				</li>
			</ul>
		</div>
	<?php }
	?>
<?php }