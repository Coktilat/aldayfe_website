<?php
$item_featured_value = get_post_meta( get_the_ID(), 'eltd_hotel_room_is_featured_meta', true );
$item_featured       = ! empty( $item_featured_value ) && $item_featured_value === 'yes' ? true : false;
if ( $item_featured ) {
	?>
    <div class="eltd-item-featured">
        <i class="fa fa-bolt" aria-hidden="true"></i>
    </div>
<?php }
