<div class="eltd-full-width">
    <div class="eltd-full-width-inner clearfix">
        <div class="eltd-hotel-room-search-holder">
            <div class="eltd-container">
                <div class="eltd-container-inner">
                    <div class="eltd-grid-row <?php echo esc_attr($holder_classes); ?>">
                        <div <?php echo albergo_elated_get_content_sidebar_class(); ?>>
                            <?php
                            eltd_hotel_get_cpt_single_module_template_part( 'templates/search/parts/search-hotel', 'hotel-room', '', array( 'params' => $params ) );
                            ?>
                        </div>
                        <?php if($sidebar_layout !== 'no-sidebar') { ?>
                            <div <?php echo albergo_elated_get_sidebar_holder_class(); ?>>
                                <?php get_sidebar(); ?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>