<?php

include_once ELTD_HOTEL_CPT_PATH.'/hotel-room/hotel-room-register.php';
include_once ELTD_HOTEL_CPT_PATH.'/hotel-room/helper-functions.php';
include_once ELTD_HOTEL_CPT_PATH.'/hotel-room/tax-custom-fields.php';
include_once ELTD_HOTEL_CPT_PATH.'/hotel-room/profile/profile-functions.php';
include_once ELTD_HOTEL_CPT_PATH.'/hotel-room/reviews/load.php';
include_once ELTD_HOTEL_CPT_PATH.'/hotel-room/shop/load.php';

//load admin
if(!function_exists('eltd_hotel_room_load_admin')) {
	function eltd_hotel_room_load_admin() {
		include_once ELTD_HOTEL_CPT_PATH.'/hotel-room/admin/options/map.php';
	}
	add_action('albergo_elated_before_options_map', 'eltd_hotel_room_load_admin');
}
