<?php
$max_adults = eltd_hotel_get_hotel_room_adults();
?>
<?php if ( $max_adults != '' ) { ?>
    <div class="eltd-filter-section eltd-filter-section-12 eltd-section-adults">
        <div class="eltd-filter-adults-count-holder" data-adults="<?php echo esc_attr($params['room_adults']) ?>">
            <label for="eltd-filter-adults"><?php esc_html_e( 'adults', 'eltd-hotel' ) ?></label>
            <select id="eltd-filter-adults" name="eltd-filter-adults" class="eltd-filter-adults">
                <option value="0">0</option>
	            <?php for ( $i = 1; $i <= $max_adults; $i ++ ) { ?>
                    <option <?php echo ($params['room_adults'] == $i) ? 'selected' : ''; ?>
                            value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
	            <?php } ?>
            </select>
        </div>
    </div>
<?php } ?>