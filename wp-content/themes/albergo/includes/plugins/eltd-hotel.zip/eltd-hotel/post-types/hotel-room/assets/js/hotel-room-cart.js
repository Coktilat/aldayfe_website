(function($) {
    'use strict';

    var hotelRoomCart = {};
    eltd.modules.hotelRoomCart = hotelRoomCart;

    hotelRoomCart.eltdOnDocumentReady = eltdOnDocumentReady;
    hotelRoomCart.eltdOnWindowLoad = eltdOnWindowLoad;
    hotelRoomCart.eltdOnWindowResize = eltdOnWindowResize;
    hotelRoomCart.eltdOnWindowScroll = eltdOnWindowScroll;

    hotelRoomCart.eltdInitHotelRoomCartUpdateSession = eltdInitHotelRoomCartUpdateSession ;

    $(document).ready(eltdOnDocumentReady);
    $(window).load(eltdOnWindowLoad);
    $(window).resize(eltdOnWindowResize);
    $(window).scroll(eltdOnWindowScroll);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function eltdOnDocumentReady() {
        eltdInitHotelRoomCartUpdateSession();


    }

    /*
     All functions to be called on $(window).load() should be in this function
     */
    function eltdOnWindowLoad() {
    }

    /*
     All functions to be called on $(window).resize() should be in this function
     */
    function eltdOnWindowResize() {

    }

    /*
     All functions to be called on $(window).scroll() should be in this function
     */
    function eltdOnWindowScroll() {

    }

    function eltdInitHotelRoomCartUpdateSession(){
        var wooCommerceCheckout = $('.woocommerce-checkout');

        function updateSessionTrigger() {


            var ajaxData = {
                action: 'check_hotel_room_session_update',
            };

            $.ajax({
                type: 'POST',
                data: ajaxData,
                url: eltdGlobalVars.vars.eltdAjaxUrl,

                success: function (data) {
                    return true;
                }
            });
        }

        if(wooCommerceCheckout.length) {
            updateSessionTrigger();
        }
      
    }

    

})(jQuery);