<?php
$thumb_size = $this_object->getImageSize($params);
?>
<div class="eltd-hrl-item-image">
	<?php if ( has_post_thumbnail() ) {
    $image_src = get_the_post_thumbnail_url( get_the_ID() );

    if ( strpos( $image_src, '.gif' ) !== false ) {
        echo get_the_post_thumbnail( get_the_ID(), 'full' );
    } else {

	    if ($thumb_size == 'custom' && $custom_image_width != '' && $custom_image_height != '') {
		    echo albergo_elated_generate_thumbnail('', $image_src, albergo_elated_filter_px($custom_image_width), albergo_elated_filter_px($custom_image_height));
	    } else {
		    echo get_the_post_thumbnail( get_the_ID(), $thumb_size );
	    }
    }
} else { ?>
    <img itemprop="image" class="eltd-hrl-original-image" width="800" height="600" src="<?php echo ELTD_HOTEL_CPT_URL_PATH.'/hotel-room/assets/img/hotel_room_featured_image.jpg'; ?>" alt="<?php esc_html_e('Hotel Room Featured Image', 'eltd-hotel'); ?>" />
<?php } ?>
    <a itemprop="url" class="eltd-hrl-link eltd-block-drag-link" href="<?php echo get_permalink(); ?>" target="_self"></a>
	<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/featured', '', $params ); ?>
</div>