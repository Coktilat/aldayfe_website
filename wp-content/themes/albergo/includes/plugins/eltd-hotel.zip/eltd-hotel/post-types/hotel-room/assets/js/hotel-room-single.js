(function($) {
    'use strict';

    var hotelRoomSingle = {};
    eltd.modules.hotelRoomSingle = hotelRoomSingle;

    hotelRoomSingle.eltdOnDocumentReady = eltdOnDocumentReady;
    hotelRoomSingle.eltdOnWindowLoad = eltdOnWindowLoad;
    hotelRoomSingle.eltdOnWindowResize = eltdOnWindowResize;
    hotelRoomSingle.eltdOnWindowScroll = eltdOnWindowScroll;

    hotelRoomSingle.eltdInitHotelRoomSingleTabs = eltdInitHotelRoomSingleTabs;
    hotelRoomSingle.eltdHotelRoomTabsMapTrigger = eltdHotelRoomTabsMapTrigger;
    hotelRoomSingle.eltdHotelRoomReviewsInit = eltdHotelRoomReviewsInit;
    hotelRoomSingle.eltdInitHotelRoomSingleSlider = eltdInitHotelRoomSingleSlider;

    $(document).ready(eltdOnDocumentReady);
    $(window).load(eltdOnWindowLoad);
    $(window).resize(eltdOnWindowResize);
    $(window).scroll(eltdOnWindowScroll);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function eltdOnDocumentReady() {
        if(typeof eltd === 'undefined' || typeof eltd === '' ){
            //if theme is not installed, generate single items manualy
            eltdInitHotelRoomSingleTabs();
        }

        if(typeof eltd !== 'undefined' ){
            //if theme is installed, trigger google map loading on location tab on single pages
            eltdHotelRoomTabsMapTrigger();

        }

        // For now, regardless of whether the theme is installed, initiate reviews
        eltdHotelRoomReviewsInit();


    }

    /*
     All functions to be called on $(window).load() should be in this function
     */
    function eltdOnWindowLoad() {
        eltdInitHotelRoomSingleReservation();
        eltdInitHotelRoomSingleSlider();
    }

    /*
     All functions to be called on $(window).resize() should be in this function
     */
    function eltdOnWindowResize() {

    }

    /*
     All functions to be called on $(window).scroll() should be in this function
     */
    function eltdOnWindowScroll() {

    }

    function eltdInitHotelRoomSingleTabs(){
        var holder = $('.eltd-hotel-room-single-outer');
        var roomNavItems = holder.find('.eltd-hr-item-wrapper ul li a');
        var roomSectionsItems  = holder.find('.eltd-hr-item-section');
        roomNavItems.first().addClass('eltd-active-item');

        roomNavItems.on('click', function(e){

            e.preventDefault();

            roomNavItems.removeClass('eltd-active-item');

            var thisNavItem  = $(this);

            var thisNavItemId = thisNavItem.attr('href');
            thisNavItem.addClass('eltd-active-item');

            if( roomSectionsItems.length ){
                roomSectionsItems.each(function(){

                    var thisSectionItem = $(this);

                    if('#'+thisSectionItem.attr('id') === thisNavItemId){
                        thisSectionItem.show();
                        if(thisNavItemId === '#eltd_hotel_room_tab_id_location'){
                            eltdHotelRoomReInitGoogleMap();
                        }
                    }else{
                        thisSectionItem.hide();
                    }
                });
            }
        });
    }

    function eltdHotelRoomTabsMapTrigger(){
        var holder = $('.eltd-hotel-room-single-outer');
        var hotelRoomNavItems = holder.find('.eltd-hr-item-wrapper ul li a');
        hotelRoomNavItems.on('click', function(e){

            e.preventDefault();

            var thisNavItem  = $(this);
            var thisNavItemId = thisNavItem.attr('href');

            if(thisNavItemId === '#eltd_hotel_room_tab_id_location'){
                eltdHotelRoomReInitGoogleMap();
            }
        });
    }

    function eltdHotelRoomReInitGoogleMap(){

        if(typeof eltd !== 'undefined'){
            eltd.modules.googleMap.eltdShowGoogleMap();
        }
    }

    function eltdHotelRoomReviewsInit() {
        var reviewWrappers = $('.eltd-hr-item-reviews-input-wrapper');
        if (reviewWrappers.length) {

            var emptyStarClass = 'icon_star_alt',
                fullStarClass = 'icon_star';

            var setCriteriaCommands = function(criteriaHolder) {
                criteriaHolder.find('.eltd-hr-item-reviews-star-holder')
                    .mouseenter(function () {
                        $(this).add($(this).prevAll()).find('.eltd-hr-item-reviews-star').removeClass(emptyStarClass).addClass(fullStarClass);
                        $(this).nextAll().find('.eltd-hr-item-reviews-star').removeClass(fullStarClass).addClass(emptyStarClass);
                    })
                    .click(function() {
                        criteriaHolder.find('.eltd-hr-item-reviews-hidden-input').val($(this).index()+1);
                    });

                criteriaHolder.find('.eltd-hr-item-reviews-rating-holder')
                    .mouseleave(function() {
                        var inputValue = criteriaHolder.find('.eltd-hr-item-reviews-hidden-input').val();
                        inputValue = inputValue === "" ? 0 : parseInt(inputValue,10);
                        $(this).find('.eltd-hr-item-reviews-star-holder').each(function(i) {
                            $(this).find('.eltd-hr-item-reviews-star').removeClass((i < inputValue) ? emptyStarClass : fullStarClass).addClass((i < inputValue) ? fullStarClass : emptyStarClass);
                        });
                    }).trigger('mouseleave');
            };

            reviewWrappers.each(function() {

                var reviewWrapper = $(this);
                var criteriaHolders = reviewWrapper.find('.eltd-hr-item-reviews-criteria-holder');

                criteriaHolders.each(function() {
                    setCriteriaCommands($(this));
                });
            });
        }
    }

    function eltdInitHotelRoomSingleReservation() {
        var reservation = $('.eltd-hotel-room-reservation');
        if (reservation.length) {

            reservation.each(function() {
                var thisReservation = $(this),
                    allInputs               = thisReservation.find('input, select'),
                    thisReservationHolder   = thisReservation.parents('.eltd-hotel-room-reservation-holder'),
                    finishForm              = thisReservation.find('.eltd-buy-item-form .eltd-hotel-room-single-res-button'), // form that is enabled after validation
                    relocationButton        = thisReservation.find('.eltd-hotel-room-reservation-similar'), // button for relocation
                    form                    = thisReservation.find('#eltd-hotel-room-form'), // initial form
                    initialPrice            = thisReservation.find('.eltd-res-initial-price .eltd-res-price-number'), // initial price
                    endPrice                = thisReservation.find('.eltd-res-end-price .eltd-res-price-number'), // end price after activated extra services
                    roomNumber              = thisReservation.find('.eltd-res-rooms-number'),
                    adults                  = thisReservation.find('.eltd-res-adults'),
                    children                = thisReservation.find('.eltd-res-children'),
                    minDate                 = thisReservation.find('.eltd-res-min-date'),
                    maxDate                 = thisReservation.find('.eltd-res-max-date'),
                    formValidation          = thisReservation.find('#reservation-validation-messages-holder');

                //INIT ROOMS FIELD

                var selectRoomNumber = roomNumber;
                if(selectRoomNumber.length) {
                    selectRoomNumber.select2({
                        minimumResultsForSearch: -1
                    });
                }

                //INIT ADULTS FIELD

                var selectAdults = adults;
                if(selectAdults.length) {
                    selectAdults.select2({
                        minimumResultsForSearch: -1
                    });
                }

                //INIT ADULTS FIELD

                var selectChildren = children;
                if(selectChildren.length) {
                    selectChildren.select2({
                        minimumResultsForSearch: -1
                    });
                }


                //INIT DATE CHECK-IN FIELD
                if(minDate.length) {
                    minDate.datepicker({
                        minDate : '0',
                        dateFormat: 'yy-mm-dd'
                    })
                }

                //INIT DATE CHECK-OUT FIELD
                if(maxDate.length) {
                    maxDate.datepicker({
                        minDate : '+1d',
                        dateFormat: 'yy-mm-dd'
                    })
                }

                allInputs.change(function() {
                    // reset buttons on reservation form when something is changed
                    finishForm.addClass('eltd-disable-hotel-room-single-btn');
                    relocationButton.addClass('eltd-disable-hotel-room-single-btn');
                });

                form.on('submit', function(e) {

                    var thisForm = $(this);

                    e.preventDefault();
                    e.stopPropagation();

                    var ajaxData = {
                        action: 'check_hotel_room_booking'
                    };

                    // get all inputs
                    ajaxData.fields = thisForm.serialize();

                    $.ajax({
                        type: 'POST',
                        data: ajaxData,
                        url: eltdGlobalVars.vars.eltdAjaxUrl,

                        success: function (data) {

                            var response = $.parseJSON(data);

                            if(!response.status) {
                                updateValidationTemplate(formValidation, response.messages);

                                finishForm.addClass('eltd-disable-hotel-room-single-btn');

                                if(response.relocation === 'hotel_search') {
                                    // enable relocation
                                    relocationButton.removeClass('eltd-disable-hotel-room-single-btn');
                                }
                                else {
                                    // leave only check reservation
                                    relocationButton.addClass('eltd-disable-hotel-room-single-btn');
                                }

                            } else {

                                // reset all messages
                                updateValidationTemplate(formValidation, []);

                                // enable add to cart
                                relocationButton.addClass('eltd-disable-hotel-room-single-btn');

                                finishForm.removeClass('eltd-disable-hotel-room-single-btn');

                                if(response.newPrice !== '') {
                                    // set new price
                                    endPrice.html(response.newPrice);
                                }

                            }

                            // added to reservation holder data
                            setDataForBooking(thisReservationHolder, thisForm);
                        }
                    });
                });

                relocationButton.click(function (e) {
                    e.preventDefault();
                    e.stopPropagation();

                    var thisButton = $(this);
                    var data = thisReservationHolder.data();

                    var searchLink = thisButton.attr('href');

                    var i = 0;
                    // creating link and 'get' data
                    $.each(data, function(index, value) {
                        if(i++ === 0) {
                            searchLink+= '?';
                        } else {
                            searchLink+= '&';
                        }
                        searchLink += index + '=' + value;
                    });

                    // redirect to search page
                    window.location = searchLink;

                })

            });

        }


        var updateValidationTemplate = function (formValidation, messages) {
            var html = '';

            for(var i = 0; i < messages.length; i++) {
                html += '<div class="eltd-reservation-messages">' + messages[i] + '</div>';
            }

            formValidation.html(html);

        };

        var setDataForBooking = function (holder, form) {
            holder.data('min_date', form.find('input[name="room_min_date"]').val());
            holder.data('max_date', form.find('input[name="room_max_date"]').val());
            holder.data('rooms_number', form.find('select[name="room_number"]').val());
            holder.data('adults', form.find('select[name="room_adults"]').val());
            holder.data('children', form.find('select[name="room_children"]').val());
        }

    }

    function eltdInitHotelRoomSingleSlider() {
        var sliders = $('.eltd-hotel-room-single-holder .eltd-owl-slider, .eltd-hotel-room-single-holder .eltd-slider-thumbnail');

        if(sliders.length) {
            sliders.addClass('eltd-hotel-single-slider-show');
        }
    }



})(jQuery);