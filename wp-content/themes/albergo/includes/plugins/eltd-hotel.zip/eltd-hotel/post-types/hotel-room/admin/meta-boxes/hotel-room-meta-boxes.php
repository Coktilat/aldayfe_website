<?php
if(eltd_hotel_theme_installed()) {
	if(!function_exists( 'eltd_hotel_room_meta_box_map' )) {
		function eltd_hotel_room_meta_box_map()
		{

			/* get currency */
			$currency = eltd_hotel_room_get_currency();

			$hotel_room_meta_box = albergo_elated_add_meta_box(
				array(
					'scope' => array('hotel-room'),
					'title' => esc_html__('Hotel Room Settings', 'eltd-hotel'),
					'name' => 'hotel_room_item_meta'
				)
			);

			albergo_elated_add_meta_box_field(
				array(
					'name'          => 'eltd_hotel_room_featured_item_meta',
					'type'          => 'select',
					'default_value' => '',
					'label'         => esc_html__('Choose element on the top', 'eltd-hotel'),
					'description'   => esc_html__('This option will set first element on single item ', 'eltd-hotel'),
					'options'     => array(
						''  => esc_html__( 'Default', 'eltd-hotel' ),
						'featured_image' => esc_html__( 'Featured Image', 'eltd-hotel' ),
						'slider' => esc_html__( 'Slider (from gallery)', 'eltd-hotel' ),
					),
					'parent'        => $hotel_room_meta_box,
				)
			);

			albergo_elated_add_admin_section_title( array(
				'title'       => esc_html__( 'Tabs', 'eltd-hotel' ),
				'description' => esc_html__( 'Enable items for single room', 'eltd-hotel' ),
				'name'        => 'hotel_room_single_tab_title',
				'parent'      => $hotel_room_meta_box
			) );


			albergo_elated_add_meta_box_field(
				array(
					'name'          => 'eltd_hotel_room_enable_amenities_meta',
					'type'          => 'select',
					'default_value' => '',
					'label'         => esc_html__('Enable Amenities', 'eltd-hotel'),
					'description'   => esc_html__('This option will enable/disable Amenities ', 'eltd-hotel'),
					'options'     => array(
						''  => esc_html__( 'Default', 'eltd-hotel' ),
						'yes' => esc_html__( 'Yes', 'eltd-hotel' ),
						'no' => esc_html__( 'No', 'eltd-hotel' ),
					),
					'parent'        => $hotel_room_meta_box,
				)
			);

			albergo_elated_add_meta_box_field(
				array(
					'name'          => 'eltd_hotel_room_enable_gallery_meta',
					'type'          => 'select',
					'default_value' => '',
					'label'         => esc_html__('Enable Gallery', 'eltd-hotel'),
					'description'   => esc_html__('This option will enable/disable Gallery ', 'eltd-hotel'),
					'options'     => array(
						''  => esc_html__( 'Default', 'eltd-hotel' ),
						'yes' => esc_html__( 'Yes', 'eltd-hotel' ),
						'no' => esc_html__( 'No', 'eltd-hotel' ),
					),
					'parent'        => $hotel_room_meta_box,
				)
			);

			albergo_elated_add_meta_box_field(
				array(
					'name'          => 'eltd_hotel_room_enable_extra_services_meta',
					'type'          => 'select',
					'default_value' => '',
					'label'         => esc_html__('Enable Extra Services', 'eltd-hotel'),
					'description'   => esc_html__('This option will enable/disable Extra Services ', 'eltd-hotel'),
					'options'     => array(
						''  => esc_html__( 'Default', 'eltd-hotel' ),
						'yes' => esc_html__( 'Yes', 'eltd-hotel' ),
						'no' => esc_html__( 'No', 'eltd-hotel' ),
					),
					'parent'        => $hotel_room_meta_box,
				)
			);

			albergo_elated_add_meta_box_field(
				array(
					'name'          => 'eltd_hotel_room_enable_location_meta',
					'type'          => 'select',
					'default_value' => '',
					'label'         => esc_html__('Enable Location', 'eltd-hotel'),
					'description'   => esc_html__('This option will enable/disable Location ', 'eltd-hotel'),
					'options'     => array(
						''  => esc_html__( 'Default', 'eltd-hotel' ),
						'yes' => esc_html__( 'Yes', 'eltd-hotel' ),
						'no' => esc_html__( 'No', 'eltd-hotel' ),
					),
					'parent'        => $hotel_room_meta_box,
				)
			);

			albergo_elated_add_meta_box_field(
				array(
					'name'          => 'eltd_hotel_room_enable_reviews_meta',
					'type'          => 'select',
					'default_value' => '',
					'label'         => esc_html__('Enable Reviews', 'eltd-hotel'),
					'description'   => esc_html__('This option will enable/disable Reviews ', 'eltd-hotel'),
					'options'     => array(
						''  => esc_html__( 'Default', 'eltd-hotel' ),
						'yes' => esc_html__( 'Yes', 'eltd-hotel' ),
						'no' => esc_html__( 'No', 'eltd-hotel' ),
					),
					'parent'        => $hotel_room_meta_box,
				)
			);

			albergo_elated_add_meta_box_field(
				array(
					'name'        => 'eltd_hotel_room_number_meta',
					'type'        => 'text',
					'label'       => esc_html__( 'Room Number', 'eltd-hotel' ),
					'description' => esc_html__( 'Enter number of hotel rooms', 'eltd-hotel' ),
					'args'        => array(
						'col_width' => 2,
					),
					'parent'      => $hotel_room_meta_box
				)
			);

			albergo_elated_add_meta_box_field(
				array(
					'name'        => 'eltd_hotel_room_price_meta',
					'type'        => 'text',
					'label'       => esc_html__( 'Price per night', 'eltd-hotel' ),
					'description' => esc_html__( 'Enter hotel room price per night', 'eltd-hotel' ),
					'args'        => array(
						'col_width' => 2,
						'suffix'    => $currency
					),
					'parent'      => $hotel_room_meta_box
				)
			);

			$eltd_capacity_group = albergo_elated_add_admin_group(
				array(
					'name'        => 'capacity_group',
					'title'       => esc_html__( 'Capacity', 'eltd-hotel' ),
					'description' => esc_html__( 'Enter capacity for hotel room', 'eltd-hotel' ),
					'parent'      => $hotel_room_meta_box
				)
			);

					$eltd_capacity_row = albergo_elated_add_admin_row(
						array(
							'name'   => 'eltd_capacity_row',
							'next'   => true,
							'parent' => $eltd_capacity_group
						)
					);

							albergo_elated_add_meta_box_field(
								array(
									'name'   => 'eltd_room_capacity_adults_meta',
									'type'   => 'textsimple',
									'label'  => esc_html__( 'Adults (Number)', 'eltd-hotel' ),
									'parent' => $eltd_capacity_row,
								)
							);

							albergo_elated_add_meta_box_field(
								array(
									'name'   => 'eltd_room_capacity_children_meta',
									'type'   => 'textsimple',
									'label'  => esc_html__( 'Children (Number)', 'eltd-hotel' ),
									'parent' => $eltd_capacity_row,
								)
							);

			do_action('eltd_hotel_room_action_meta_fields', $hotel_room_meta_box);

		}
		add_action('albergo_elated_meta_boxes_map', 'eltd_hotel_room_meta_box_map');
	}
}