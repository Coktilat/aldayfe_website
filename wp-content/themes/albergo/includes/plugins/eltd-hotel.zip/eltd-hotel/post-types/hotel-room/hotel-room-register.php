<?php
namespace ElatedHotel\CPT\HotelRoom;

use ElatedHotel\Lib;

/**
 * Class HotelRoomRegister
 * @package ElatedHotel\CPT\HotelRoom
 */

class HotelRoomRegister implements Lib\PostTypeInterface {
	/**
	 * @var string
	 */
	private $base;
	/**
	 * @var string
	 */
	private $taxBase;

	public function __construct() {
		$this->base    = 'hotel-room';
		$this->taxBase = 'hotel-room-category';

		add_action('admin_menu', array($this, 'removeLocationTagMetaBox'));
		add_action('admin_menu', array($this, 'removeExtraServicesTagMetaBox'));
		add_action('admin_menu', array($this, 'removeReviewTagMetaBox'));

		add_filter('single_template', array($this, 'registerSingleTemplate'));
	}

	/**
	 * @return string
	 */
	public function getBase() {
		return $this->base;
	}

	public function register() {
		$this->registerPostType();
		$this->registerTagTax();
	}

	/**
	 * Registers hotel room single template if one does'nt exists in theme.
	 * Hooked to single_template filter
	 * @param $single string current template
	 * @return string string changed template
	 */
	public function registerSingleTemplate($single) {
		global $post;

		if(isset($post) && $post->post_type == $this->base) {

			if(!file_exists(get_template_directory().'/single-'.$this->base.'.php')) {
				return ELTD_HOTEL_CPT_PATH.'/hotel-room/templates/single-'.$this->base.'.php';
			}
		}

		return $single;
	}

	/**
	 * Regsiters custom post type with WordPress
	 */
	private function registerPostType() {

		$menuPosition = 5;
		$menuIcon     = 'dashicons-palmtree';

		register_post_type($this->base,
			array(
				'labels'        => array(
					'name'          => __('Elated Hotel Room', 'eltd-hotel'),
					'menu_name'     => __('Elated Hotel Room', 'eltd-hotel'),
					'all_items'     => __('Elated Hotel Room Items', 'eltd-hotel'),
					'add_new'       => __('Add New Hotel Room', 'eltd-hotel'),
					'singular_name' => __('Elated Hotel Room', 'eltd-hotel'),
					'add_item'      => __('New Hotel Room Item', 'eltd-hotel'),
					'add_new_item'  => __('Add New Hotel Room Item', 'eltd-hotel'),
					'edit_item'     => __('Edit Hotel Room', 'eltd-hotel')
				),
				'public'        => true,
				'show_in_menu'  => true,
				'menu_position' => $menuPosition,
				'show_ui'       => true,
				'has_archive'   => false,
				'hierarchical'  => false,
				'supports'      => array('title', 'editor', 'thumbnail', 'page-attributes', 'excerpt', 'comments'),
				'menu_icon'     => $menuIcon
			)
		);
	}

	/**
	 * Registers custom tag taxonomy with WordPress
	 */
	private function registerTagTax() {
		$labels_extra_services = array(
			'name'              => esc_html__( 'Extra Services', 'eltd-hotel' ),
			'singular_name'     => esc_html__( 'Extra Service', 'eltd-hotel' ),
			'search_items'      => esc_html__( 'Search Extra Services', 'eltd-hotel' ),
			'all_items'         => esc_html__( 'All Extra Services', 'eltd-hotel' ),
			'parent_item'       => esc_html__( 'Parent Extra Service', 'eltd-hotel' ),
			'parent_item_colon' => esc_html__( 'Parent Extra Services:', 'eltd-hotel' ),
			'edit_item'         => esc_html__( 'Edit Extra Service', 'eltd-hotel' ),
			'update_item'       => esc_html__( 'Update Extra Service', 'eltd-hotel' ),
			'add_new_item'      => esc_html__( 'Add New Extra Service', 'eltd-hotel' ),
			'new_item_name'     => esc_html__( 'New Extra Service Name', 'eltd-hotel' ),
			'menu_name'         => esc_html__( 'Extra Services', 'eltd-hotel' )
		);

		$labels_amenities = array(
			'name'              => esc_html__( 'Amenities', 'eltd-hotel' ),
			'singular_name'     => esc_html__( 'Amenity', 'eltd-hotel' ),
			'search_items'      => esc_html__( 'Search Amenities', 'eltd-hotel' ),
			'all_items'         => esc_html__( 'All Amenities', 'eltd-hotel' ),
			'parent_item'       => esc_html__( 'Parent Amenity', 'eltd-hotel' ),
			'parent_item_colon' => esc_html__( 'Parent Amenities:', 'eltd-hotel' ),
			'edit_item'         => esc_html__( 'Edit Amenity', 'eltd-hotel' ),
			'update_item'       => esc_html__( 'Update Amenity', 'eltd-hotel' ),
			'add_new_item'      => esc_html__( 'Add New Amenity', 'eltd-hotel' ),
			'new_item_name'     => esc_html__( 'New Amenity Name', 'eltd-hotel' ),
			'menu_name'         => esc_html__( 'Amenities', 'eltd-hotel' )
		);

		$labels_locations = array(
			'name'              => esc_html__( 'Locations', 'eltd-hotel' ),
			'singular_name'     => esc_html__( 'Location', 'eltd-hotel' ),
			'search_items'      => esc_html__( 'Search Locations', 'eltd-hotel' ),
			'all_items'         => esc_html__( 'All Locations', 'eltd-hotel' ),
			'parent_item'       => esc_html__( 'Parent Location', 'eltd-hotel' ),
			'parent_item_colon' => esc_html__( 'Parent Locations:', 'eltd-hotel' ),
			'edit_item'         => esc_html__( 'Edit Location', 'eltd-hotel' ),
			'update_item'       => esc_html__( 'Update Location', 'eltd-hotel' ),
			'add_new_item'      => esc_html__( 'Add New Location', 'eltd-hotel' ),
			'new_item_name'     => esc_html__( 'New Location Name', 'eltd-hotel' ),
			'menu_name'         => esc_html__( 'Locations', 'eltd-hotel' )
		);

		$labels_review = array(
			'name'              => esc_html__('Review Criteria', 'eltd-hotel'),
			'singular_name'     => esc_html__('Review Criterion', 'eltd-hotel'),
			'search_items'      => esc_html__('Search Review Criteria', 'eltd-hotel'),
			'all_items'         => esc_html__('All Review Criteria', 'eltd-hotel'),
			'parent_item'       => esc_html__('Parent Review Criterion', 'eltd-hotel'),
			'parent_item_colon' => esc_html__('Parent Review Criterion:', 'eltd-hotel'),
			'edit_item'         => esc_html__('Edit Review Criterion', 'eltd-hotel'),
			'update_item'       => esc_html__('Update Review Criterion', 'eltd-hotel'),
			'add_new_item'      => esc_html__('Add New Review Criterion', 'eltd-hotel'),
			'new_item_name'     => esc_html__('New Review Criterion Name', 'eltd-hotel'),
			'menu_name'         => esc_html__('Review Criteria', 'eltd-hotel'),
		);

		register_taxonomy( 'extra-service-tag', array( $this->base ), array(
			'hierarchical'      => false,
			'labels'            => $labels_extra_services,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'extra-service-tag' )
		) );

		register_taxonomy( 'amenity-tag', array( $this->base ), array(
			'hierarchical'      => true,
			'labels'            => $labels_amenities,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'amenity-tag' )
		) );

		register_taxonomy( 'location-tag', array( $this->base ), array(
			'hierarchical'      => false,
			'labels'            => $labels_locations,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'location-tag' )
		) );

		register_taxonomy('review-tag', array($this->base), array(
			'hierarchical'      => true,
			'labels'            => $labels_review,
			'show_ui'           => true,
			'query_var'         => true,
			'show_admin_column' => false,
			'rewrite'           => array( 'slug' => 'review-tag' )
		));
	}

	public function removeLocationTagMetaBox() {
		// remove location tags from side metaboxes
		remove_meta_box('tagsdiv-location-tag', $this->base, 'side');
	}

	public function removeExtraServicesTagMetaBox() {
		// remove extra services tags from side metaboxes
		remove_meta_box('tagsdiv-extra-service-tag', $this->base, 'side');
	}

	public function removeReviewTagMetaBox() {
		// remove extra services tags from side metaboxes
		remove_meta_box('review-tagdiv', $this->base, 'side');
	}





}