<div class="eltd-container">

    <div class="eltd-container-inner clearfix">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <div class="eltd-hotel-room-single-holder">
                <?php if (post_password_required()) {
                    echo get_the_password_form();
                } else { ?>
                    <?php

                    do_action('albergo_elated_hotel_room_page_before_content');

                    eltd_hotel_get_cpt_single_module_template_part('templates/single/layout-collections/default', 'hotel-room', '', $params);

                    do_action('albergo_elated_hotel_room_page_after_content');

                    ?>
                <?php } ?>
            </div>
        <?php endwhile; endif; ?>
    </div>

</div>