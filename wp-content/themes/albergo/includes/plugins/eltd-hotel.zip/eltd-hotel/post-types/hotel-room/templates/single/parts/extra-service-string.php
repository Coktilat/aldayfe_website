<?php

$html = '';

switch ( $service_pack ) {
	case 'add_to_price' : {
		$html .= '<span class="eltd-label-items-value-marked">' . '+ ' . esc_attr( $price ) . esc_attr( $currency ). ' ' .'</span>';
		$html .= esc_html__('to price','eltd-hotel');
		break;
	}
	case 'add_to_price_per_night' : {
		$html .= '<span class="eltd-label-items-value-marked">' . '+ ' . esc_attr( $price ) . esc_attr( $currency ). ' ' .'</span>';
		$html .= esc_html__('to price (per night)','eltd-hotel');
		break;
	}
	case 'add_to_price_per_person' : {
		$html .= '<span class="eltd-label-items-value-marked">' . '+ ' . esc_attr( $price ) . esc_attr( $currency ). ' ' .'</span>';
		$html .= esc_html__('to price per person','eltd-hotel');
		break;
	}
	case 'add_to_price_per_person_per_night' : {
		$html .= '<span class="eltd-label-items-value-marked">' . '+ ' . esc_attr( $price ) . esc_attr( $currency ). ' ' .'</span>';
		$html .= esc_html__('to price per person per night','eltd-hotel');
		break;
	}
	case 'subtract_from_price' : {
		$html .= '<span class="eltd-label-items-value-marked">' . '- ' . esc_attr( $price ) . esc_attr( $currency ). ' ' .'</span>';
		$html .= esc_html__('from price','eltd-hotel');
		break;
	}
	case 'subtract_from_price_per_night' : {
		$html .= '<span class="eltd-label-items-value-marked">' . '- ' . esc_attr( $price ) . esc_attr( $currency ). ' ' .'</span>';
		$html .= esc_html__('from price per night','eltd-hotel');
		break;
	}
	case 'increase_price_by_percent_amount' : {
		$html .='<span class="eltd-label-items-value-marked">'. '+ ' . esc_attr( $percent ). ' ' .'</span>';
		$html .= esc_html__('to price','eltd-hotel');
		break;
	}
	case 'decrease_price_by_percent_amount' : {
		$html .= '<span class="eltd-label-items-value-marked">'. '- ' . esc_attr( $percent ). ' ' . '</span>';
		$html .= esc_html__('from price','eltd-hotel');
		break;
	}
	default : {

	}
		break;
}

print $html;
