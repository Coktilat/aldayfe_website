<?php
$max_children = eltd_hotel_get_hotel_room_max_children();
?>
<?php if ( $max_children != '' ) { ?>
    <div class="eltd-filter-section eltd-filter-section-12 eltd-section-children">
        <div class="eltd-filter-children-count-holder" data-children="<?php echo esc_attr($params['room_children']) ?>">
            <label for="eltd-filter-children"><?php esc_html_e( 'Children', 'eltd-hotel' ) ?></label>
            <select id="eltd-filter-children" name="eltd-filter-children" class="eltd-filter-children">
                <option value="0">0</option>
	            <?php for ( $i = 1; $i <= $max_children; $i ++ ) { ?>
                    <option <?php echo ($params['room_children'] == $i) ? 'selected' : ''; ?>
                            value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
	            <?php } ?>
            </select>
        </div>
    </div>
<?php } ?>