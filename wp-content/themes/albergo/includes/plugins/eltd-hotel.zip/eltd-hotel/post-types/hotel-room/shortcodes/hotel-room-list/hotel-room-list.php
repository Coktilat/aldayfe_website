<?php

namespace ElatedHotel\CPT\Shortcodes\HotelRoomList;

use ElatedHotel\Lib;

class HotelRoomList implements Lib\ShortcodeInterface {
    private $base;

    public function __construct() {
        $this->base = 'eltd_hotel_room_list';

        add_action( 'vc_before_init', array( $this, 'vcMap' ) );

	    //Room List Location filter
	    add_filter( 'vc_autocomplete_eltd_hotel_room_list_room_location_callback', array( &$this, 'roomLocationAutocompleteSuggester', ), 10, 1 ); // Get suggestion(find). Must return an array

	    //Room List Location render
	    add_filter( 'vc_autocomplete_eltd_hotel_room_list_room_location_render', array( &$this, 'roomLocationAutocompleteRender', ), 10, 1 ); // Render exact room. Must return an array (label,value)

	    //Room List Extra Services filter
	    add_filter( 'vc_autocomplete_eltd_hotel_room_list_room_extra_services_callback', array( &$this, 'roomExtraServicesAutocompleteSuggester', ), 10, 1 ); // Get suggestion(find). Must return an array

	    //Room List Extra Services render
	    add_filter( 'vc_autocomplete_eltd_hotel_room_list_room_extra_services_render', array( &$this, 'roomExtraServicesAutocompleteRender', ), 10, 1 ); // Render exact room. Must return an array (label,value)

	    //Room List Amenities filter
	    add_filter( 'vc_autocomplete_eltd_hotel_room_list_room_amenities_callback', array( &$this, 'roomAmenitiesAutocompleteSuggester', ), 10, 1 ); // Get suggestion(find). Must return an array

	    //Room List Amenities render
	    add_filter( 'vc_autocomplete_eltd_hotel_room_list_room_amenities_render', array( &$this, 'roomAmenitiesAutocompleteRender', ), 10, 1 ); // Render exact room. Must return an array (label,value)


    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        if ( function_exists( 'vc_map' ) ) {
            vc_map( array(
                    'name'                      => esc_html__( 'Elated Hotel Room List', 'eltd-hotel' ),
                    'base'                      => $this->getBase(),
                    'category'                  => esc_html__( 'BY ELATED HOTEL', 'eltd-hotel' ),
                    'icon'                      => 'icon-wpb-hotel-room-list extended-custom-hotel-room-icon',
                    'allowed_container_element' => 'vc_row',
                    'params'                    => array(
	                    array(
		                    'type'        => 'dropdown',
		                    'param_name'  => 'type',
		                    'heading'     => esc_html__( 'Type', 'eltd-hotel' ),
		                    'value'       => array(
			                    esc_html__( 'Standard', 'eltd-hotel' ) => 'standard',
		                    	esc_html__( 'Gallery', 'eltd-hotel' )  => 'gallery',
			                    esc_html__( 'Divided', 'eltd-hotel' )   => 'divided',
		                    ),
		                    'save_always' => true
	                    ),
	                    array(
		                    'type'        => 'dropdown',
		                    'param_name'  => 'gallery_hover',
		                    'heading'     => esc_html__( 'Hover', 'eltd-hotel' ),
		                    'value'       => array(
			                    esc_html__( 'Default', 'eltd-hotel' ) => 'standard',
			                    esc_html__( 'Slide from bottom ', 'eltd-hotel' )  => 'slide_from_bottom'
		                    ),
		                    'save_always' => true,
		                    'dependency'  => array( 'element' => 'type', 'value' => array( 'gallery' ) ),
	                    ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'number_of_columns',
                            'heading'     => esc_html__( 'Number of Columns', 'eltd-hotel' ),
                            'value'       => array(
                                esc_html__( 'Default', 'eltd-hotel' ) => '',
                                esc_html__( 'One', 'eltd-hotel' )     => '1',
                                esc_html__( 'Two', 'eltd-hotel' )     => '2',
                                esc_html__( 'Three', 'eltd-hotel' )   => '3',
                                esc_html__( 'Four', 'eltd-hotel' )    => '4',
                                esc_html__( 'Five', 'eltd-hotel' )    => '5'
                            ),
                            'description' => esc_html__( 'Default value is Three', 'eltd-hotel' ),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'space_between_items',
                            'heading'     => esc_html__( 'Space Between Room', 'eltd-hotel' ),
                            'value'       => array_flip( albergo_elated_get_space_between_items_array() ),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'number_of_items',
                            'heading'     => esc_html__( 'Number of Rooms Per Page', 'eltd-hotel' ),
                            'description' => esc_html__( 'Set number of rooms for your hotel room list. Enter -1 to show all.', 'eltd-hotel' ),
                            'value'       => '-1'
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'image_proportions',
                            'heading'     => esc_html__( 'Image Proportions', 'eltd-hotel' ),
                            'value'       => array(
                                esc_html__( 'Original', 'eltd-hotel' )  => 'full',
                                esc_html__( 'Square', 'eltd-hotel' )    => 'square',
                                esc_html__( 'Landscape', 'eltd-hotel' ) => 'landscape',
                                esc_html__( 'Portrait', 'eltd-hotel' )  => 'portrait',
                                esc_html__( 'Thumbnail', 'eltd-hotel' ) => 'thumbnail',
                                esc_html__( 'Medium', 'eltd-hotel' )    => 'medium',
                                esc_html__( 'Large', 'eltd-hotel' )     => 'large',
                                esc_html__( 'Custom', 'eltd-hotel' )     => 'custom'
                            ),
                            'description' => esc_html__( 'Set image proportions for your hotel room list.', 'eltd-hotel' ),
                        ),
	                    array(
		                    'type'        => 'textfield',
		                    'param_name'  => 'custom_image_width',
		                    'heading'     => esc_html__( 'Custom Image Width', 'eltd-hotel' ),
		                    'dependency'  => array( 'element' => 'image_proportions', 'value' => array( 'custom' ) ),
		                    'value'       => ''
	                    ),
	                    array(
		                    'type'        => 'textfield',
		                    'param_name'  => 'custom_image_height',
		                    'heading'     => esc_html__( 'Custom Image Height', 'eltd-hotel' ),
		                    'dependency'  => array( 'element' => 'image_proportions', 'value' => array( 'custom' ) ),
		                    'value'       => ''
	                    ),
                        array(
                            'type'        => 'autocomplete',
                            'param_name'  => 'room_location',
                            'heading'     => esc_html__( 'Location', 'eltd-hotel' ),
                            'value'       => array_flip(eltd_hotel_get_taxonomy_list('location-tag', true)),
                            'settings'    => array(
                                'multiple'      => true,
                                'sortable'      => true,
                                'unique_values' => true
                            )
                        ),
                        array(
                            'type'        => 'autocomplete',
                            'param_name'  => 'room_amenities',
                            'heading'     => esc_html__( 'Amenities', 'eltd-hotel' ),
                            'value'       => array_flip(eltd_hotel_get_taxonomy_list('amenity-tag', true)),
                            'settings'    => array(
	                            'multiple'      => true,
	                            'sortable'      => true,
	                            'unique_values' => true
                            )
                        ),
                        array(
                            'type'        => 'autocomplete',
                            'param_name'  => 'room_extra_services',
                            'heading'     => esc_html__( 'Extra Services', 'eltd-hotel' ),
                            'value'       => array_flip(eltd_hotel_get_taxonomy_list('extra-service-tag', true)),
                            'settings'    => array(
	                            'multiple'      => true,
	                            'sortable'      => true,
	                            'unique_values' => true
                            )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'order_by',
                            'heading'     => esc_html__( 'Order By', 'eltd-hotel' ),
                            'value'       => array_flip( albergo_elated_get_query_order_by_array() ),
                            'save_always' => true
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'order',
                            'heading'     => esc_html__( 'Order', 'eltd-hotel' ),
                            'value'       => array_flip( albergo_elated_get_query_order_array() ),
                            'save_always' => true
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'title_tag',
                            'heading'    => esc_html__( 'Title Tag', 'eltd-hotel' ),
                            'value'      => array_flip( albergo_elated_get_title_tag( true ) ),
                            'group'      => esc_html__( 'Content Layout', 'eltd-hotel' ),
                        ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'enable_filter',
                            'heading'    => esc_html__( 'Enable Filter', 'eltd-hotel' ),
                            'value'      => array_flip( albergo_elated_get_yes_no_select_array()),
                            'group'      => esc_html__( 'Additional Features', 'eltd-hotel' )
                        ),
	                    array(
		                    'type'       => 'dropdown',
		                    'param_name' => 'enable_sort',
		                    'heading'    => esc_html__( 'Enable Sort', 'eltd-hotel' ),
		                    'value'      => array_flip( albergo_elated_get_yes_no_select_array()),
		                    'group'      => esc_html__( 'Additional Features', 'eltd-hotel' )
	                    ),
	                    array(
		                    'type'       => 'dropdown',
		                    'param_name' => 'enable_excerpt',
		                    'heading'    => esc_html__( 'Enable Excerpt', 'eltd-hotel' ),
		                    'value'      => array_flip( albergo_elated_get_yes_no_select_array( false ) ),
		                    'group'      => esc_html__( 'Content Layout', 'eltd-hotel' )
	                    ),
	                    array(
		                    'type'        => 'textfield',
		                    'param_name'  => 'excerpt_length',
		                    'heading'     => esc_html__( 'Excerpt Length', 'eltd-hotel' ),
		                    'description' => esc_html__( 'Number of characters', 'eltd-hotel' ),
		                    'dependency'  => array( 'element' => 'enable_excerpt', 'value' => array( 'yes' ) ),
		                    'group'       => esc_html__( 'Content Layout', 'eltd-hotel' )
	                    ),
                        array(
                            'type'       => 'dropdown',
                            'param_name' => 'pagination_type',
                            'heading'    => esc_html__( 'Pagination Type', 'eltd-hotel' ),
                            'value'      => array(
                                esc_html__( 'None', 'eltd-hotel' )            => 'no-pagination',
                                esc_html__( 'Standard', 'eltd-hotel' )        => 'standard',
                                esc_html__( 'Load More', 'eltd-hotel' )       => 'load-more',
                                esc_html__( 'Infinite Scroll', 'eltd-hotel' ) => 'infinite-scroll'
                            ),
                            'group'      => esc_html__( 'Additional Features', 'eltd-hotel' )
                        ),
                        array(
                            'type'       => 'textfield',
                            'param_name' => 'load_more_top_margin',
                            'heading'    => esc_html__( 'Load More Top Margin (px or %)', 'eltd-hotel' ),
                            'dependency' => array( 'element' => 'pagination_type', 'value' => array( 'load-more' ) ),
                            'group'      => esc_html__( 'Additional Features', 'eltd-hotel' )
                        )
                    )
                )
            );
        }
    }

    /**
     * Renders shortcodes HTML
     *
     * @param $atts array of shortcode params
     * @param $content string shortcode content
     *
     * @return string
     */
    public function render($atts, $content = null) {
        $args = array(
	        'type'                      => 'standard',
	        'gallery_hover'             => '',
	        'number_of_columns'         => '3',
	        'space_between_items'       => 'normal',
	        'number_of_items'           => '-1',
	        'image_proportions'         => 'full',
	        'custom_image_width'        => '',
	        'custom_image_height'       => '',
	        'room_location'             => '',
	        'room_amenities'            => '',
	        'room_extra_services'       => '',
	        'room_min_date'             => '',
	        'room_max_date'             => '',
	        'room_min_price'            => '',
	        'room_max_price'            => '',
	        'room_adults'               => '',
	        'room_children'             => '',
	        'room_number_of_rooms'      => '',
	        'sort_option'               => '',
	        'order_by'                  => 'date',
	        'order'                     => 'DESC',
	        'title_tag'                 => 'h5',
	        'enable_excerpt'            => 'no',
	        'excerpt_length'            => '20',
	        'pagination_type'           => 'no-pagination',
	        'load_more_top_margin'      => '',
	        'enable_filter'             => 'no',
	        'enable_sort'               => 'no',
        );
        $params = shortcode_atts($args, $atts);

        /***
         * @params query_results
         * @params holder_data
         * @params holder_classes
         * @params holder_inner_classes
         */
        $additional_params = array();

        $query_array                        = $this->getQueryArray( $params );
        $query_results                      = new \WP_Query( $query_array );
        $additional_params['query_results'] = $query_results;

        $additional_params['holder_data'] = $this->getHolderData( $params, $additional_params );
        $additional_params['holder_classes'] = $this->getHolderClasses( $params );
        $additional_params['holder_inner_classes'] = $this->getHolderInnerClasses( $params );

        $params['this_object'] = $this;

        $html = eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'holder', '', $params, $additional_params);

        return $html;
    }

    /**
     * Generates hotel room list query attribute array
     *
     * @param $params
     *
     * @return array
     */

    public function getQueryArray($params){
	    $query_array = array(
		    'post_status'    => 'publish',
		    'post_type'      => 'hotel-room',
		    'posts_per_page' => $params['number_of_items']
	    );

	    switch ($params['sort_option']) {
		    case 'price-low' : {
			    $query_array['meta_key'] = 'eltd_hotel_room_price_meta';
			    $query_array['orderby'] = 'meta_value_num';
			    $query_array['order'] = 'ASC';
		    }
			    break;
		    case 'price-high' : {
			    $query_array['meta_key'] = 'eltd_hotel_room_price_meta';
			    $query_array['orderby'] = 'meta_value_num';
			    $query_array['order'] = 'DESC';
		    }
			    break;
		    case 'date' : {
			    $query_array['orderby'] = 'date';
			    $query_array['order'] = 'ASC';
		    }
			    break;
		    case 'name' : {
			    $query_array['orderby'] = 'name';
			    $query_array['order'] = 'ASC';
		    }
			    break;
		    case 'name-x' : {
			    $query_array['orderby'] = 'DESC';
			    $query_array['order'] = 'name';
		    }
			    break;
		    default : {
			    $query_array['orderby'] = $params['order_by'];
			    $query_array['order'] = $params['order'];
		    }
			    break;
	    }

	    // TAXONOMY QUERY VALUES
	    if ( ! empty( $params['room_location'] ) || ! empty( $params['room_amenities'] ) || ! empty( $params['room_extra_services'] )) {
		    $tax_query = array();

		    if ( ! empty( $params['room_location'] ) ) {
			    $tax_query[] = array(
				    'taxonomy'  => 'location-tag',
				    'terms'     => $params['room_location'],
				    'operator' => 'AND',
			    );
		    }

		    if ( ! empty( $params['room_amenities'] ) ) {
			    $tax_query[] = array(
				    'taxonomy'  => 'amenity-tag',
				    'terms'     => $params['room_amenities'],
				    'operator' => 'AND',
			    );
		    }

		    if ( ! empty( $params['room_extra_services'] ) ) {
			    $tax_query[] = array(
				    'taxonomy'  => 'extra-service-tag',
				    'terms'     => $params['room_extra_services'],
				    'operator' => 'AND'
			    );
		    }

		    $query_array['tax_query'] = $tax_query;
	    }

	    // META QUERY VALUES
	    if ( ! empty( $params['room_min_price'] ) || ! empty( $params['room_max_price'] ) || ! empty( $params['room_number_of_rooms'] ) ) {
		    $meta_query = array();

		    if ( ! empty( $params['room_min_price'] ) || ! empty( $params['room_max_price'] ) ) {
			    $min_price = 0;
			    $max_price = eltd_hotel_get_hotel_room_max_price_value();
			    if ( ! empty( $params['room_min_price'] ) ) {
				    $min_price = $params['room_min_price'];

			    }
			    if ( ! empty( $params['room_max_price'] ) ) {
				    $max_price = $params['room_max_price'];
			    }
			    $meta_query[] = array(
				    'key' => 'eltd_hotel_room_price_meta',
				    'value' => array( $min_price, $max_price ),
				    'type' => 'numeric',
				    'compare' => 'BETWEEN'
			    );
		    }

		    if ( ! empty( $params['room_number_of_rooms'] ) ) {

			    $room_number_of_rooms = $params['room_number_of_rooms'];

			    $meta_query[] = array(
				    'key' => 'eltd_hotel_room_number_meta',
				    'value' => $room_number_of_rooms,
				    'type' => 'numeric',
				    'compare' => '>='
			    );
		    }

		    if ( ! empty( $params['room_adults'] ) ) {

			    $room_adults = $params['room_adults'];

			    $meta_query[] = array(
				    'key' => 'eltd_room_capacity_adults_meta',
				    'value' => $room_adults,
				    'type' => 'numeric',
				    'compare' => '>='
			    );
		    }

		    if ( ! empty( $params['room_children'] ) ) {

			    $room_children = $params['room_children'];

			    $meta_query[] = array(
				    'key' => 'eltd_room_capacity_children_meta',
				    'value' => $room_children,
				    'type' => 'numeric',
				    'compare' => '>='
			    );
		    }

		    $query_array['meta_query'] = $meta_query;
	    }

	    if(!empty($params['next_page'])){
		    $query_array['paged'] = $params['next_page'];
	    } else {
		    $query_array['paged'] = 1;
	    }

	    return $query_array;
    }


    /**
     * Generates data attributes array
     *
     * @param $params
     * @param $additional_params
     *
     * @return string
     */

    public function getHolderData($params, $additional_params){
        $dataString = '';

        if(get_query_var('paged')) {
            $paged = get_query_var('paged');
        } elseif(get_query_var('page')) {
            $paged = get_query_var('page');
        } else {
            $paged = 1;
        }

        $query_results = $additional_params['query_results'];
        $params['max_num_pages'] = $query_results->max_num_pages;

        if(!empty($paged)) {
            $params['next_page'] = $paged+1;
        }

        foreach ($params as $key => $value) {
            if($value !== '') {
                $new_key = str_replace( '_', '-', $key );

                $dataString .= ' data-'.$new_key.'="'.esc_attr($value) . '"';
            }
        }

        return $dataString;
    }


    /**
     * Generates hotel room holder classes
     *
     * @param $params
     *
     * @return string
     */

    public function getHolderClasses( $params ) {
        $classes = array();

        $classes[] = ! empty( $params['type'] ) ? 'eltd-hrl-' . $params['type'] : 'eltd-hrl-standard';
        if($params['type'] == 'gallery') {
        	switch ($params['gallery_hover']){
        		case 'slide_from_bottom' : {
			        $classes[] = 'eltd-hrl-gallery-hover-sfb';
		        } break;
		        case 'standard' : {
			        $classes[] = 'eltd-hrl-gallery-hover-st';
		        } break;
		        default : {
			        $classes[] = 'eltd-hrl-gallery-hover-st';
		        }
            }

        }
        $classes[] = ! empty( $params['space_between_items'] ) ? 'eltd-' . $params['space_between_items'] . '-space' : 'eltd-normal-space';
        $classes[] = ! empty( $params['enable_filter'] ) && $params['enable_filter'] == 'yes' ? 'eltd-hrl-with-filter' : '';
        $classes[] = ! empty( $params['room_location'] )  ? 'eltd-hrl-location-set' : '';
        $classes[] = ! empty( $params['room_amenity'] )  ? 'eltd-hrl-amenity-set' : '';

        $number_of_columns = $params['number_of_columns'];
        switch ( $number_of_columns ):
            case '1':
                $classes[] = 'eltd-hrl-one-column';
                break;
            case '2':
                $classes[] = 'eltd-hrl-two-columns';
                break;
            case '3':
                $classes[] = 'eltd-hrl-three-columns';
                break;
            case '4':
                $classes[] = 'eltd-hrl-four-columns';
                break;
            case '5':
                $classes[] = 'eltd-hrl-five-columns';
                break;
            default:
                $classes[] = 'eltd-hrl-three-columns';
                break;
        endswitch;

        $classes[] = ! empty( $params['pagination_type'] ) ? 'eltd-hrl-pag-' . $params['pagination_type'] : '';

        return implode( ' ', $classes );
    }


    /**
     * Generates hotel room holder inner classes
     *
     * @param $params
     *
     * @return string
     */

    public function getHolderInnerClasses($params){
        $classes = array();

        $classes[] = 'eltd-outer-space';

        //$classes[] = $params['hotel_room_slider_on'] === 'yes' ? 'eltd-owl-slider eltd-hrl-is-slider' : '';

        return implode(' ', $classes);
    }


    /**
     * Generates hotel room article classes
     *
     *
     * @return string
     */

    public function getArticleClasses($params){
        $classes = array();

        $classes[] = 'eltd-item-space';

        $item_featured = get_post_meta( get_the_ID(), 'eltd_hotel_room_is_featured_meta', true);
        $classes[] = ! empty( $item_featured ) && $item_featured === 'yes' ? 'eltd-item-featured' : '';

        $article_classes = get_post_class($classes);

        return implode(' ', $article_classes);
    }


    /**
     * Generates hotel room image size
     *
     * @param $params
     *
     * @return string
     */

    public function getImageSize($params){
        $thumb_size = 'full';

        if ( ! empty( $params['image_proportions'] ) ) {
            $image_size = $params['image_proportions'];

            switch ( $image_size ) {
                case 'landscape':
                    $thumb_size = 'albergo_elated_landscape';
                    break;
                case 'portrait':
                    $thumb_size = 'albergo_elated_portrait';
                    break;
                case 'square':
                    $thumb_size = 'albergo_elated_square';
                    break;
                case 'thumbnail':
                    $thumb_size = 'thumbnail';
                    break;
                case 'medium':
                    $thumb_size = 'medium';
                    break;
                case 'large':
                    $thumb_size = 'large';
                    break;
                case 'full':
                    $thumb_size = 'full';
                    break;
	            case 'custom':
		            $thumb_size = 'custom';
		            break;
            }
        }

        return $thumb_size;
    }

    /**
     * Returns array of load more element styles
     *
     * @param $params
     *
     * @return array
     */

    public function getLoadMoreStyles($params) {
        $styles = array();

        if (!empty($params['load_more_top_margin'])) {
            $margin = $params['load_more_top_margin'];

            if(albergo_elated_string_ends_with($margin, '%') || albergo_elated_string_ends_with($margin, 'px')) {
                $styles[] = 'margin-top: '.$margin;
            } else {
                $styles[] = 'margin-top: '.albergo_elated_filter_px($margin).'px';
            }
        }

        return implode(';', $styles);
    }


	/**
	 * Filter room list location
	 *
	 * @param $query
	 *
	 * @return array
	 */
	public function roomLocationAutocompleteSuggester( $query ) {
		global $wpdb;
		$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT a.slug AS slug, a.name AS room_location_title, a.term_id as termid
					FROM {$wpdb->terms} AS a
					LEFT JOIN ( SELECT term_id, taxonomy  FROM {$wpdb->term_taxonomy} ) AS b ON b.term_id = a.term_id
					WHERE b.taxonomy = 'location-tag' AND a.name LIKE '%%%s%%'", stripslashes( $query ) ), ARRAY_A );

		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = array();
				$data['value'] = $value['termid'];
				$data['label'] = ( ( strlen( $value['room_location_title'] ) > 0 ) ? esc_html__( 'Location', 'eltd-hotel' ) . ': ' . $value['room_location_title'] : '' );
				$results[]     = $data;
			}
		}

		return $results;
	}

	/**
	 * Find room list location by slug
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function roomLocationAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // get value from requested
		if ( ! empty( $query ) ) {
			// get room location
			$room_location = get_term_by( 'slug', $query, 'location-tag' );
			if ( is_object( $room_location ) ) {

				$room_location_slug  = $room_location->slug;
				$room_location_title = $room_location->name;

				$room_location_title_display = '';
				if ( ! empty( $room_location_title ) ) {
					$room_location_title_display = esc_html__( 'Location', 'eltd-hotel' ) . ': ' . $room_location_title;
				}

				$data          = array();
				$data['value'] = $room_location_slug;
				$data['label'] = $room_location_title_display;

				return ! empty( $data ) ? $data : false;
			}

			return false;
		}

		return false;
	}

	/**
	 * Filter room list extra service
	 *
	 * @param $query
	 *
	 * @return array
	 */
	public function roomExtraServicesAutocompleteSuggester( $query ) {
		global $wpdb;
		$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT a.slug AS slug, a.name AS room_extra_service_title, a.term_id as termid
					FROM {$wpdb->terms} AS a
					LEFT JOIN ( SELECT term_id, taxonomy  FROM {$wpdb->term_taxonomy} ) AS b ON b.term_id = a.term_id
					WHERE b.taxonomy = 'extra-service-tag' AND a.name LIKE '%%%s%%'", stripslashes( $query ) ), ARRAY_A );

		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = array();
				$data['value'] = $value['termid'];
				$data['label'] = ( ( strlen( $value['room_extra_service_title'] ) > 0 ) ? esc_html__( 'Extra Service', 'eltd-hotel' ) . ': ' . $value['room_extra_service_title'] : '' );
				$results[]     = $data;
			}
		}

		return $results;
	}

	/**
	 * Find room list extra service by slug
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function roomExtraServicesAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // get value from requested
		if ( ! empty( $query ) ) {
			// get room extra service
			$room_extra_service = get_term_by( 'slug', $query, 'extra-service-tag' );
			if ( is_object( $room_extra_service ) ) {

				$room_extra_service_slug  = $room_extra_service->slug;
				$room_extra_service_title = $room_extra_service->name;

				$room_extra_service_title_display = '';
				if ( ! empty( $room_extra_service_title ) ) {
					$room_extra_service_title_display = esc_html__( 'Extra Service', 'eltd-hotel' ) . ': ' . $room_extra_service_title;
				}

				$data          = array();
				$data['value'] = $room_extra_service_slug;
				$data['label'] = $room_extra_service_title_display;

				return ! empty( $data ) ? $data : false;
			}

			return false;
		}

		return false;
	}

	/**
	 * Filter room list amenity
	 *
	 * @param $query
	 *
	 * @return array
	 */
	public function roomAmenitiesAutocompleteSuggester( $query ) {
		global $wpdb;
		$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT a.slug AS slug, a.name AS room_amenity_title, a.term_id as termid
					FROM {$wpdb->terms} AS a
					LEFT JOIN ( SELECT term_id, taxonomy  FROM {$wpdb->term_taxonomy} ) AS b ON b.term_id = a.term_id
					WHERE b.taxonomy = 'amenity-tag' AND a.name LIKE '%%%s%%'", stripslashes( $query ) ), ARRAY_A );

		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data          = array();
				$data['value'] = $value['termid'];
				$data['label'] = ( ( strlen( $value['room_amenity_title'] ) > 0 ) ? esc_html__( 'Amenity', 'eltd-hotel' ) . ': ' . $value['room_amenity_title'] : '' );
				$results[]     = $data;
			}
		}

		return $results;
	}

	/**
	 * Find room list amenity by slug
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function roomAmenitiesAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // get value from requested
		if ( ! empty( $query ) ) {
			// get room amenity
			$room_amenity = get_term_by( 'slug', $query, 'amenity-tag' );
			if ( is_object( $room_amenity ) ) {

				$room_amenity_slug  = $room_amenity->slug;
				$room_amenity_title = $room_amenity->name;

				$room_amenity_title_display = '';
				if ( ! empty( $room_amenity_title ) ) {
					$room_amenity_title_display = esc_html__( 'Amenity', 'eltd-hotel' ) . ': ' . $room_amenity_title;
				}

				$data          = array();
				$data['value'] = $room_amenity_slug;
				$data['label'] = $room_amenity_title_display;

				return ! empty( $data ) ? $data : false;
			}

			return false;
		}

		return false;
	}
}