<?php extract( apply_filters( 'albergo_elated_hotel_single_google_map_params', array() ) ); ?>
<div class="eltd-hotel-room-map eltd-hotel-room-label-items-holder">
	<div class="eltd-hotel-room-map-items eltd-hotel-room-items-style clearfix">

        <h4>
			<?php esc_html_e( 'Location', 'eltd-hotel' ); ?>
        </h4>

		<div class="eltd-hotel-room-map-object">
			<?php echo albergo_elated_execute_shortcode('eltd_google_map', $google_map_params); ?>
		</div>
	</div>
</div>