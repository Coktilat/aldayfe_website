<div class="eltd-hrl-holder <?php echo esc_attr( $holder_classes ); ?>" <?php echo wp_kses( $holder_data, array( 'data' ) ); ?>>
	<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'sort/sort', '', $params, $additional_params ); ?>
	<div class="eltd-grid-row">
        <div class="eltd-hrl-items-part
        <?php if(isset($params['enable_filter']) && $params['enable_filter'] === 'yes') { ?>
                eltd-grid-col-9
            <?php } else { ?>
                eltd-grid-col-12
            <?php } ?>">
			<div class="eltd-hrl-inner <?php echo esc_attr( $holder_inner_classes ); ?> clearfix">
				<?php
				if ( $query_results->have_posts() ):
					while ( $query_results->have_posts() ) : $query_results->the_post();
						echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'item', '', $params, $additional_params );
					endwhile;
				else:
					echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/posts-not-found' );
				endif;

				wp_reset_postdata();
				?>
			</div>
			<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'pagination/' . $pagination_type, '', $params, $additional_params ); ?>
		</div>
		<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/holder', '', $params, $additional_params ); ?>
	</div>
</div>