<?php extract(apply_filters('albergo_elated_hotel_single_active_tabs_params', array()));
?>
<?php echo eltd_hotel_get_cpt_single_module_template_part('templates/single/parts/title', 'hotel-room', '', $params); ?>
<div class="eltd-grid-row">
    <div class="eltd-grid-col-9">
        <div class="eltd-hotel-room-single-outer">

            <?php

            if ($featured_item == 'slider') {
                echo eltd_hotel_get_cpt_single_module_template_part('templates/single/parts/slider', 'hotel-room', '', $params);
            } else {
                echo eltd_hotel_get_cpt_single_module_template_part('templates/single/parts/featured-image', 'hotel-room', '', $params);
            }

            ?>

            <div class="eltd-hr-item-wrapper eltd-tabs eltd-horizontal eltd-tab-text">

                <ul class="eltd-tabs-nav clearfix">
                    <?php foreach ($hotel_tabs as $hotel_tab) { ?>

                        <li class="eltd-hotel-room-nav-item">

                            <a href="<?php echo esc_attr($hotel_tab['id']) ?>">

                                        <span class="eltd-hotel-room-nav-section-title">
                                            <?php echo esc_html($hotel_tab['title']) ?>
                                        </span>

                            </a>
                        </li>
                    <?php }; ?>
                </ul>

                <div class="eltd-hr-item-section eltd-tab-container"
                     id="<?php echo esc_attr($hotel_tabs['description']['id']) ?>">
                    <?php

                    echo eltd_hotel_get_cpt_single_module_template_part('templates/single/parts/description', 'hotel-room', '', $params);

                    if ($hotel_info['amenities'] == 'yes') {

                        echo eltd_hotel_get_cpt_single_module_template_part('templates/single/parts/amenities', 'hotel-room', '', $params);
                    }

                    if ($hotel_info['extra_services'] == 'yes') {

                        echo eltd_hotel_get_cpt_single_module_template_part('templates/single/parts/extra-services', 'hotel-room', '', $params);
                    }


                    ?>
                </div>

                <?php if ($hotel_info['gallery'] == 'yes') { ?>
                    <div class="eltd-hr-item-section eltd-tab-container"
                         id="<?php echo esc_attr($hotel_tabs['gallery']['id']) ?>">
                        <?php

                        echo eltd_hotel_get_cpt_single_module_template_part('templates/single/parts/gallery', 'hotel-room', '', $params);

                        ?>
                    </div>

                <?php } ?>

                <?php if ($hotel_info['location'] == 'yes') { ?>
                    <div class="eltd-hr-item-section eltd-tab-container"
                         id="<?php echo esc_attr($hotel_tabs['location']['id']) ?>">
                        <?php

                        echo eltd_hotel_get_cpt_single_module_template_part('templates/single/parts/google-map', 'hotel-room', '', $params);
                        echo eltd_hotel_get_cpt_single_module_template_part('templates/single/parts/location', 'hotel-room', '', $params);

                        ?>
                    </div>

                <?php } ?>

                <?php if ($hotel_info['reviews'] == 'yes') { ?>
                    <div class="eltd-hr-item-section eltd-tab-container"
                         id="<?php echo esc_attr($hotel_tabs['reviews']['id']) ?>">
                        <?php

                        echo eltd_hotel_get_cpt_single_module_template_part('templates/single/parts/reviews', 'hotel-room', '', $params);

                        ?>
                    </div>

                <?php } ?>

            </div>
        </div>
    </div>
    <div class="eltd-grid-col-3">
        <?php
        echo eltd_hotel_get_cpt_single_module_template_part('templates/single/parts/reservation', 'hotel-room', '', $params);
        dynamic_sidebar('hotel-room-single-sidebar'); ?>
    </div>
</div>