<?php extract( apply_filters( 'albergo_elated_hotel_single_extra_services_params', array() ) );
if ( ( isset( $extra_services ) && count( $extra_services ) > 0 )) {
	?>
    <div class="eltd-hotel-room-extra-service eltd-hotel-room-label-items-holder">
        <div class="eltd-hotel-room-extra-service-label eltd-hotel-room-label-style">
            <h4>
				<?php esc_html_e( 'Extra Service', 'eltd-hotel' ); ?>
            </h4>
        </div>
        <div class="eltd-hotel-room-extra-service-items eltd-hotel-room-items-style clearfix">
            <div class="eltd-grid-row">
				<?php foreach ( $extra_services as $extra_service ) { ?>
                    <div class="eltd-grid-col-12">
                        <div class="eltd-tag-item eltd-label-items-item">
                            <h6 class="eltd-label-items-label eltd-tag-item-name">
	                            <?php echo esc_attr( $extra_service['name'] ); ?>
                            </h6>
                            <div class="eltd-dot-item"></div>
                            <span class="eltd-label-items-value eltd-tag-item-service">
                            <?php echo eltd_hotel_room_get_extra_service_string( $extra_service );
                            if ( eltd_hotel_room_get_extra_service_type( $extra_service ) ) {
	                            esc_html_e( ' (*Mandatory)', 'eltd-hotel' );
                            }
                            ?>
                            </span>
                        </div>
	                    <?php echo esc_attr( $extra_service['description']); ?>
                    </div>
				<?php } ?>
            </div>
        </div>
    </div>
<?php }