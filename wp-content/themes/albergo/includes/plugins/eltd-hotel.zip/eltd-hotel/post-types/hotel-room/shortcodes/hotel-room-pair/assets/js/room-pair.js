(function($) {
    'use strict';

    var hotelRoomPair = {};
    eltd.modules.hotelRoomPair = hotelRoomPair;

    hotelRoomPair.eltdOnDocumentReady = eltdOnDocumentReady;
    hotelRoomPair.eltdOnWindowLoad = eltdOnWindowLoad;
    hotelRoomPair.eltdOnWindowResize = eltdOnWindowResize;
    hotelRoomPair.eltdOnWindowScroll = eltdOnWindowScroll;

    $(document).ready(eltdOnDocumentReady);
    $(window).load(eltdOnWindowLoad);
    $(window).resize(eltdOnWindowResize);
    $(window).scroll(eltdOnWindowScroll);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function eltdOnDocumentReady() {
    }

    /*
     All functions to be called on $(window).load() should be in this function
     */
    function eltdOnWindowLoad() {
        eltdParallaxElements();

    }

    /*
     All functions to be called on $(window).resize() should be in this function
     */
    function eltdOnWindowResize() {

    }

    /*
     All functions to be called on $(window).scroll() should be in this function
     */
    function eltdOnWindowScroll() {
    }

    /**
     * Parallax Elements Instances
     */
    function eltdParallaxElements() {
        var parallaxElements = $('.eltd-hrp-inner');

        if (parallaxElements.length && !eltd.htmlEl.hasClass('touch')) {
            parallaxElements.each(function(){
                var parallaxElement = $(this),
                    randCoeff = (Math.floor(Math.random() * 2) + 1 ) * 0.1,
                    delta = -Math.round(parallaxElement.height() * randCoeff),
                    dataParallax = '{"y":'+delta+', "smoothness":20}';

                parallaxElement.attr('data-parallax', dataParallax);
            });

            setTimeout(function(){
                ParallaxScroll.init(); //initialzation removed from plugin js file to have it run only on non-touch devices
            }, 100); //wait for calcs
        }
    }


})(jQuery);
