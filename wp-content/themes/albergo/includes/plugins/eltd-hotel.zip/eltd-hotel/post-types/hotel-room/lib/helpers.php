<?php

use ElatedHotel\CPT\HotelRoom\Lib\HotelRoomSearch;

if(!function_exists('eltd_hotel_room_search')) {
	/**
	 * @return HotelRoomSearch
	 */
	function eltd_hotel_room_search() {
		return HotelRoomSearch::getInstance();
	}
}