<?php if ( has_post_thumbnail() ) { ?>
	<div class="eltd-hotel-room-image">
		<?php the_post_thumbnail( 'full' ); ?>
	</div>
<?php }