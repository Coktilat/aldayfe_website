<?php

if(!function_exists('eltd_hotel_room_meta_box_functions')) {
	/**
	 * @param $post_types
	 *
	 * @return array
	 */
	function eltd_hotel_room_meta_box_functions($post_types) {
		$post_types[] = 'hotel-room';

		return $post_types;
	}

	add_filter('albergo_elated_meta_box_post_types_save', 'eltd_hotel_room_meta_box_functions');
	add_filter('albergo_elated_meta_box_post_types_remove', 'eltd_hotel_room_meta_box_functions');
}

if(!function_exists('eltd_hotel_register_hotel_room_cpt')) {
	/**
	 * @param $cpt_class_name
	 *
	 * @return array
	 */
	function eltd_hotel_register_hotel_room_cpt($cpt_class_name) {
		$cpt_class = array(
			'ElatedHotel\CPT\HotelRoom\HotelRoomRegister'
		);

		$cpt_class_name = array_merge($cpt_class_name, $cpt_class);

		return $cpt_class_name;
	}

	add_filter('eltd_hotel_filter_register_custom_post_types', 'eltd_hotel_register_hotel_room_cpt');
}

if ( ! function_exists( 'eltd_hotel_room_scope_meta_box_functions' ) ) {
	function eltd_hotel_room_scope_meta_box_functions( $post_types ) {
		$post_types[] = 'hotel-room';

		return $post_types;
	}

	add_filter( 'albergo_elated_set_scope_for_meta_boxes', 'eltd_hotel_room_scope_meta_box_functions' );
}


// Load property shortcodes
if(!function_exists('eltd_hotel_room_include_shortcodes_file')) {
	/**
	 * Loades all shortcodes by going through all folders that are placed directly in shortcodes folder
	 */
	function eltd_hotel_room_include_shortcodes_file() {
		foreach(glob(ELTD_HOTEL_CPT_PATH.'/hotel-room/shortcodes/*/load.php') as $shortcode_load) {
			include_once $shortcode_load;
		}
	}

	add_action('eltd_hotel_include_shortcode_files', 'eltd_hotel_room_include_shortcodes_file');
}

if(!function_exists('eltd_hotel_room_get_single_room')) {
	function eltd_hotel_room_get_single_room() {

		$params = array();

		eltd_hotel_get_cpt_single_module_template_part('templates/single/holder', 'hotel-room', '', $params);
	}
}

if(!function_exists('eltd_hotel_room_register_single_sidebar')) {
	/**
	 * Register sidebar that will be used for hotel room single page
	 */
	function eltd_hotel_room_register_single_sidebar() {
		register_sidebar(array(
			'name'          => esc_html__('Hotel Room Single Sidebar', 'eltd-hotel'),
			'id'            => 'hotel-room-single-sidebar',
			'description'   => esc_html__('Sidebar that is displayed on hotel room single page', 'eltd-hotel'),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4><span class="eltd-sidearea-title">',
			'after_title'   => '</span><span class="eltd-sidearea-line"></span></h4>'
		));
	}

	add_action('widgets_init', 'eltd_hotel_room_register_single_sidebar');
}


if ( ! function_exists( 'eltd_hotel_room_get_search_page' ) ) {
	function eltd_hotel_room_get_search_page() {
		$sidebar_layout = albergo_elated_sidebar_layout();

		$holder_classes = $sidebar_layout !== 'no-sidebar' ? 'eltd-content-has-sidebar' : '';
		$holder_classes = apply_filters( 'albergo_elated_hotel_searh_holder_classes', $holder_classes );

		$params = array();

		$params['type']                 = eltd_hotel_room_search()->getHotelTypes();
		$params['number_of_columns']    = eltd_hotel_room_search()->getNumberOfColumns();
		$params['image_proportions']    = eltd_hotel_room_search()->getImageProportion();
		$params['room_min_date']        = eltd_hotel_room_search()->getCheckIn();
		$params['room_max_date']        = eltd_hotel_room_search()->getCheckOut();
		$params['room_number_of_rooms'] = eltd_hotel_room_search()->getRooms();
		$params['room_location']        = eltd_hotel_room_search()->getLocations();
		$params['sort_option']          = eltd_hotel_room_search()->getSortOption();
		$params['room_adults']          = eltd_hotel_room_search()->getAdults();
		$params['room_children']        = eltd_hotel_room_search()->getChildren();
		$params['order_by']             = eltd_hotel_room_search()->getOrderBy();
		$params['order']                = eltd_hotel_room_search()->getOrderType();
		$params['number_of_items']      = eltd_hotel_room_search()->getHotelRoomsPerPage();

		// default params
		$params['enable_filter']   = 'yes';
		$params['enable_sort']     = 'yes';
		$params['pagination_type'] = 'standard';
		$params['title_tag'] = 'h4';


		$list_params = array(
			'params'         => $params,
			'holder_classes' => $holder_classes,
			'sidebar_layout' => $sidebar_layout
		);

		eltd_hotel_get_cpt_single_module_template_part( 'templates/search/holder', 'hotel-room', '', $list_params );
	}
}

if ( ! function_exists( 'eltd_hotel_room_get_search_pages' ) ) {
	/**
	 * @param bool $first_empty
	 *
	 * @return array
	 */
	function eltd_hotel_room_get_search_pages( $first_empty = false ) {
		$posts_args = array(
			'post_type'   => array( 'page' ),
			'post_status' => 'publish',
			'meta_key'    => '_wp_page_template',
			'meta_value'  => 'post-types/hotel-room/templates/search-hotel-item-template.php'
		);

		$posts_query = new WP_Query( $posts_args );

		$search_pages = array();

		if ( $first_empty ) {
			$search_pages[''] = '';
		}

		if ( $posts_query->have_posts() ) {
			while ( $posts_query->have_posts() ) {
				$posts_query->the_post();
				$search_pages[ get_the_ID() ] = get_the_title();
			}
		}

		return $search_pages;
	}
}

if ( ! function_exists( 'eltd_hotel_room_get_search_page_url' ) ) {
	/**
	 * @return false|string
	 */
	function eltd_hotel_room_get_search_page_url() {
		$default_url = get_post_type_archive_link( 'hotel-room' );
		if ( ! eltd_hotel_theme_installed() ) {
			return $default_url;
		}

		$option = albergo_elated_options()->getOptionValue( 'hotel_room_search_main_page' );

		if ( empty( $option ) ) {
			return $default_url;
		}

		return get_permalink( $option );
	}
}

if ( ! function_exists( 'albergo_elated_get_hotel_search_holder_classes' ) ) {
	/**
	 * Function that generates blog holder classes for single search page
	 */
	function albergo_elated_get_hotel_search_holder_classes( $classes ) {
		$sidebar_classes   = array();
		$sidebar_classes[] = 'eltd-grid-large-gutter';

		$classes = $classes . ' ' . implode( ' ', $sidebar_classes );

		return $classes;
	}

	add_filter( 'albergo_elated_hotel_searh_holder_classes', 'albergo_elated_get_hotel_search_holder_classes' );
}


if ( ! function_exists('eltd_hotel_room_get_hotel_room_taxonomy') ) {
	/**
	 * @param $taxonomy
	 * @param string $item_id
	 *
	 * @return array|string|WP_Error
	 */
	function eltd_hotel_room_get_hotel_room_taxonomy($taxonomy, $item_id = '') {
		$item_id = isset($item_id) && !empty($item_id) ?  $item_id : get_the_ID();

		if(isset($taxonomy) && !empty($taxonomy)) {
			$taxonomies = wp_get_post_terms( $item_id, $taxonomy );
			return $taxonomies;
		}

		return '';
	}
}

if ( ! function_exists('eltd_hotel_room_get_currency') ) {
	/**
	 * Get currency
	 * @return string of currency that is used in woocommerce or default currency
	 */
	function eltd_hotel_room_get_currency() {
		$currency = '$'; // default currency if woocommerce is not installed
		if ( albergo_elated_is_woocommerce_installed() ) {
			$currency = get_woocommerce_currency_symbol( get_woocommerce_currency() );
		}

		return $currency;
	}
}


if(!function_exists( 'eltd_hotel_room_get_locations' )){
	/**
	 * Get all locations
	 * return array of all location added as tag
	 *
	 * @param bool $first_empty set first param to be empty
	 *
	 * @return array
	 */
	function eltd_hotel_room_get_locations($first_empty = true){

		$hotel_locations_array = array();
		$args = array(
			//'taxonomy'   => 'location-tag',
			'hide_empty' => false
		);

		$hotel_locations = get_terms($args);

		if (is_array($hotel_locations) && count($hotel_locations)) {
			if($first_empty){
				$hotel_locations_array[''] = esc_html__('All', 'hotel-location');
			}
			foreach ($hotel_locations as $hotel_location) {
				if($hotel_location->taxonomy == 'location-tag') {
					// use only with specific taxonomy (doesn't work like argument in get_terms())
					$hotel_locations_array[ $hotel_location->term_id ] = $hotel_location->name;
				}

			}

		}

		return $hotel_locations_array;
	}
}


if(!function_exists( 'eltd_hotel_room_get_extra_services' )){
	/**
	 * Get all extra services
	 * return array of all extra services added as tag
	 */
	function eltd_hotel_room_get_extra_services(){

		$first_empty = true;

		$extra_services_array = array();
		$args = array(
			'hide_empty' => false
		);

		$extra_services = get_terms($args);

		if (is_array($extra_services) && count($extra_services)) {
			if($first_empty){
				$extra_services_array[''] = '';
			}
			foreach ($extra_services as $extra_service) {

				if($extra_service->taxonomy == 'extra-service-tag') {
					// use only with specific taxonomy (doesn't work like argument in get_terms())
					$extra_services_array[ $extra_service->term_id ] = $extra_service->name;
				}

			}

		}

		return $extra_services_array;
	}
}


if(!function_exists( 'eltd_hotel_room_get_location_by_id' )){
	/**
	 * Get hotel room location
	 * param $id - location id
	 * return object
	 */
	function eltd_hotel_room_get_location_by_id($id){
		$type = get_term_by('id', $id, 'location-tag');
		return $type;
	}
}

if(!function_exists( 'eltd_hotel_room_get_extra_service_by_id' )){
	/**
	 * Get hotel room extra services
	 * param $id - extra service id
	 * return object
	 */
	function eltd_hotel_room_get_extra_service_by_id($id){
		$type = get_term_by('id', $id, 'extra-service-tag');
		return $type;
	}
}

if(!function_exists('eltd_hotel_room_get_service_packs')){
	/**
	 * Get hotel service packs
	 * return object
	 */
	function eltd_hotel_room_get_service_packs(){
		$extra_services = array(
			'add_to_price' => esc_html__( 'Add to price', 'eltd-hotel' ),
			'add_to_price_per_night' => esc_html__( 'Add to price per night', 'eltd-hotel' ),
			'add_to_price_per_person' => esc_html__( 'Add to price per person', 'eltd-hotel' ),
			'add_to_price_per_person_per_night' => esc_html__( 'Add to price per person per night', 'eltd-hotel' ),
			'subtract_from_price' => esc_html__( 'Subtract from price', 'eltd-hotel' ),
			'subtract_from_price_per_night' => esc_html__( 'Subtract from price per night', 'eltd-hotel' ),
			'increase_price_by_percent_amount' => esc_html__( 'Increase price by % amount', 'eltd-hotel' ),
			'decrease_price_by_percent_amount' => esc_html__( 'Decrease price by % amount', 'eltd-hotel' ),
		);

		return $extra_services;
	}
}

if ( ! function_exists( 'eltd_hotel_room_get_room_sorting_options' ) ) {
	/**
	 * Get Sorting Options
	 * return object
	 */
	function eltd_hotel_room_get_room_sorting_options() {
		$options = array(
			''           => esc_html__( 'Default', 'eltd-hotel' ),
			'date'       => esc_html__( 'Date', 'eltd-hotel' ),
			'price-low'  => esc_html__( 'Price Low to High', 'eltd-hotel' ),
			'price-high' => esc_html__( 'Price High to Low', 'eltd-hotel' ),
			'name'       => esc_html__( 'Name (A-Z)', 'eltd-hotel' ),
			'name-x'     => esc_html__( 'Name (Z-A)', 'eltd-hotel' )
		);

		return $options;
	}
}

if(!function_exists( 'eltd_hotel_room_save_custom_fields' )) {
	/**
	 * Save custom fields for hotel room(front end submit)
	 *
	 * @param  $post_id , $post
	 * @param $post
	 */
	function eltd_hotel_room_save_custom_fields( $post_id, $post ) {


		if($post && $post !== null && $post->post_type !== 'hotel-room'){
			return;

		}

		if(isset($_POST)){
			if(isset($_POST['eltd_hotel_room_location_meta']) || isset($_POST['eltd_hotel_room_extra_service_meta'])) {

				$location_ids        = array();
				$location_save_array = array();

				if ( $_POST['eltd_hotel_room_location_meta'] ) {
					$location = $_POST['eltd_hotel_room_location_meta'];
					if ( $location !== '' ) {
						$location_ids[] = $location;
					}
				}

				$extra_services_ids        = array();
				$extra_services_save_array = array();

				if ( $_POST['eltd_hotel_room_extra_service_meta'] ) {
					$extra_services = $_POST['eltd_hotel_room_extra_service_meta'];
					if ( $extra_services !== '' ) {
						$extra_services_ids = $extra_services;
					}
				}


				// location

				if ( count( $location_ids ) ) {
					foreach ( $location_ids as $id ) {
						$type                  = eltd_hotel_room_get_location_by_id( $id );
						$location_save_array[] = $type->slug;
					}
				}

				if ( count( $location_save_array ) ) {

					wp_set_object_terms( $post_id, $location_save_array, 'location-tag' );
				} else {
					wp_delete_object_term_relationships( $post_id, 'location-tag' );
				}

				// extra services

				if ( count( $extra_services_ids ) ) {
					foreach ( $extra_services_ids as $id ) {
						$type                        = eltd_hotel_room_get_extra_service_by_id( $id );
						$extra_services_save_array[] = $type->slug;
					}
				}

				if ( count( $extra_services_save_array ) ) {

					wp_set_object_terms( $post_id, $extra_services_save_array, 'extra-service-tag' );
				} else {
					wp_delete_object_term_relationships( $post_id, 'extra-service-tag' );
				}
			}
		}
	}
	add_action('save_post', 'eltd_hotel_room_save_custom_fields', 25, 2);
}


if ( ! function_exists( 'eltd_hotel_room_single_room_active_tabs' ) ) {
	/**
	 * Function that returns active tabs for room single
	 *
	 * @param $params
	 *
	 * @return mixed
	 */
	function eltd_hotel_room_single_room_active_tabs($params) {


		$featured_item = albergo_elated_get_meta_field_intersect( 'hotel_room_featured_item' );


		// get which info is enabled
		$hotel_info_array = array(
			'hotel_room_enable_amenities',
			'hotel_room_enable_gallery',
			'hotel_room_enable_extra_services',
			'hotel_room_enable_location',
			'hotel_room_enable_reviews',
		);

		$params_info = array();

		foreach($hotel_info_array as $hotel_info) {
			$hotel_info_key                         = str_replace('hotel_room_enable_', '', $hotel_info);

			$params_info[$hotel_info_key] = albergo_elated_get_meta_field_intersect( $hotel_info );

		}

		$tabs = array();

		// this tab is enabled by default
		$tabs['description']['id'] = 'eltd_hotel_room_tab_id_description';
		$tabs['description']['title'] = esc_html__('ROOM DETAILS','eltd-hotel');


		if($params_info['gallery'] == 'yes') {
			$tabs['gallery']['id'] = 'eltd_hotel_room_tab_id_gallery';
			$tabs['gallery']['title'] = esc_html__('GALLERY','eltd-hotel');
		}

		if($params_info['location'] == 'yes') {
			$tabs['location']['id'] = 'eltd_hotel_room_tab_id_location';
			$tabs['location']['title'] = esc_html__('LOCATION','eltd-hotel');
		}

		if($params_info['reviews'] == 'yes') {
			$tabs['reviews']['id'] = 'eltd_hotel_room_tab_id_reviews';
			$tabs['reviews']['title'] = esc_html__('REVIEWS','eltd-hotel');
		}

		// merge info and tabs
		$params['hotel_info'] = $params_info;
		$params['hotel_tabs'] = $tabs;
		$params['featured_item'] = $featured_item;

		return $params;
	}

	add_filter( 'albergo_elated_hotel_single_active_tabs_params', 'eltd_hotel_room_single_room_active_tabs' );
}

if ( ! function_exists( 'eltd_hotel_room_single_room_slider' ) ) {

	/**
	 * Function that returns single slider params
	 *
	 * @param $params
	 *
	 * @return mixed
	 */
	function eltd_hotel_room_single_room_slider($params) {

		$params['slider_images'] = get_post_meta(get_the_ID(), 'eltd_hotel_gallery_images', true);

		return $params;
	}

	add_filter( 'albergo_elated_hotel_single_slider_params', 'eltd_hotel_room_single_room_slider' );
}



if ( ! function_exists( 'eltd_hotel_room_single_room_location' ) ) {
	/**
	 * Add location params to single room pages.
	 *
	 * @param array $params
	 *
	 * @return array
	 */
	function eltd_hotel_room_single_room_location( $params = array() ) {

		$id = get_the_ID();

		$locations        = eltd_hotel_room_get_hotel_room_taxonomy('location-tag');
		$params['location'] = '';
		foreach ( $locations as $location ) {
			$params['location'] = $location; // only one location
		}

		$params['full_address']     = get_post_meta($id, 'eltd_hotel_room_full_address_meta', true);
		$params['simple_address']   = get_post_meta($id, 'eltd_hotel_room_simple_address_meta', true);
		$params['email']            = get_post_meta($id, 'eltd_hotel_room_email_meta', true);
		$params['country']          = get_post_meta($id, 'eltd_hotel_room_address_country_meta', true);
		$params['phone']            = get_post_meta($id, 'eltd_hotel_room_phone_meta', true);

		return $params;
	}

	add_filter( 'albergo_elated_hotel_single_location_params', 'eltd_hotel_room_single_room_location' );
}


if ( ! function_exists( 'eltd_hotel_room_single_room_extra_services' ) ) {
	/**
	 * Add extra services params to single room pages.
	 *
	 * @param array $params
	 *
	 * @param int|string $item_id
	 *
	 * @return array
	 */
	function eltd_hotel_room_single_room_extra_services( $params = array(), $item_id = '' ) {

		$id = isset( $item_id ) && ! empty( $item_id ) ? $item_id : get_the_ID();

		// get all general options
		$extra_services = eltd_hotel_room_get_extra_services();

		// get general options that are set on single page
		$extra_services_active_on_single = get_post_meta( $id, 'eltd_hotel_room_extra_service_meta', true );

		$extra_services_with_all_parameters = array();

		foreach ( $extra_services as $key => $name ) {
			// use only general options set on single page
			if ( $name != '' && in_array( $key, $extra_services_active_on_single ) ) {
				$extra_services_with_all_parameters[ $key ]['name']         = $name;
				$extra_services_with_all_parameters[ $key ]['description']  = preg_replace( '[<\/p>|<p>]', '', tag_description( $key ) );
				$extra_services_with_all_parameters[ $key ]['type']         = get_term_meta( $key, 'eltd_extra_service_type', true );
				$extra_services_with_all_parameters[ $key ]['service_pack'] = get_term_meta( $key, 'eltd_extra_service_pack', true );
				$extra_services_with_all_parameters[ $key ]['price']        = get_term_meta( $key, 'eltd_extra_service_price', true );
				$extra_services_with_all_parameters[ $key ]['percent']      = get_term_meta( $key, 'eltd_extra_service_percent', true );
				$extra_services_with_all_parameters[ $key ]['global']       = 'yes';
			}
		}

		// get meta options
		$additional_extra_service = get_post_meta( $id, 'eltd_additional_extra_service_meta', true );

		if ( is_array( $additional_extra_service ) && count( $additional_extra_service ) > 0 ) {
			foreach ( $additional_extra_service as $key => $service ) {
				$extra_services_with_all_parameters[ $key ]           = $service;
				$extra_services_with_all_parameters[ $key ]['global'] = 'no';
			}
		}

		$params['extra_services'] = $extra_services_with_all_parameters;

		return $params;

	}

	add_filter( 'albergo_elated_hotel_single_extra_services_params', 'eltd_hotel_room_single_room_extra_services' );
}

if ( ! function_exists( 'eltd_hotel_room_single_room_google_map' ) ) {
	/**
	 * Add google map params to single room.
	 *
	 * @param array $params
	 *
	 * @return array
	 */
	function eltd_hotel_room_single_room_google_map( $params = array() ) {

		$id = get_the_ID();

		$full_address = get_post_meta($id, 'eltd_hotel_room_full_address_meta', true);

		$google_map_params = array(
			'address1' => $full_address,
			'snazzy_map_style' => 'yes',
			'snazzy_map_code' => "`{`
				{
				``featureType``: ``landscape.natural``,
				``elementType``: ``geometry.fill``,
				``stylers``: `{`
				{
				``visibility``: ``on``
				},
				{
				``color``: ``#e0efef``
				}
				`}`
				},
				{
				``featureType``: ``poi``,
				``elementType``: ``geometry.fill``,
				``stylers``: `{`
				{
				``visibility``: ``on``
				},
				{
				``hue``: ``#1900ff``
				},
				{
				``color``: ``#c0e8e8``
				}
				`}`
				},
				{
				``featureType``: ``road``,
				``elementType``: ``geometry``,
				``stylers``: `{`
				{
				``lightness``: 100
				},
				{
				``visibility``: ``simplified``
				}
				`}`
				},
				{
				``featureType``: ``road``,
				``elementType``: ``labels``,
				``stylers``: `{`
				{
				``visibility``: ``off``
				}
				`}`
				},
				{
				``featureType``: ``transit.line``,
				``elementType``: ``geometry``,
				``stylers``: `{`
				{
				``visibility``: ``on``
				},
				{
				``lightness``: 700
				}
				`}`
				},
				{
				``featureType``: ``water``,
				``elementType``: ``all``,
				``stylers``: `{`
				{
				``color``: ``#7dcdcd``
				}
				`}`
				}
				`}`"
		);

		$params['google_map_params'] = $google_map_params;

		return $params;

	}

	add_filter( 'albergo_elated_hotel_single_google_map_params', 'eltd_hotel_room_single_room_google_map' );
}

if ( ! function_exists( 'eltd_hotel_room_single_room_reservation' ) ) {
	/**
	 * Add reservation params to single room.
	 *
	 * @param array $params
	 *
	 * @return array
	 */
	function eltd_hotel_room_single_room_reservation( $params = array() ) {
		$id = get_the_ID();

		// check if already is in cart
		$in_cart = eltd_hotel_room_single_in_cart($id);

		$email          = wp_get_current_user()->user_email;

		$adults          = get_post_meta( $id, 'eltd_room_capacity_adults_meta', true );
		$children        = get_post_meta( $id, 'eltd_room_capacity_children_meta', true );
		$number_of_rooms = get_post_meta( $id, 'eltd_hotel_room_number_meta', true );
		$initial_price   = get_post_meta( $id, 'eltd_hotel_room_price_meta', true );
		$currency        = eltd_hotel_room_get_currency();

		$params['adults']          = intval( $adults );
		$params['children']        = intval( $children );
		$params['number_of_rooms'] = intval( $number_of_rooms );
		$params['initial_price']   = intval( $initial_price );
		$params['in_cart']         = $in_cart;
		$params['currency']        = $currency;
		$params['email']           = $email;

		return $params;
	}

	add_filter( 'albergo_elated_hotel_single_reservation_params', 'eltd_hotel_room_single_room_reservation' );
}

if(!function_exists('eltd_hotel_room_get_extra_service_type')){
	/**
	 * Get if hotel room extra service type is mandatory
	 * return object
	 *
	 * @param $extra_service object
	 *
	 * @return string
	 */
	function eltd_hotel_room_get_extra_service_type($extra_service){

		$flag = is_object($extra_service); // if it is general tag, than it is object

		if($flag) {
			$type = get_term_meta( $extra_service->term_id, 'eltd_extra_service_type', true );
		} else {
			$type = $extra_service['type'];
		}

		return $type == 'mandatory';
	}
}

if(!function_exists('eltd_hotel_room_get_extra_service_string')){
	/**
	 * Get hotel room extra service string
	 *
	 * @param $extra_service string
	 *
	 * @return string
	 */
	function eltd_hotel_room_get_extra_service_string($extra_service){

		$params = array();

		$params['currency'] = eltd_hotel_room_get_currency();

		$params['service_pack'] = $extra_service['service_pack'];
		$params['price']        = $extra_service['price'];
		$params['percent']      = $extra_service['percent'];


		return eltd_hotel_return_cpt_single_module_template_part( 'templates/single/parts/extra-service-string', 'hotel-room', '', $params );
	}
}

if ( ! function_exists( 'eltd_hotel_room_single_room_price' ) ) {
	/**
	 * Add location params to single room pages.
	 *
	 * @param array $params
	 *
	 * @return array
	 */
	function eltd_hotel_room_single_room_price( $params = array() ) {

		$id = get_the_ID();

		$params['currency'] = eltd_hotel_room_get_currency();
		$params['price'] = get_post_meta($id, 'eltd_hotel_room_price_meta', true);


		return $params;
	}

	add_filter( 'albergo_elated_hotel_single_price_params', 'eltd_hotel_room_single_room_price' );
}


if ( ! function_exists( 'eltd_hotel_room_single_specific_extra_service' ) ) {
	/**
	 * Return Specific Extra Service, public or on single room
	 *
	 * @param bool $public
	 * @param string $tag_id
	 * @param string $page_id
	 *
	 * @return array of tag parameters
	 */
	function eltd_hotel_room_single_specific_extra_service( $public = true, $tag_id = '', $page_id = '' ) {

		$id = isset( $page_id ) && ! empty( $page_id ) ? $page_id : get_the_ID();

		$extra_service = [];

		if ( $public ) {
			// get general options that are set on single page
			$extra_services                = eltd_hotel_room_get_extra_services();
			$extra_service['name']         = $extra_services[ $tag_id ];
			$extra_service['description']  = preg_replace( '[<\/p>|<p>]', '', tag_description( $tag_id ) );
			$extra_service['type']         = get_term_meta( $tag_id, 'eltd_extra_service_type', true );
			$extra_service['service_pack'] = get_term_meta( $tag_id, 'eltd_extra_service_pack', true );
			$extra_service['price']        = get_term_meta( $tag_id, 'eltd_extra_service_price', true );
			$extra_service['percent']      = get_term_meta( $tag_id, 'eltd_extra_service_percent', true );
			$extra_service['global']       = 'yes';

			return $extra_service;
		} else {
			// get meta options
			$additional_extra_service = get_post_meta( $id, 'eltd_additional_extra_service_meta', true );

			$extra_service                  = $additional_extra_service[ $tag_id ];
			$extra_service['global']        = 'no';

			return $extra_service;
		}
	}
}


if( !function_exists('eltd_hotel_get_hotel_room_max_price_value') ) {
	/**
	 * Function that returns maximum price of all hotel rooms
	 *
	 * @return null|string
	 */
	function eltd_hotel_get_hotel_room_max_price_value() {
		global $wpdb;
		$table_prefix = $wpdb->get_blog_prefix();
		$query = "SELECT max(cast(meta_value as unsigned)) FROM " . $table_prefix ."postmeta WHERE meta_key='eltd_hotel_room_price_meta'";
		$the_max = $wpdb->get_var($query);
		return $the_max;
	}
}


if( !function_exists('eltd_hotel_get_hotel_room_max_rooms') ) {
	/**
	 * Function that returns maximum rooms of all hotel rooms
	 *
	 * @return null|string
	 */
	function eltd_hotel_get_hotel_room_max_rooms() {
		global $wpdb;
		$table_prefix = $wpdb->get_blog_prefix();
		$query = "SELECT max(cast(meta_value as unsigned)) FROM " . $table_prefix ."postmeta WHERE meta_key='eltd_hotel_room_number_meta'";
		$the_max = $wpdb->get_var($query);
		return $the_max;
	}
}

if( !function_exists('eltd_hotel_get_hotel_room_adults') ) {
	/**
	 * Function that returns maximum adults of all hotel rooms
	 *
	 * @return null|string
	 */
	function eltd_hotel_get_hotel_room_adults() {
		global $wpdb;
		$table_prefix = $wpdb->get_blog_prefix();
		$query = "SELECT max(cast(meta_value as unsigned)) FROM " . $table_prefix ."postmeta WHERE meta_key='eltd_room_capacity_adults_meta'";
		$the_max = $wpdb->get_var($query);
		return $the_max;
	}
}


if( !function_exists('eltd_hotel_get_hotel_room_max_children') ) {
	/**
	 * Function that returns maximum children of all hotel rooms
	 *
	 * @return null|string
	 */
	function eltd_hotel_get_hotel_room_max_children() {
		global $wpdb;
		$table_prefix = $wpdb->get_blog_prefix();
		$query = "SELECT max(cast(meta_value as unsigned)) FROM " . $table_prefix ."postmeta WHERE meta_key='eltd_room_capacity_children_meta'";
		$the_max = $wpdb->get_var($query);
		return $the_max;
	}
}


if( !function_exists('eltd_hotel_room_check_availability') ) {
	/**
	 * @param $params array from shortcode
	 *
	 * @return array of flag and available rooms -- in same case we do not need to know which rooms are availlable
	 */
	function eltd_hotel_room_check_availability($params) {

		//  room id
		//  new room room min date
		//  new room room max date
		//  number of rooms that user want to reserve

		if ( isset( $params['page_id'] ) ) {
			$id = $params['page_id'];
		} else {
			$id = get_the_ID();
		}

		// if dates are not set, only room number is important
		if ( $params['room_min_date'] == '' || $params['room_min_date'] == '' ) {
			return array( 'flag' => true ); // return non empty to allow room after filter
		}

		// get dates and rooms from filter
		$room_date_start = new DateTime( $params['room_min_date'] );
		$room_date_end   = new DateTime( $params['room_max_date'] );

		$room_to_reserve_number = ( $params['room_number_of_rooms'] ) != '' ? intval( $params['room_number_of_rooms'] ) : 1;

		//total number of rooms sum
		$number_of_rooms = intval( get_post_meta( $id, 'eltd_hotel_room_number_meta', true ) );
		$number_of_rooms = ( $number_of_rooms == '' ) ? 1 : $number_of_rooms;

		$starting_date_array = array();
		$ending_date_array   = array();
		$number_array        = array();

		$room_dates = get_post_meta( $id, 'eltd_room_date_meta', true );

		if ( is_array( $room_dates ) && count( $room_dates ) ) {
			foreach ( $room_dates as $room_date ) {
				//starting and ending date as well as room for every reservation
				$starting_date_array[] = $room_date['date_begin'];
				$ending_date_array[]   = $room_date['date_end'];
				$number_array[]        = $room_date['number_of_room'];
			}
		}


		//array of different rooms that are reserved in case that user use different number (e.g. 1,2,3,4) - number 1 and 3 are 1 X time
		$different_number_array = array();
		foreach ( $number_array as $number ) {
			if ( ! in_array( $number, $different_number_array ) ) {
				array_push( $different_number_array, $number );
			}
		}

		// flag if there are available room
		$flag = false;
		// array of free rooms
		$rooms_available = array();

		// check for every room separately
		foreach ( $different_number_array as $room_number ) {
			// exit case, if rooms are found in last iteration
			if ( count( $rooms_available ) >= $room_to_reserve_number ) {
				break;
			}

			$reserved_room_found = false;

			// check if that room is reserved in that time
			for ( $i = 0; $i < count( $starting_date_array ); $i ++ ) {
				if ( $room_number == $number_array[ $i ] ) {
					$starting_date_from_array = new DateTime( $starting_date_array[ $i ] );
					$ending_date_from_array   = new DateTime( $ending_date_array[ $i ] );

					// if true, reserved room is found
					if ( ( $room_date_start < $starting_date_from_array && $room_date_end > $starting_date_from_array )
					     || ( $room_date_start >= $starting_date_from_array && $room_date_start < $ending_date_from_array )
					     || ( $room_date_end > $starting_date_from_array && $room_date_end < $ending_date_from_array )
					     || ( $room_date_start < $ending_date_from_array && $room_date_end > $ending_date_from_array ) ) {
						$reserved_room_found = true;
						break;
					}
				}
			}

			// if there is not reserved room in that time, room can be reserved
			if ( ! $reserved_room_found ) {
				array_push( $rooms_available, $room_number );
			}
		}

		// exit case, if rooms are found and return new numbers
		if ( count( $rooms_available ) >= $number_of_rooms ) {
			$flag = true;
		} else if ( ( count( $rooms_available ) + ( $number_of_rooms - count( $different_number_array ) ) ) >= $room_to_reserve_number ) { //
			// if number of available rooms and rooms which are not reserved more or same with number of rooms that user tried to reserve

			//all reserved rooms
			$different_number = count( $different_number_array );

			// new number -- this is ok in case we are using room number [1,2,3,4]
			$new_number = $different_number + 1;

			//add new rooms until enough rooms are reserved
			while ( $different_number <= $number_of_rooms && count( $rooms_available ) < $room_to_reserve_number ) {

				// just to check if we have that number already created
				if ( ! in_array( $new_number, $different_number_array ) ) {
					array_push( $rooms_available, $new_number );
					$new_number ++;
				}
			}

			$flag = true;
		}

		// return empty array if there is not available room
		return array( 'flag' => $flag, 'rooms' => $rooms_available );

	}
}

if ( ! function_exists( 'eltd_hotel_room_get_new_price' ) ) {
	/**
	 * @param $params array
	 *
	 * @return string new price
	 */

	/*
	 * 1 - add to price
	 * 2 - add to price per night
	 * 3 - add to price per person
	 * 4 - add to price per night per person
	 * 5 - subtract from price
	 * 6 - subtract from price per night
	 * 7 - increase price by amount
	 * 8 - decrease price by amount
	 *
	 * price =  (7,8 * price) * nights + (1 - 5 + 2 * nights
	 *          - 6 * nights + 3 * (adults + children) + (4 * (adults + children) * nights))
	 */
	function eltd_hotel_room_get_new_price( $params ) {
		// get how much days
		$datetime1 = new DateTime( $params['room_min_date'] );
		$datetime2 = new DateTime( $params['room_max_date'] );
		$days      = $datetime1->diff( $datetime2 )->days;

		$adults          = intval( $params['room_adults'] );
		$children        = intval( $params['room_children'] );
		$price_initial   = intval( get_post_meta( $params['page_id'], 'eltd_hotel_room_price_meta', true ) );
		$number_of_rooms = intval( $params['room_number'] );
		$price           = intval( $price_initial );

		// get all selected extra services - this does not include mandatory extra services
		$checked_extra_services     = array();
		$checked_extra_services_ids = $params['checked_extra_services'];
		foreach ( $checked_extra_services_ids as $checked_extra_services_id ) {

			// get extra service parameters based on their id
			$public = strstr( $checked_extra_services_id, 'public' ) !== false;
			$tag_id = substr( strstr( $checked_extra_services_id, 'id-' ), 3 ); // clear 'id-'

			$checked_extra_services[] = eltd_hotel_room_single_specific_extra_service( $public, $tag_id, $params['page_id'] );
		}

		// get all mandatory extra services cuz they are not in form
		$mandatory_extra_services = array();
		$single_extra_services    = eltd_hotel_room_single_room_extra_services(array(), $params['page_id'] );

		foreach ( $single_extra_services['extra_services'] as $extra_service ) {
			if ( $extra_service['type'] == 'mandatory' ) {
				$mandatory_extra_services[] = $extra_service;
			}
		}

		// merging all extra services
		$all_extra_services = array_merge( $checked_extra_services, $mandatory_extra_services );

		/*          counting start          */

		// first part - percent
		foreach ( $all_extra_services as $service ) {
			if ( $service['service_pack'] == 'increase_price_by_percent_amount' ) {
				$price = $price * ( 100 + intval( $service['percent'] ) ) / 100;
			} elseif ( $service['service_pack'] == 'decrease_price_by_percent_amount' ) {
				$price = $price * ( 100 - intval( $service['percent'] ) ) / 100;
			}
		}
		// second part - per night
		$price *= $days;

		// third part - number

		foreach ( $all_extra_services as $service ) {
			if ( $service['service_pack'] == 'add_to_price' ) {
				$price = $price + intval( $service['price'] );

			}
			if ( $service['service_pack'] == 'add_to_price_per_night' ) {
				$price = $price + $days * intval( $service['price'] );
			}
			if ( $service['service_pack'] == 'add_to_price_per_person' ) {
				$price = $price + ( $adults + $children ) * intval( $service['price'] );
			}
			if ( $service['service_pack'] == 'add_to_price_per_person_per_night' ) {
				$price = $price + ( $adults + $children ) * $days * intval( $service['price'] );
			}
			if ( $service['service_pack'] == 'subtract_from_price' ) {
				$price = $price - intval( $service['price'] );
			}
			if ( $service['service_pack'] == 'subtract_from_price_per_night' ) {
				$price = $price - $days * intval( $service['price'] );
			}

		}

		// fourth part - number
		$price *= $number_of_rooms;

		/*          counting end            */

		return $price;
	}
}


//Hotel payment functions
if ( ! function_exists( 'eltd_hotel_include_room_payment_class' ) ) {
	/**
	 * Function that includes product course
	 */
	function eltd_hotel_include_room_payment_class() {
		if ( eltd_hotel_woocommerce_integration_installed() && albergo_elated_is_woocommerce_installed() ) {
			require_once 'payment/class-wc-product-hotel-room.php';
			require_once 'payment/class-wc-order-item-hotel-room.php';
			require_once 'payment/class-wc-order-item-hotel-room-store.php';
			require_once 'payment/class-wc-hotel-room-data-store-cpt.php';
		}
	}

	add_action( 'init', 'eltd_hotel_include_room_payment_class', 1000 );
}

if ( ! function_exists( 'eltd_hotel_add_room_to_post_types_payment' ) ) {
	/**
	 * Function that add custom post type to list
	 */
	function eltd_hotel_add_room_to_post_types_payment( $post_types ) {
		if ( albergo_elated_is_woocommerce_installed() && eltd_hotel_woocommerce_integration_installed() ) {
			$post_types[] = 'hotel-room';
		}

		return $post_types;
	}

	add_filter( 'eltd_woocommerce_checkout_integration_post_types', 'eltd_hotel_add_room_to_post_types_payment', 100 );
}

if ( ! function_exists( 'eltd_hotel_room_add_to_cart_action' ) ) {
	function eltd_hotel_room_add_to_cart_action( $add_to_cart_url ) {
		$product_id        = apply_filters( 'woocommerce_add_to_cart_product_id', absint( $_REQUEST['add-to-cart'] ) );
		$product           = new WC_Product_Hotel_Room( $product_id );
		$url               = $product->add_to_cart_url();
		$quantity          = empty( $_REQUEST['quantity'] ) ? 1 : wc_stock_amount( $_REQUEST['quantity'] );
		$passed_validation = true;

		if ( $passed_validation && WC()->cart->add_to_cart( $product_id, $quantity ) !== false ) {
			wc_add_to_cart_message( array( $product_id => $quantity ), true );

			// If has custom URL redirect there
			if ( $url ) {
				wp_safe_redirect( $url );
				exit;
			} elseif ( get_option( 'woocommerce_cart_redirect_after_add' ) === 'yes' ) {
				wp_safe_redirect( wc_get_cart_url() );
				exit;
			}
		}
	}

	add_action( 'woocommerce_add_to_cart_handler_hotel-room', 'eltd_hotel_room_add_to_cart_action', 10, 1 );
}

//Post type helper functions
if ( ! function_exists( 'eltd_hotel_calculate_room_price' ) ) {
	function eltd_hotel_calculate_room_price( $id = '' ) {
		$price = 0;
		if (session_status() == PHP_SESSION_NONE) {
			session_start();
		}

		if(isset($_SESSION) && isset($_SESSION['rooms'])) {
			foreach ( $_SESSION['rooms'] as $room ) {
				if ( $room['item_id'] == $id ) {
					$price = $room['room_price'];
				}
			}
		}
		else {
			eltd_hotel_room_force_cart_clear();
		}

		return $price;
	}
}

//Force empty cart
if ( ! function_exists( 'eltd_hotel_room_force_cart_clear' ) ) {
	function eltd_hotel_room_force_cart_clear() {
		if ( albergo_elated_is_woocommerce_installed()) {
			global $woocommerce;
			$woocommerce->cart->empty_cart();
		}

	}
}

//Post type template functions
if ( ! function_exists( 'eltd_hotel_room_get_buy_form' ) ) {
	function eltd_hotel_room_get_buy_form() {

		if ( albergo_elated_is_woocommerce_installed() && function_exists( 'eltd_woocomerce_checkout_integration_get_buy_form' ) ) {
			eltd_woocomerce_checkout_integration_get_buy_form( array(),
				array(
					'input_text'   => esc_html__( 'Book Now', 'eltd-hotel' ),
					'size'         => 'medium',
					'type'         => 'solid',
					'custom_class' => 'eltd-hotel-room-single-res-button eltd-disable-hotel-room-single-btn',
				) );
		}
	}
}

//Check if page(room) is in cart
if ( ! function_exists( 'eltd_hotel_room_single_in_cart' ) ) {
	/**
	 * @param $page_id int of room
	 *
	 * @return bool if room exists in woo cart
	 */
	function eltd_hotel_room_single_in_cart($page_id) {

		$id = isset( $page_id ) && ! empty( $page_id ) ? $page_id : get_the_ID();

		if ( albergo_elated_is_woocommerce_installed()) {
			global $woocommerce;
			$items = $woocommerce->cart->get_cart();

			foreach($items as $item => $values) {
				if($values['data']->get_id() == $id) {
					return true;
				}
			}

			return false;
		}
	}
}


