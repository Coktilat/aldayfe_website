<?php
if ( albergo_elated_core_plugin_installed() ) {
	echo albergo_elated_get_button_html( array(
			'custom_class' => 'eltd-hr-filter-button',
			'html_type'    => 'button',
			'size'         => 'medium',
			'type'         => 'solid',
			'text'         => esc_html__( 'Filter Results', 'eltd-hotel' )
		) );
}
?>
