<?php

if(!function_exists('eltd_hotel_get_user_profile_reservation_items')) {
    function eltd_hotel_get_user_profile_reservation_items() {
        $formatted_orders = eltd_woocommerce_checkout_get_user_order_items('WC_Order_Item_Hotel_Room');

        return $formatted_orders;
    }
}