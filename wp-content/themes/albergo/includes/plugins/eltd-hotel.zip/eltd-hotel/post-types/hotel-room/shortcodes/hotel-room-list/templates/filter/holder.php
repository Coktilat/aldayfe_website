<?php if(isset($params['enable_filter']) && $params['enable_filter'] === 'yes') { ?>
	<div class="eltd-grid-col-3">
		<div class="eltd-hrl-filter-part">
				<h4>
					<b><?php esc_html_e( 'Your ', 'eltd-hotel' ); ?></b>
					<?php esc_html_e( 'Reservation', 'eltd-hotel' ); ?>
				</h4>
			<div class="eltd-filter-row eltd-filter-section-csp">
				<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/date', '', $params ); ?>
				<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/location', '', $params ); ?>
				<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/room-count', '', $params ); ?>
				<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/adults', '', $params ); ?>
                <?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/children', '', $params ); ?>
			</div>
			<div class="eltd-filter-row eltd-filter-section-sf">
				<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/price-range', '', $params ); ?>
			</div>
			<div class="eltd-filter-row eltd-filter-section-st">
				<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/amenities', '', $params ); ?>
			</div>
			<div class="eltd-filter-row eltd-filter-section-action">
				<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'filter/button', '', $params ); ?>
			</div>
		</div>
	</div>
<?php } ?>