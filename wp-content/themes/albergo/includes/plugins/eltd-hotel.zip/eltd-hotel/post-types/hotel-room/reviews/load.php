<?php

define('ELTD_HOTEL_ROOM_REVIEWS_PREFIX', 'eltd_hotel_room_reviews_');
define('ELTD_HOTEL_ROOM_REVIEWS_MAX_RATING', 5);
define('ELTD_HOTEL_ROOM_REVIEWS_POINTS_SCALE', 2);

require_once 'functions.php';
require_once 'tax-custom-fields.php';