<?php
namespace ElatedHotel\CPT\Shortcodes\HotelRoomPair;

use ElatedHotel\Lib;

class HotelRoomPair implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'eltd_hotel_room_pair';
		
		add_action('vc_before_init', array($this,'vcMap'));
		
		//Small room id filter
		add_filter( 'vc_autocomplete_eltd_hotel_room_pair_small_room_id_callback', array( &$this, 'smallRoomIDAutocompleteSuggester', ), 10, 1 );
		
		//Small room id render
		add_filter( 'vc_autocomplete_eltd_hotel_room_pair_small_room_id_render', array( &$this, 'smallRoomIDAutocompleteRender', ), 10, 1 );

		//Big room id filter
		add_filter( 'vc_autocomplete_eltd_hotel_room_pair_big_room_id_callback', array( &$this, 'bigRoomIDAutocompleteSuggester', ), 10, 1 );

		//Big room id render
		add_filter( 'vc_autocomplete_eltd_hotel_room_pair_big_room_id_render', array( &$this, 'bigRoomIDAutocompleteRender', ), 10, 1 );
		
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if(function_exists('vc_map')) {
			vc_map(
				array(
					'name'                      => esc_html__( 'Elated Hotel Room Pair', 'eltd-hotel' ),
					'base'                      => $this->getBase(),
					'category'                  => esc_html__( 'BY ELATED HOTEL', 'eltd-hotel' ),
					'icon'                      => 'icon-wpb-hotel-room-pair extended-custom-hotel-room-icon',
					'allowed_container_element' => 'vc_row',
					'params'                    => array(
						array(
							'type'        => 'autocomplete',
							'param_name'  => 'small_room_id',
							'heading'     => esc_html__( 'Small Room', 'eltd-hotel' ),
							'settings'    => array(
								'sortable'      => true,
								'unique_values' => true
							),
							'admin_label' => true,
							'save_always' => true,
							'description' => esc_html__( 'If you left this field empty then room ID will be of the current page', 'eltd-hotel' )
						),array(
                            'type'        => 'dropdown',
                            'param_name'  => 'enable_custom_image_1',
                            'heading'     => esc_html__( 'Enable Custom Image For Small Room', 'eltd-hotel' ),
                            'value'       => array_flip(albergo_elated_get_yes_no_select_array(false)),
                            'admin_label' => true,
                            'save_always' => true,
                        ),
                        array(
                            'type'        => 'attach_image',
                            'param_name'  => 'custom_image_1',
                            'heading'     => esc_html__( 'Custom Image', 'eltd-hotel' ),
                            'value'       => albergo_elated_get_yes_no_select_array(false),
                            'admin_label' => true,
                            'save_always' => true,
                            'dependency'  => array('element' => 'enable_custom_image_1', 'value' => 'yes')
                        ),
						array(
							'type'        => 'autocomplete',
							'param_name'  => 'big_room_id',
							'heading'     => esc_html__( 'Big Room', 'eltd-hotel' ),
							'settings'    => array(
								'sortable'      => true,
								'unique_values' => true
							),
							'admin_label' => true,
							'save_always' => true,
							'description' => esc_html__( 'If you left this field empty then room ID will be of the current page', 'eltd-hotel' )
						),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'enable_custom_image_2',
                            'heading'     => esc_html__( 'Enable Custom Image For Big Room', 'eltd-hotel' ),
                            'value'       => array_flip(albergo_elated_get_yes_no_select_array(false)),
                            'admin_label' => true,
                            'save_always' => true,
                        ),
                        array(
                            'type'        => 'attach_image',
                            'param_name'  => 'custom_image_2',
                            'heading'     => esc_html__( 'Custom Image', 'eltd-hotel' ),
                            'value'       => albergo_elated_get_yes_no_select_array(false),
                            'admin_label' => true,
                            'save_always' => true,
                            'dependency'  => array('element' => 'enable_custom_image_2', 'value' => 'yes')
                        ),
						array(
							'type' => 'dropdown',
							'param_name' => 'layout',
							'heading' => esc_html__('Layout order','eltd-hotel'),
							'value' => array(
								esc_html__('Small Room On The Left','eltd-hotel') => '',
								esc_html__('Big Room On The Left','eltd-hotel') => 'eltd-big-room-first',
							)
						),
						array(
							'type' => 'dropdown',
							'param_name' => 'title_tag',
							'heading' => esc_html__('Title Tag','eltd-hotel'),
							'value' => array_flip(albergo_elated_get_title_tag(true))
						),
						array(
							'type' => 'colorpicker',
							'param_name' => 'trim_background_color',
							'heading' => esc_html__('Trim Background Color','eltd-hotel'),
						),
					)
				)
			);
		}
    }
	
    public function render($atts, $content = null) {
        $args = array(
	        'small_room_id'             => '',
			'big_room_id'               => '',
            'enable_custom_image_1'     => 'no',
            'custom_image_1'            => '',
            'enable_custom_image_2'     => 'no',
            'custom_image_2'            => '',
			'layout'					=> '',
			'title_tag'					=> 'h4',
			'trim_background_color'		=> ''
        );

		$params = shortcode_atts($args, $atts);
		//extract($params);

	    $params['small_room_id'] = !empty($params['small_room_id']) ? $params['small_room_id'] : get_the_ID();
		$params['big_room_id'] = !empty($params['big_room_id']) ? $params['big_room_id'] : get_the_ID();

		$params['title_tag'] = !empty($params['title_tag']) ? $params['title_tag'] : $args['title_tag'];

		$params['rooms'] = array();
		$params['rooms'][] = array( 'class_name' => 'eltd-small-room', 'room_id' => $params['small_room_id'], 'room_price' => $this->getItemPrice($params['big_room_id']), 'image_size' => 'albergo_elated_square', 'enable_custom_image' => $params['enable_custom_image_1'], 'custom_image' => $params['custom_image_1'] );
		$params['rooms'][] = array( 'class_name' => 'eltd-big-room', 'room_id' => $params['big_room_id'], 'room_price' => $this->getItemPrice($params['big_room_id']), 'image_size' => 'albergo_elated_portrait', 'enable_custom_image' => $params['enable_custom_image_2'], 'custom_image' => $params['custom_image_2'] );


		$params['currency'] = eltd_hotel_room_get_currency();
		$params['holder_classes'] = $this->getHolderClasses($params);
		$params['trim_styles'] = $this->getTrimStyles($params);

		$html = eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-pair', 'room-pair', '', $params);

		return $html;
	}
	
	/**
	 * Return room info styles
	 *
	 * @param $params
	 *
	 * @return array
	 */
	private function getHolderClasses( $params ) {
		$holderClasses = array();
		
		if ( ! empty( $params['layout'] ) ) {
			$holderClasses[] = $params['layout'];
		}
		
		return implode( ' ', $holderClasses );
	}
	
	/**
	 * Generates room price based on id
	 *
	 * @param $room_id
	 *
	 * @return html
	 */
	public function getItemPrice( $room_id ) {

		$price = get_post_meta( $room_id, 'eltd_hotel_room_price_meta', true);

		return $price;
	}

	/**
	 * Filter small room by ID or Title
	 *
	 * @param $query
	 *
	 * @return array
	 */
	public function smallRoomIDAutocompleteSuggester( $query ) {
		global $wpdb;
		$room_id = (int) $query;
		$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT ID AS id, post_title AS title
					FROM {$wpdb->posts}
					WHERE post_type = 'hotel-room' AND ( ID = '%d' OR post_title LIKE '%%%s%%' )", $room_id > 0 ? $room_id : - 1, stripslashes( $query ), stripslashes( $query ) ), ARRAY_A );


		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data = array();
				$data['value'] = $value['id'];
				$data['label'] = esc_html__( 'Id', 'eltd-hotel' ) . ': ' . $value['id'] . ( ( strlen( $value['title'] ) > 0 ) ? ' - ' . esc_html__( 'Title', 'eltd-hotel' ) . ': ' . $value['title'] : '' );
				$results[] = $data;
			}
		}

		return $results;

	}

	/**
	 * Find small room by id
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function smallRoomIDAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // get value from requested
		if ( ! empty( $query ) ) {
			
			$room = get_post( (int) $query );
			if ( ! is_wp_error( $room ) ) {
				
				$room_id = $room->ID;
				$room_title = $room->post_title;
				
				$room_title_display = '';
				if ( ! empty( $portfolio_title ) ) {
					$room_title_display = ' - ' . esc_html__( 'Title', 'eltd-hotel' ) . ': ' . $room_title;
				}
				
				$room_id_display = esc_html__( 'Id', 'eltd-hotel' ) . ': ' . $room_id;

				$data          = array();
				$data['value'] = $room_id;
				$data['label'] = $room_id_display . $room_title_display;

				return ! empty( $data ) ? $data : false;
			}

			return false;
		}

		return false;
	}

	/**
	 * Filter big room by ID or Title
	 *
	 * @param $query
	 *
	 * @return array
	 */
	public function bigRoomIDAutocompleteSuggester( $query ) {
		global $wpdb;
		$room_id = (int) $query;
		$post_meta_infos = $wpdb->get_results( $wpdb->prepare( "SELECT ID AS id, post_title AS title
					FROM {$wpdb->posts}
					WHERE post_type = 'hotel-room' AND ( ID = '%d' OR post_title LIKE '%%%s%%' )", $room_id > 0 ? $room_id : - 1, stripslashes( $query ), stripslashes( $query ) ), ARRAY_A );

		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data = array();
				$data['value'] = $value['id'];
				$data['label'] = esc_html__( 'Id', 'eltd-hotel' ) . ': ' . $value['id'] . ( ( strlen( $value['title'] ) > 0 ) ? ' - ' . esc_html__( 'Title', 'eltd-hotel' ) . ': ' . $value['title'] : '' );
				$results[] = $data;
			}
		}

		return $results;

	}

	/**
	 * Find big room by id
	 * @since 4.4
	 *
	 * @param $query
	 *
	 * @return bool|array
	 */
	public function bigRoomIDAutocompleteRender( $query ) {
		$query = trim( $query['value'] ); // get value from requested
		if ( ! empty( $query ) ) {

			$room = get_post( (int) $query );
			if ( ! is_wp_error( $room ) ) {

				$room_id = $room->ID;
				$room_title = $room->post_title;

				$room_title_display = '';
				if ( ! empty( $portfolio_title ) ) {
					$room_title_display = ' - ' . esc_html__( 'Title', 'eltd-hotel' ) . ': ' . $room_title;
				}

				$room_id_display = esc_html__( 'Id', 'eltd-hotel' ) . ': ' . $room_id;

				$data          = array();
				$data['value'] = $room_id;
				$data['label'] = $room_id_display . $room_title_display;

				return ! empty( $data ) ? $data : false;
			}

			return false;
		}

		return false;
	}


	public function getTrimStyles( $params ) {
		$styles = array();

		if (!empty($params['trim_background_color'])) {
			$styles[] = 'border-color: ' . $params['trim_background_color'] . ';';
		}

		return implode( ';', $styles );
	}
}