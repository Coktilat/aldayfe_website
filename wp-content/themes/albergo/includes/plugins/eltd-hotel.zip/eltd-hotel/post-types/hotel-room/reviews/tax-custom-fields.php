<?php

if ( ! function_exists( 'eltd_hotel_room_reviews_fields' ) ) {
	function eltd_hotel_room_reviews_fields() {

		$hotel_room_fields = albergo_elated_add_taxonomy_fields( array(
				'scope' => 'review-tag',
				'name'  => 'review_tag'
			) );

		albergo_elated_add_taxonomy_field( array(
				'name'        => 'review_room_order',
				'type'        => 'text',
				'label'       => esc_html__( 'Order', 'eltd-hotel' ),
				'description' => esc_html__( 'If there are multiple criteria, they will be displayed in an ascending order.', 'eltd-hotel' ),
				'parent'      => $hotel_room_fields
			) );

		albergo_elated_add_taxonomy_field( array(
				'name'        => 'main_review_criterion',
				'type'        => 'selectblank',
				'label'       => esc_html__( 'Show in Reviews', 'eltd-hotel' ),
				'description' => esc_html__( 'All the criteria can be rated when leaving a review, but only those marked to be shown will be displayed in the list of reviews.', 'eltd-hotel' ),
				'options'     => array(
					'no'  => esc_html__( 'No', 'eltd-hotel' ),
					'yes' => esc_html__( 'Yes', 'eltd-hotel' ),
				),
				'parent'      => $hotel_room_fields
			) );
	}

	add_action( 'albergo_elated_custom_taxonomy_fields', 'eltd_hotel_room_reviews_fields' );
}

if ( ! function_exists( 'eltd_hotel_room_review_tag_columns' ) ) {
	function eltd_hotel_room_review_tag_columns( $columns ) {
		$new_columns = array(
			'cb'             => '<input type="checkbox" />',
			'name'           => esc_html__( 'Name', 'eltd-hotel' ),
			'slug'           => esc_html__( 'Slug', 'eltd-hotel' ),
			'review_order' => esc_html__( 'Order', 'eltd-hotel' ),
			'main_review_criterion' => esc_html__( 'Shown in Reviews', 'eltd-hotel' ),
		);

		return $new_columns;
	}

	add_filter( "manage_room_edit-review-tag_columns", 'eltd_hotel_room_review_tag_columns' );
}

if ( ! function_exists( 'eltd_hotel_room_review_tag_column_values' ) ) {
	function eltd_hotel_room_review_tag_column_values( $out, $column_name, $term_id ) {
		$term_meta = get_term_meta( $term_id );
		switch ( $column_name ) {
			case 'review_order':
				$out .= isset( $term_meta['review_order'][0] ) ? $term_meta['review_order'][0] : '-';
				break;
			case 'main_criterion':
				$out .= ( isset( $term_meta['main_review_criterion'][0] ) && $term_meta['main_review_criterion'][0] == 'yes' ) ? esc_html__( 'Yes', 'eltd-hotel' ) : esc_html__( 'No', 'eltd-hotel' );
				break;

			default:
				break;
		}

		return $out;
	}

	add_filter( "manage_room_review-tag_custom_column", 'eltd_hotel_room_review_tag_column_values', 10, 3 );
}