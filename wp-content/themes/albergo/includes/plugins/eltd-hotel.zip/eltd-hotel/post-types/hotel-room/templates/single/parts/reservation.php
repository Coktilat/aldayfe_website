<?php
extract( apply_filters( 'albergo_elated_hotel_single_reservation_params', array() ) );
$input_array = apply_filters( 'albergo_elated_extra_services', array() );
$today  = date('Y-m-d');
$tomorrow  = date('Y-m-d', mktime(0, 0, 0, date("m")  , date("d")+1, date("Y")));
?>

<div class="eltd-hotel-room-reservation-holder">
    <h4>
        <b><?php esc_html_e( 'Your ', 'eltd-hotel' ); ?></b>
		<?php esc_html_e( 'Reservation', 'eltd-hotel' ); ?>
    </h4>
    <div class="eltd-hotel-room-reservation" data-room-id="<?php echo get_the_ID(); ?>">
        <form id="eltd-hotel-room-form" method="POST">
	        <?php wp_nonce_field('eltd_hotel_room_booking_form', 'eltd_hotel_room_booking_form'); ?>
            <div class="eltd-grid-row">
                <div class="eltd-grid-col-12">
                    <span class="eltd-input-email">
                        <label>Email:</label>
                        <input type="text" class="eltd-res-email" name="user_email"
                               placeholder="<?php esc_html_e( 'Need to be logged in', 'eltd-hotel' ) ?>" disabled value="<?php echo esc_attr($email) ?>" />
                    </span>
                </div>
                <div class="eltd-grid-col-12">
                    <span class="eltd-input-min-date">
                        <label>Check in</label>
                        <input type="text" class="eltd-res-min-date" name="room_min_date"
                           placeholder="<?php esc_html_e( 'Check-in', 'eltd-hotel' ) ?>" value="<?php echo esc_attr($today) ?>" />
                    </span>
                </div>
                <div class="eltd-grid-col-12">
                    <span class="eltd-input-max-date">
                        <label>Check out</label>
                        <input type="text" class="eltd-res-max-date" name="room_max_date"
                           placeholder="<?php esc_html_e( 'Check-out', 'eltd-hotel' ) ?>" value="<?php echo esc_attr($tomorrow) ?>" />
                    </span>
                </div>
                <div class="eltd-grid-col-12">
                    <span class="eltd-input-rooms-number">
                        <label for="eltd-res-rooms-number">Rooms:</label>
                        <select id="eltd-res-rooms-number" name="room_number" class="eltd-res-rooms-number">
                            <?php for ( $i = 1; $i <= $number_of_rooms; $i ++ ) { ?>
                                <option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
                            <?php } ?>
                        </select>
                    </span>
                </div>
                <div class="eltd-grid-col-12">
                    <span class="eltd-input-adults">
                        <label for="eltd-res-adults">Adults:</label>
                        <select id="eltd-res-adults" name="room_adults" class="eltd-res-adults">
                            <option value="0">0</option>
                            <?php for ( $i = 1; $i <= $adults; $i ++ ) { ?>
                                <option <?php echo ($adults == $i) ? 'selected="selected"' : ''; ?> value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
                            <?php } ?>
                        </select>
                    </span>
                </div>
                <div class="eltd-grid-col-12">
                    <span class="eltd-input-children">
                        <label for="eltd-res-children">Children:</label>
                    <select id="eltd-res-children" name="room_children" class="eltd-res-children" data-max-children="0">
                            <option value="0">0</option>
                        <?php for ( $i = 1; $i <= $children; $i ++ ) { ?>
                            <option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
                        <?php } ?>
                        </select>
                    </span>
                </div>
                <div class="eltd-grid-col-12">
                    <div class="eltd-input-extra-services-on-res">
                        <label>Extra Services:</label>
                        <div class="eltd-res-extra-services-holder" id="eltd-res-extra-services-holder">
                            <?php

                            foreach ( $input_array as $service_pack => $value ) { ?>

                                <div class="eltd-res-extra-service-item" <?php echo albergo_elated_get_inline_attrs($value['data']) ?>>
                                    <label class="eltd-checkbox-label"
                                           for="<?php echo esc_attr( $value['exs_id'] ); ?>">
                                        <input type="checkbox" <?php  echo ! empty( $value['type'] ) && $value['type'] == 'mandatory' ? 'checked disabled' : ''; ?>
                                               class="eltd-res-extra-service-checkbox" id="<?php echo esc_attr( $value['exs_id'] ); ?>"
                                               name="checked_extra_services[]" value="<?php echo esc_attr( $value['exs_id'] ); ?>"/>
                                        <span class="eltd-checkbox-frame icon_check ">
                                        </span>
                                        <span class="eltd-label-text">
                                            <?php echo esc_attr($value['name']); ?>
                                        </span>
                                    </label>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="eltd-grid-col-12">
                    <div class="eltd-input-initial-price-on-res">
                        <label>Initial Price:</label>
                        <span class="eltd-res-initial-price" id="eltd-res-initial-price">
                                <span class="eltd-res-price-number"><?php echo esc_attr( intval( $initial_price ) ) ?></span><span
                                    class="eltd-res-price-currency"><?php echo esc_attr( $currency ) ?></span>
                            </span>
                    </div>
                </div>
                <div class="eltd-grid-col-12">
                    <div class="eltd-input-end-price-on-res">
                        <label>Your Price:</label>
                        <span class="eltd-res-end-price" id="eltd-res-end-price">
                                <span class="eltd-res-price-number"><?php echo esc_attr( intval( $initial_price ) ) ?></span><span
                                    class="eltd-res-price-currency"><?php echo esc_attr( $currency ) ?></span>
                            </span>
                    </div>
                </div>
                <div class="eltd-grid-col-12">
                    <?php
                    if ( albergo_elated_core_plugin_installed() ) {
	                    if ( ! $in_cart ) {
		                    echo albergo_elated_get_button_html( array(
			                    'html_type'    => 'input',
			                    'input_name'   => 'submit',
			                    'custom_class' => 'eltd-hotel-room-single-res-button',
			                    'size'         => 'medium',
			                    'type'         => 'solid',
			                    'text'         => esc_html__( 'Check', 'eltd-hotel' )
		                    ) );
	                    }
                    }
                    ?>
                    <input type="hidden" name="room_id" value="<?php echo esc_attr(get_the_ID()); ?>">
                </div>
            </div>
            <div id="reservation-validation-messages-holder"></div>
        </form>
	    <?php
	    if ( albergo_elated_core_plugin_installed() ) {
		    if ( ! $in_cart ) {
			    echo albergo_elated_get_button_html( array(
				    'custom_class' => 'eltd-hotel-room-reservation-similar eltd-disable-hotel-room-single-btn',
				    'size'         => 'medium',
				    'link'         => eltd_hotel_room_get_search_page_url(),
				    'type'         => 'solid',
				    'text'         => esc_html__( 'Similar x', 'eltd-hotel' )
			    ) );
			    ?>
			    <?php echo eltd_hotel_room_get_buy_form();
		    } else {
			    echo albergo_elated_get_button_html( array(
				    'custom_class' => 'eltd-hotel-room-reservation-cart',
				    'size'         => 'medium',
				    'link'         => esc_url( wc_get_cart_url() ),
				    'type'         => 'solid',
				    'text'         => esc_html__( 'View Cart', 'eltd-hotel' )
			    ) );
		    }
	    }?>
    </div>
</div>