<?php

if ( ! function_exists( 'eltd_hotel_room_shop_extra_services' ) ) {
	/**
	 * This function create information for checkboxes on reservation golder on hotel room single
	 *
	 * @param array $input_array
	 *
	 * @return array
	 */
	function eltd_hotel_room_shop_extra_services( $input_array = array() ) {

		$services = apply_filters( 'albergo_elated_hotel_single_extra_services_params', array());

		$i = 0;
		foreach ( $services['extra_services'] as $key => $extra_service ) {
			$input_array[ $i ]['name'] = $extra_service['name'];
			$input_array[ $i ]['info'] = eltd_hotel_room_get_extra_service_string( $extra_service );
			$input_array[ $i ]['data'] = array();

			// create id based on service public/single + id.
			// Global id is from taxonomy and local is meta field
			if($extra_service['global'] == 'yes') {
				$apr = 'public';
			} else {
				$apr = 'single';
			}

			$input_array[$i]['exs_id']                          = 'es-'.$apr.'-id-'.$key;

			if ( $extra_service['type'] != '' ) {
				$input_array[$i]['type']                        = $extra_service['type'];
			}
			if ( $extra_service['service_pack'] != '' ) {
				$input_array[$i]['data']['data-service-pack']   = $extra_service['service_pack'];
			}
			if ( $extra_service['price'] != '' ) {
				$input_array[$i]['data']['data-price']          = $extra_service['price'];
			}
			if ( $extra_service['percent'] != '' ) {
				$input_array[$i]['data']['data-percent']        = $extra_service['percent'];
			}

			$i++;

		}


		return $input_array;
	}

	add_filter( 'albergo_elated_extra_services', 'eltd_hotel_room_shop_extra_services');
}

if ( ! function_exists( 'eltd_hotel_room_disable_dc_quantity' ) ) {
	/**
	 * This function send false through albergo_elated_woo_cart_enable_quantity false
	 *
	 * @param bool
	 *
	 * @return array
	 */
	function eltd_hotel_room_disable_dc_quantity() {

		return false;
	}

	add_filter( 'albergo_elated_woo_cart_enable_quantity', 'eltd_hotel_room_disable_dc_quantity');
}

if ( ! function_exists( 'eltd_hotel_room_shop_create_reservation' ) ) {
	/**
	 * This function create reserved room
	 *
	 */
	function eltd_hotel_room_shop_create_reservation($order_id) {

		/*
		 * for each room which exist in session
		 * get that room all reserved dates
		 * merge with new reserved dates
		 * updated all dates with new array
		 */

		if(isset($_SESSION) && isset($_SESSION['rooms'])) {
			foreach ( $_SESSION['rooms'] as $room ) {

				$old_rooms = get_post_meta($room['item_id'],'eltd_room_date_meta', true);
				if($old_rooms == '' || empty($old_rooms)) {
					$old_rooms = array();
				}

				$new_rooms = array();

				foreach ( $room['free_rooms'] as $free_room ) {
					$new_rooms[] = array(
						'date_begin' => $room['room_min_date'],
						'date_end' => $room['room_max_date'],
						'number_of_room' => $free_room,
						'adults'   => $room['room_adults'],
						'children' => $room['room_children'],
						'order_id' => $order_id,
						'additional_info' => $room['additional_info']);
				}

				$result = (array_merge($new_rooms, $old_rooms));

				update_post_meta( $room['item_id'], 'eltd_room_date_meta', $result );
			}
            $_SESSION['rooms'] = array();
		}
	}

	add_action( 'woocommerce_checkout_update_order_meta', 'eltd_hotel_room_shop_create_reservation' );
}


if ( ! function_exists( 'eltd_hotel_room_shop_handle_reservation' ) ) {
    function eltd_hotel_room_shop_handle_reservation($order_id, $status_from, $status_to, $order) {
        $items_list      = apply_filters( 'albergo_elated_custom_product_types', 'line_item' );
        if($status_to === 'cancelled' || $status_to === 'refunded' || $status_to === 'failed') {
            $items = $order->get_items( $items_list );
            foreach ($items as $item) {
                if (is_a($item, 'WC_Order_Item_Hotel_Room')) {
                    $room_id = $item->get_product_id();
                    $room_reservations = get_post_meta($room_id,'eltd_room_date_meta', true);
                    foreach ($room_reservations as $key => $reservation) {
                        if($reservation['order_id'] == $order_id) {
                            unset($room_reservations[$key]);
                        }
                    }
                    //RESET INDEXES FROM 0
                    $room_reservations = array_values( $room_reservations );
                    update_post_meta($room_id, 'eltd_room_date_meta', $room_reservations );
                }
            }
        }
    }

    add_action('woocommerce_order_status_changed', 'eltd_hotel_room_shop_handle_reservation', 10, 4);
}



