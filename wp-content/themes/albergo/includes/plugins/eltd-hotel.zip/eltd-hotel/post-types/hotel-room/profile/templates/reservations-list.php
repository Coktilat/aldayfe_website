<div class="eltd-hotel-profile-reservations-holder">
<?php if(!empty($customer_orders)) { ?>
    <?php
	foreach($customer_orders as $customer_order) {
        $id = $customer_order['product_id'];
        $name = $customer_order['name'];
        $order_status = $customer_order['order_status'];
        $order_completed = $order_status == 'completed' ? true : false;
	    ?>
        <div class="eltd-hotel-profile-reservations-item">
            <div class="eltd-hotel-profile-reservations-item-image">
                <?php
                if (has_post_thumbnail($id)) {
                    $image = get_the_post_thumbnail_url($id, 'thumbnail');
                } else {
                    $image = ELTD_CPT_URL_PATH.'/hotel-room/assets/img/hotel_room_featured_image.jpg';
                }
                ?>
                <img src="<?php echo esc_attr($image); ?>" alt="<?php echo esc_attr('Hotel room thumbnail', 'eltd-hotel') ?>"/>
            </div>
            <div class="eltd-hotel-profile-reservations-item-title">
                <h4>
                    <a href="<?php echo get_the_permalink($id); ?>">
                        <?php echo esc_html($name); ?>
                    </a>
                    <span>
                        <?php echo '(' . wc_get_order_status_name($order_status) . ')'; ?>
                    </span>
                </h4>
            </div>
        </div>
    <?php
    }
 } else { ?>
    <h3><?php esc_html_e("Your reservations list is empty.", 'eltd-hotel') ?> </h3>
    <a href="<?php echo eltd_hotel_room_get_search_page_url() ?>" title="Hotel Rooms Page"><?php esc_html_e("Go to Rooms", 'eltd-hotel'); ?></a>
<?php } ?>
</div>