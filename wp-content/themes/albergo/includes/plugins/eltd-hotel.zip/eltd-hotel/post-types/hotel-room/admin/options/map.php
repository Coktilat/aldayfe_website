<?php

if(!function_exists('eltd_hotel_room_options_map')) {

	function eltd_hotel_room_options_map() {

		$search_pages =  eltd_hotel_room_get_search_pages(true);

		$search_panel = albergo_elated_add_admin_panel(array(
			'title' => esc_html__('Search Page', 'eltd-hotel'),
			'name'  => 'panel_hotel_room_search',
			'page'  => '_hotel'
		));

		albergo_elated_add_admin_field(array(
			'parent'        => $search_panel,
			'type'          => 'select',
			'name'          => 'hotel_room_search_main_page',
			'default_value' => '',
			'label'         => esc_html__('Main Search Page', 'eltd-hotel'),
			'description'   => esc_html__('Choose main search page. Defaults to hotel rooms archive page', 'eltd-hotel'),
			'options'       => $search_pages,
			'args'          => array(
				'col_width' => 3
			)
		));

		albergo_elated_add_admin_field(array(
			'parent'        => $search_panel,
			'type'          => 'text',
			'name'          => 'hotel_room_per_page',
			'default_value' => 12,
			'label'         => esc_html__('Items per Page', 'eltd-hotel'),
			'description'   => esc_html__('Choose number of hotel rooms per page', 'eltd-hotel'),
			'args'          => array(
				'col_width' => 3
			)
		));

		albergo_elated_add_admin_field(array(
			'parent'        => $search_panel,
			'type'          => 'select',
			'name'          => 'hotel_room_search_default_view_type',
			'default_value' => 'gallery',
			'label'         => esc_html__('Default Hotel Room View Type', 'eltd-hotel'),
			'description'   => esc_html__('Choose default Hotel room view type', 'eltd-hotel'),
			'options'       => array(
				'gallery'     => esc_html__('Gallery', 'eltd-hotel'),
				'standard' => esc_html__('Standard', 'eltd-hotel'),
				'divided'  => esc_html__('Divided', 'eltd-hotel')
			),
			'args'          => array(
				'col_width' => 3
			)
		));

		albergo_elated_add_admin_field(array(
			'parent'        => $search_panel,
			'type'          => 'select',
			'name'          => 'hotel_room_search_columns',
			'default_value' => '3',
			'label'         => esc_html__('Number of Columns', 'eltd-hotel'),
			'description'   => esc_html__('Choose number of columns on search page', 'eltd-hotel'),
			'options'       => array(
				''     => esc_html__('Default', 'eltd-hotel'),
				'1' => esc_html__('One', 'eltd-hotel'),
				'2'  => esc_html__('Two', 'eltd-hotel'),
				'3'  => esc_html__('Three', 'eltd-hotel'),
				'4'  => esc_html__('Four', 'eltd-hotel'),
				'5'  => esc_html__('Five', 'eltd-hotel'),
				'6'  => esc_html__('Six', 'eltd-hotel'),
			),
			'args'          => array(
				'col_width' => 3
			)
		));

		albergo_elated_add_admin_field(array(
			'parent'        => $search_panel,
			'type'          => 'select',
			'name'          => 'hotel_room_search_image_proportion',
			'default_value' => 'portrait',
			'label'         => esc_html__('Image Proportion', 'eltd-hotel'),
			'description'   => esc_html__('Choose image proportion on search page', 'eltd-hotel'),
			'options'       => array(
				'full' => esc_html__( 'Original', 'eltd-hotel' ),
				'square' => esc_html__( 'Square', 'eltd-hotel' ),
				'landscape' => esc_html__( 'Landscape', 'eltd-hotel' ),
				'portrait' => esc_html__( 'Portrait', 'eltd-hotel' ),
				'thumbnail' => esc_html__( 'Thumbnail', 'eltd-hotel' ),
				'medium' => esc_html__( 'Medium', 'eltd-hotel' ),
				'large' => esc_html__( 'Large', 'eltd-hotel' )
			),
			'args'          => array(
				'col_width' => 3
			)
		));

		albergo_elated_add_admin_field(array(
			'parent'        => $search_panel,
			'type'          => 'select',
			'name'          => 'hotel_room_search_default_ordering',
			'default_value' => 'date',
			'label'         => esc_html__('Default Hotel Room Ordering', 'eltd-hotel'),
			'description'   => esc_html__('Choose default hotel room ordering', 'eltd-hotel'),
			'options'       => eltd_hotel_room_get_room_sorting_options(),
			'args'          => array(
				'col_width' => 3
			)
		));

		$panel_hotel_room_single = albergo_elated_add_admin_panel(array(
			'title' => esc_html__('Hotel Room Single', 'eltd-hotel'),
			'name'  => 'panel_hotel_room_single',
			'page'  => '_hotel'
		));

		albergo_elated_add_admin_field(
			array(
				'name'          => 'hotel_room_featured_item',
				'type'          => 'select',
				'default_value' => '',
				'label'         => esc_html__('Choose element on the top', 'eltd-hotel'),
				'description'   => esc_html__('This option will set first element on single item ', 'eltd-hotel'),
				'options'     => array(
					''  => esc_html__( 'Default', 'eltd-hotel' ),
					'featured_image' => esc_html__( 'Featured Image', 'eltd-hotel' ),
					'slider' => esc_html__( 'Slider (from gallery)', 'eltd-hotel' ),
				),
				'parent'        => $panel_hotel_room_single,
			)
		);

		albergo_elated_add_admin_section_title( array(
			'title'       => esc_html__( 'Tabs', 'eltd-hotel' ),
			'description' => esc_html__( 'Enable items for single room', 'eltd-hotel' ),
			'name'        => 'hotel_room_single_tab_title',
			'parent'      => $panel_hotel_room_single
		) );

		albergo_elated_add_admin_field(
			array(
				'name'          => 'hotel_room_enable_amenities',
				'type'          => 'yesno',
				'default_value' => 'yes',
				'label'         => esc_html__('Enable Amenities', 'eltd-hotel'),
				'description'   => esc_html__('This option will enable/disable Amenities ', 'eltd-hotel'),
				'parent'        => $panel_hotel_room_single,
			)
		);

		albergo_elated_add_admin_field(
			array(
				'name'          => 'hotel_room_enable_gallery',
				'type'          => 'yesno',
				'default_value' => 'yes',
				'label'         => esc_html__('Enable Gallery', 'eltd-hotel'),
				'description'   => esc_html__('This option will enable/disable Gallery ', 'eltd-hotel'),
				'parent'        => $panel_hotel_room_single,
			)
		);

		albergo_elated_add_admin_field(
			array(
				'name'          => 'hotel_room_enable_extra_services',
				'type'          => 'yesno',
				'default_value' => 'yes',
				'label'         => esc_html__('Enable Extra Services', 'eltd-hotel'),
				'description'   => esc_html__('This option will enable/disable Extra Services ', 'eltd-hotel'),
				'parent'        => $panel_hotel_room_single,
			)
		);

		albergo_elated_add_admin_field(
			array(
				'name'          => 'hotel_room_enable_location',
				'type'          => 'yesno',
				'default_value' => 'yes',
				'label'         => esc_html__('Enable Location', 'eltd-hotel'),
				'description'   => esc_html__('This option will enable/disable Location ', 'eltd-hotel'),
				'parent'        => $panel_hotel_room_single,
			)
		);

		albergo_elated_add_admin_field(
			array(
				'name'          => 'hotel_room_enable_reviews',
				'type'          => 'yesno',
				'default_value' => 'yes',
				'label'         => esc_html__('Enable Reviews', 'eltd-hotel'),
				'description'   => esc_html__('This option will enable/disable Reviews ', 'eltd-hotel'),
				'parent'        => $panel_hotel_room_single,
			)
		);
	}

	add_action('eltd_hotel_room_action_single_fields', 'eltd_hotel_room_options_map', 11);
}