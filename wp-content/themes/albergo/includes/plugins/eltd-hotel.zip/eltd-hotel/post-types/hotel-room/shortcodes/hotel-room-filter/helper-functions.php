<?php
if(!function_exists('eltd_hotel_room_hotel_room_filter_shortcode_helper')) {
    function eltd_hotel_room_hotel_room_filter_shortcode_helper($shortcodes_class_name) {
        $shortcodes = array(
            'ElatedHotel\CPT\Shortcodes\HotelRoomFilter\HotelRoomFilter'
        );

        $shortcodes_class_name = array_merge($shortcodes_class_name, $shortcodes);

        return $shortcodes_class_name;
    }

    add_filter('eltd_hotel_add_vc_shortcode', 'eltd_hotel_room_hotel_room_filter_shortcode_helper');
}

if( !function_exists('eltd_hotel_room_set_hotel_room_filter_icon_class_name_for_vc_shortcodes') ) {
    /**
     * Function that set custom icon class name for hotel room filter shortcode to set our icon for Visual Composer shortcodes panel
     */
    function eltd_hotel_room_set_hotel_room_filter_icon_class_name_for_vc_shortcodes($shortcodes_icon_class_array) {
        $shortcodes_icon_class_array[] = '.icon-wpb-hotel-room-filter';

        return $shortcodes_icon_class_array;
    }

    add_filter('eltd_hotel_filter_add_vc_shortcodes_custom_icon_class', 'eltd_hotel_room_set_hotel_room_filter_icon_class_name_for_vc_shortcodes');
}