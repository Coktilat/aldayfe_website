<?php
$extra_service_set        = isset($params['amenity-tag']) && $params['amenity-tag'] !== '';
$hide_active_filter = isset($params['hide_active_filter']) && $params['hide_active_filter'] === 'yes';
$extra_services           = eltd_hotel_get_taxonomy_list('extra-service-tag');
$room_extra_services  = explode(',', $room_extra_services);
?>
<?php if( !$extra_service_set || ( $extra_service_set && !$hide_active_filter)) { ?>
<div class="eltd-filter-section eltd-filter-section-9 eltd-section-extra-services">
    <div class="eltd-filter-extra-services-holder">
        <div class="eltd-filter-extra-services-wrapper clearfix">
            <?php foreach ($extra_services as $key => $extra_service) { ?>
                <div class="eltd-extra-service-item">
                    <input type="checkbox" <?php echo !empty($room_extra_services) && in_array($key, $room_extra_services) ? 'checked' : ''; ?> class="eltd-extra-service-cb" data-id="<?php echo esc_attr($key); ?>" id="eltd-extra-service-<?php echo esc_attr($key); ?>" name="eltd-extra-services[]" value="" />
                    <label class="eltd-checkbox-label" for="eltd-extra-service-<?php echo esc_attr($key); ?>">
                        <span class="eltd-label-view"></span>
                        <span class="eltd-label-text">
                            <?php echo esc_html($extra_service); ?>
                        </span>
                    </label>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<?php } ?>