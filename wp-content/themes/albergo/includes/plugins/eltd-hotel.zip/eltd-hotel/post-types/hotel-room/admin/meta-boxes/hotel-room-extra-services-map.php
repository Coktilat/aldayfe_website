<?php
if(eltd_hotel_theme_installed()) {
	if ( ! function_exists( 'eltd_hotel_room_map_room_extra_service_meta' ) ) {
		function eltd_hotel_room_map_room_extra_service_meta( $hotel_room_extra_services_meta_box ) {

			/* get all extra services */
			$hotel_extra_services = eltd_hotel_room_get_extra_services();

			/* get currency */
			$currency = eltd_hotel_room_get_currency();

			/* printing meta boxes */

			$hotel_room_extra_services_meta_box = albergo_elated_add_meta_box( array(
					'scope' => array( 'hotel-room' ),
					'title' => esc_html__( 'Hotel Room Extra Services', 'eltd-hotel' ),
					'name'  => 'hotel_room_extra_services_item_meta'
				) );

			if ( is_array( $hotel_extra_services ) && count( $hotel_extra_services ) ) {

				albergo_elated_add_meta_box_field( array(
					'name'          => 'eltd_hotel_room_extra_service_meta',
					'type'          => 'checkboxgroup',
					'default_value' => '',
					'label'         => esc_html__( 'Extra Services', 'eltd-hotel' ),
					'description'   => esc_html__( 'Define room extra services', 'eltd-hotel' ),
					'parent'        => $hotel_room_extra_services_meta_box,
					'options'       => $hotel_extra_services
				) );
			}

			$hotel_room_extra_service_container = albergo_elated_add_admin_container( array(
				'type'   => 'container',
				'name'   => 'hotel_room_extra_service_container',
				'parent' => $hotel_room_extra_services_meta_box
			) );

			albergo_elated_add_admin_section_title( array(
				'title'       => esc_html__( 'Additional Extra Service', 'eltd-hotel' ),
				'description' => esc_html__( 'Add extra service only for this Single Room', 'eltd-hotel' ),
				'name'        => 'hotel_room_extra_service_container_title',
				'parent'      => $hotel_room_extra_service_container
			) );

			albergo_elated_add_repeater_field( array(
				'name'        => 'eltd_additional_extra_service_meta',
				'parent'      => $hotel_room_extra_service_container,
				'button_text' => '',
				'fields'      => array_merge( array(
					array(
						'type'        => 'text',
						'name'        => 'name',
						'label'       => esc_html__( 'Name', 'eltd-hotel' ),
						'col_width'   => '6'
					),
					array(
						'type'        => 'textarea',
						'name'        => 'description',
						'label'       => esc_html__( 'Description', 'eltd-hotel' ),
						'col_width'   => '12'
					),
					array(
						'type'        => 'select',
						'name'        => 'type',
						'label'       => esc_html__( 'Type', 'eltd-hotel' ),
						'options'     => array(
							'optional'  => esc_html__( 'Optional', 'eltd-hotel' ),
							'mandatory' => esc_html__( 'Mandatory', 'eltd-hotel' ),
						),
						'col_width'   => '6',
						'args'        => array(
							'col_width' => 12,
							'select2'  => true
						),
					),
					array(
						'type'        => 'select',
						'name'        => 'service_pack',
						'label'       => esc_html__( 'Service Pack', 'eltd-hotel' ),
						'options'     => eltd_hotel_room_get_service_packs(),
						'col_width'   => '6',
						'args'        => array(
							'col_width' => 12,
							'select2'  => true
						),
					),
					array(
						'type'        => 'text',
						'name'        => 'price',
						'label'       => esc_html__( 'Price', 'eltd-hotel' ),
						'col_width'   => '6',
						'args'        => array(
							'suffix' => $currency,

						),
					),
					array(
						'type'        => 'text',
						'name'        => 'percent',
						'label'       => esc_html__( 'Percent', 'eltd-hotel' ),
						'col_width'   => '6',
						'args'        => array(
							'suffix' => '%',

						),
					),

				) )
			) );

		}

		add_action( 'albergo_elated_meta_boxes_map', 'eltd_hotel_room_map_room_extra_service_meta');
	}
}