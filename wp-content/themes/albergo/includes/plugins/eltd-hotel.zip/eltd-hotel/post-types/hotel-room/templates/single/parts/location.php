<?php extract(apply_filters('albergo_elated_hotel_single_location_params', array())); ?>
<div class="eltd-hotel-room-location eltd-hotel-room-label-items-holder">
    <div class="eltd-hotel-room-map-address eltd-hotel-room-items-style">
        <div class="eltd-grid-row">

            <?php if (isset($location) && $location != '' || isset($country) && $country != '') { ?>
                <div class="eltd-grid-col-4">
                    <div class="eltd-label-items-label">
                        <h5><?php esc_html_e('City', 'eltd-hotel'); ?></h5>
                    </div>
                    <?php if (isset($location) && ($location != '')) { ?>
                        <div class="eltd-label-items-item">
                            <?php echo esc_html($location->name); ?>
                        </div>
                    <?php }
                    if (isset($country) && ($country != '')) { ?>
                        <div class="eltd-label-items-item">
                            <?php echo esc_html($country); ?>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>

            <?php if (isset($simple_address) && $simple_address != '' || isset($phone) && $phone != '') { ?>
                <div class="eltd-grid-col-4">
                    <div class="eltd-label-items-label">
                        <h5><?php esc_html_e('Hotel contact', 'eltd-hotel'); ?></h5>
                    </div>
                    <?php if (isset($phone) && ($phone != '')) { ?>
                    <div class="eltd-label-items-item">
		                <?php echo esc_html($phone); ?>
                    </div>
	                <?php } ?>
                    <?php if (isset($simple_address) && ($simple_address != '')) { ?>
                        <div class="eltd-label-items-item">
                            <?php echo esc_html($simple_address); ?>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>


            <?php if (isset($email) && $email != '') { ?>
                <div class="eltd-grid-col-4">
                    <div class="eltd-label-items-label">
                        <h5><?php esc_html_e('Reservations', 'eltd-hotel'); ?></h5>
                    </div>
                    <div class="eltd-label-items-item">
                        <?php echo esc_html($email); ?>
                    </div>
                </div>
            <?php } ?>

        </div>
    </div>
</div>