(function($) {
    'use strict';

    var hotelRoomFilter = {};
    eltd.modules.hotelRoomFilter = hotelRoomFilter;

    hotelRoomFilter.eltdOnDocumentReady = eltdOnDocumentReady;
    hotelRoomFilter.eltdOnWindowLoad = eltdOnWindowLoad;
    hotelRoomFilter.eltdOnWindowResize = eltdOnWindowResize;
    hotelRoomFilter.eltdOnWindowScroll = eltdOnWindowScroll;

    $(document).ready(eltdOnDocumentReady);
    $(window).load(eltdOnWindowLoad);
    $(window).resize(eltdOnWindowResize);
    $(window).scroll(eltdOnWindowScroll);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function eltdOnDocumentReady() {
        eltdInitHotelRoomFilter();
    }

    /*
     All functions to be called on $(window).load() should be in this function
     */
    function eltdOnWindowLoad() {
    }

    /*
     All functions to be called on $(window).resize() should be in this function
     */
    function eltdOnWindowResize() {

    }

    /*
     All functions to be called on $(window).scroll() should be in this function
     */
    function eltdOnWindowScroll() {
    }

    function eltdInitHotelRoomFilter() {
        var filters = $('.eltd-hotel-filters');
        if (filters.length) {

            filters.each(function () {
                var filter = $(this),
                    roomNumber = filter.find('.eltd-filter-rooms-number'),
                    location = filter.find('.eltd-filter-location'),
                    adults = filter.find('.eltd-filter-adults'),
                    children = filter.find('.eltd-filter-children'),
                    minDate = filter.find('.eltd-filter-min-date'),
                    maxDate = filter.find('.eltd-filter-max-date');

                //INIT ROOMS FIELD

                var selectRoomNumber = roomNumber;
                if (selectRoomNumber.length) {
                    selectRoomNumber.select2({
                        minimumResultsForSearch: -1
                    }).on('select2:select', function (e) {
                    });
                }

                //INIT LOCATION FIELD

                var selectLocation = location;
                if (selectLocation.length) {
                    selectLocation.select2({
                        minimumResultsForSearch: -1
                    }).on('select2:select', function (e) {
                    });
                }

                //INIT ADULTS FIELD

                var selectAdults = adults;
                if (selectAdults.length) {
                    selectAdults.select2({
                        minimumResultsForSearch: -1
                    }).on('select2:select', function (e) {
                    });
                }


                //INIT ADULTS FIELD

                var selectChildren = children;
                if (selectChildren.length) {
                    selectChildren.select2({
                        minimumResultsForSearch: -1
                    }).on('select2:select', function (e) {
                    });
                }


                //INIT DATE CHECK-IN FIELD
                if (minDate.length) {
                    minDate.datepicker({
                        minDate: '0',
                        dateFormat: 'yy-mm-dd'
                    }).change(function (e) {
                    })
                }

                //INIT DATE CHECK-OUT FIELD
                if (maxDate.length) {
                    maxDate.datepicker({
                        minDate: '+1d',
                        dateFormat: 'yy-mm-dd'
                    }).change(function (e) {
                    })
                }
            });

        }
    }


})(jQuery);