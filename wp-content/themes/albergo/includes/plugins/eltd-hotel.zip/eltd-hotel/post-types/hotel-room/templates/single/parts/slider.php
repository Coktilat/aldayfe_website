<?php extract( apply_filters( 'albergo_elated_hotel_single_slider_params', array() ) );

if($slider_images !== '') :

    $slider_images_array = explode( ',', $slider_images );
    if ( isset( $slider_images_array ) && count( $slider_images_array ) ) : ?>

    <div class="eltd-owl-slider-holder eltd-custom-nav eltd-custom-nav-right eltd-hide-pagination">
        <div class="eltd-owl-slider" data-enable-thumbnail='yes' data-enable-navigation="yes" data-enable-custom-navigation="yes" data-enable-pagination="yes">
            <?php
            for ( $i = 0; $i < count( $slider_images_array ); $i ++ ) : ?>
                <?php if ( isset( $slider_images_array[ $i ] ) ) : ?>
                    <div class="eltd-hotel-room-slider-item">
                        <a href="<?php echo wp_get_attachment_url( $slider_images_array[ $i ] ) ?>"
                           data-rel="prettyPhoto[gallery_excerpt_pretty_photo]">
                            <?php echo albergo_elated_generate_thumbnail($slider_images_array[ $i ], null, '1100', '656'); ?>
                        </a>
                    </div>
                <?php endif; ?>
            <?php endfor; ?>
        </div>

        <ul class="eltd-slider-thumbnail" data-thumbnail-count="<?php echo count( $slider_images_array )?>">
            <?php
            for ( $i = 0; $i < count( $slider_images_array ); $i ++ ) : ?>
                <?php if ( isset( $slider_images_array[ $i ] ) ) : ?>
                    <li class="eltd-slider-thumbnail-item">
                        <?php echo albergo_elated_generate_thumbnail($slider_images_array[ $i ], null, '550', '403'); ?>
                    </li>
                <?php endif; ?>
            <?php endfor; ?>
        </ul>
    </div>

    <?php endif; ?>




<?php endif; ?>