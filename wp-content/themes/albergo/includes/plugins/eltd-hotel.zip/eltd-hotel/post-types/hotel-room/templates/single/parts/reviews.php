<?php
eltd_hotel_room_reviews_print_ratings_display();

comments_template('', true);