<div class="eltd-filter-section eltd-filter-section-12 eltd-section-date">
    <div class="eltd-filter-date-holder" data-date-min="<?php echo esc_attr($room_min_date); ?>" data-date-max="<?php echo esc_attr($room_max_date); ?>">
        <div class="eltd-inputs-holder clearfix">
            <span class="eltd-input-min-size">
                <label>Check in</label>
                <input type="text" class="eltd-min-date" name="eltd-min-date" placeholder="<?php esc_html_e('Select', 'eltd-hotel') ?>" value="<?php echo esc_attr($room_min_date); ?>" data-min-date="" />
            </span>
            <span class="eltd-input-max-size">
                <label>Check out</label>
                <input type="text" class="eltd-max-date" name="eltd-max-date" placeholder="<?php esc_html_e('Select', 'eltd-hotel') ?>" value="<?php echo esc_attr($room_max_date); ?>" data-max-date="" />
            </span>
        </div>
    </div>
</div>