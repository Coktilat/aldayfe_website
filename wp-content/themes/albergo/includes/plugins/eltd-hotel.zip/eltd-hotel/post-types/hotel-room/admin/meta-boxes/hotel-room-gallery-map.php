<?php
if(eltd_hotel_theme_installed()) {
	if ( ! function_exists( 'eltd_hotel_room_gallery_meta_box_map' ) ) {

		function eltd_hotel_room_gallery_meta_box_map() {

			$hotel_room_gallery_section_meta_box = albergo_elated_add_meta_box( array(
				'scope' => array( 'hotel-room' ),
				'title' => esc_html__( 'Gallery Section', 'eltd-hotel' ),
				'name'  => 'hotel_gallery_section_meta'
			) );

			albergo_elated_add_multiple_images_field( array(
				'parent'      => $hotel_room_gallery_section_meta_box,
				'name'        => 'eltd_hotel_gallery_images',
				'label'       => esc_html__( 'Gallery Images', 'eltd-hotel' ),
				'description' => esc_html__( 'Choose your gallery images', 'eltd-hotel' )
			) );
		}

		add_action( 'albergo_elated_meta_boxes_map', 'eltd_hotel_room_gallery_meta_box_map' );
	}
}
