<?php if ( $query_results->max_num_pages > 1 ) {
	$holder_styles = $this_object->getLoadMoreStyles( $params );
	?>
	<div class="eltd-hrl-loading">
		<div class="eltd-hrl-loading-bounce1"></div>
		<div class="eltd-hrl-loading-bounce2"></div>
		<div class="eltd-hrl-loading-bounce3"></div>
	</div>
	<div class="eltd-hrl-load-more-holder">
		<div class="eltd-hrl-load-more" <?php albergo_elated_inline_style( $holder_styles ); ?>>
			<?php
            if ( albergo_elated_core_plugin_installed() ) {
                echo albergo_elated_get_button_html( array(
                    'link' => 'javascript: void(0)',
                    'size' => 'large',
                    'text' => esc_html__( 'Load more', 'eltd-hotel' )
                ) );
            } else { ?>
                <a itemprop="url" href="<?php echo esc_attr( get_the_permalink() ); ?>" target="_self" class="eltd-btn eltd-btn-medium eltd-btn-solid">
                    <span class="eltd-btn-text"><?php echo esc_html__( 'Load more', 'eltd-hotel' ); ?></span>
                </a>
			<?php } ?>
		</div>
	</div>
<?php }