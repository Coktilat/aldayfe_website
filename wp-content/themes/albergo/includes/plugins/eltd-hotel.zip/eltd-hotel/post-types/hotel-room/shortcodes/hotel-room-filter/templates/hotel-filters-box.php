<div class="<?php echo esc_attr( $holder_classes ) ?>" <?php echo albergo_elated_get_inline_style( $holder_style ) ?>>
    <div class="eltd-hotel-filters">
        <h4 class="eltd-hf-title"><?php esc_html_e('Check availability') ?></h4>
        <form action="<?php echo esc_url( eltd_hotel_room_get_search_page_url() ); ?>" method="GET">
            <div class="eltd-hotel-filters-inner">
                <div class="eltd-hotel-filters-cell">
                    <span class="eltd-input-min-date">
                        <label>Check-in:</label>
                        <input type="text" class="eltd-filter-min-date" name="min_date"
                       placeholder="<?php esc_html_e( 'Check in', 'eltd-hotel' ) ?>"
                       value="<?php echo esc_attr( $today ) ?>"/>
                    </span>
                </div>
                <div class="eltd-hotel-filters-cell">
                    <span class="eltd-input-max-date">
                        <label>Check-out:</label>
                        <input type="text" class="eltd-filter-max-date" name="max_date"
                        placeholder="<?php esc_html_e( 'Check out', 'eltd-hotel' ) ?>"
                        value="<?php echo esc_attr( $tomorrow ) ?>"/>
                    </span>
                </div>
                <div class="eltd-hotel-filters-cell">
                    <span class="eltd-input-rooms-number">
                        <label for="eltd-filter-rooms-number">Rooms:</label>
                        <select id="eltd-filter-rooms-number" name="rooms_number" class="eltd-filter-rooms-number">
                        <?php for ( $i = 1; $i <= $number_of_rooms; $i ++ ) { ?>
                            <option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
                        <?php } ?>
                        </select>
                    </span>
                </div>
                <div class="eltd-hotel-filters-cell">
                    <span class="eltd-input-location">
                        <label for="eltd-filter-location">Location:</label>
                        <select id="eltd-filter-location" name="location" class="eltd-filter-location">
                            <?php foreach ( $locations as $key => $location ) { ?>
                                <option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $location ); ?></option>
                            <?php } ?>
                        </select>
                    </span>
                </div>
                <div class="eltd-hotel-filters-cell">
                    <span class="eltd-input-adults">
                        <label for="eltd-filter-adults">Adults:</label>
                        <select id="eltd-filter-adults" name="adults" class="eltd-filter-adults">
                            <option selected value="0">0</option>
                        <?php for ( $i = 1; $i <= $adults; $i ++ ) { ?>
                            <option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
                        <?php } ?>
                        </select>
                    </span>
                </div>
                <div class="eltd-hotel-filters-cell">
                    <span class="eltd-input-children">
                        <label for="eltd-filter-children">Children:</label>
                        <select id="eltd-filter-children" name="children" class="eltd-filter-children">
                            <option selected value="0">0</option>
                        <?php for ( $i = 1; $i <= $children; $i ++ ) { ?>
                            <option value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
                        <?php } ?>
                        </select>
                    </span>
                </div>
                <div class="eltd-hotel-filters-cell eltd-hotel-room-filter-button-holder">
                    <?php
                    if ( albergo_elated_core_plugin_installed() ) {
	                    echo albergo_elated_get_button_html( array(
		                    'custom_class' => 'eltd-hotel-room-filter-button',
		                    'html_type'    => 'button',
		                    'size'         => 'medium',
		                    'type'         => 'solid',
		                    'text'         => esc_html__( 'Book Now', 'eltd-hotel' )
	                    ) );
                    }
                    ?>
                </div>
                <?php if ( eltd_hotel_is_wpml_installed() ) { ?>
                    <?php
                    $lang = ICL_LANGUAGE_CODE;
                    ?>
                    <input type="hidden" name="lang" value="<?php echo esc_attr( $lang ); ?>">
                <?php } ?>
            </div>
        </form>
    </div>
</div>