<?php
require_once 'hotel-room-pair.php';
require_once 'helper-functions.php';
