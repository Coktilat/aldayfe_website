<?php

/* Property Type Custom Fields */
if (!function_exists( 'eltd_hotel_room_taxonomy_extra_services_fields' )) {
	function eltd_hotel_room_taxonomy_extra_services_fields() {

		/* get currency */
		$currency = eltd_hotel_room_get_currency();

		$extra_service_type_fields = albergo_elated_add_taxonomy_fields(
			array(
				'scope' => 'extra-service-tag',
				'name'  => 'extra_service_tag'
			)
		);

		albergo_elated_add_taxonomy_field(
			array(
				'name'        => 'eltd_extra_service_pack',
				'type'        => 'selectblank',
				'label'       => esc_html__( 'Service Pack', 'eltd-hotel' ),
				'description' => esc_html__( 'Choose Service Pack from the list.', 'eltd-hotel' ),
				'parent'      => $extra_service_type_fields,
				'options'     => eltd_hotel_room_get_service_packs(),
				'args'    => array(
					'select2'  => true
				)
			)
		);

		albergo_elated_add_taxonomy_field(
			array(
				'name'        => 'eltd_extra_service_price',
				'type'        => 'text',
				'label'       => esc_html__( 'Price', 'eltd-hotel' ).' ('.$currency.')',
				'description' => esc_html__( 'Enter price for extra service. To change currency, use Woocommerce Settings.', 'eltd-hotel' ),
				'parent'      => $extra_service_type_fields,
				'dependency' => array(
					'hide' => array(
						'eltd_extra_service_pack'  => array(
							'',
							'increase_price_by_percent_amount',
							'decrease_price_by_percent_amount'
						)
					)
				)
			)
		);

		albergo_elated_add_taxonomy_field(
			array(
				'name'        => 'eltd_extra_service_percent',
				'type'        => 'text',
				'label'       => esc_html__( 'Percent', 'eltd-hotel' ),
				'description' => esc_html__( 'Enter percent for extra service.', 'eltd-hotel' ),
				'parent'      => $extra_service_type_fields,
				'dependency' => array(
					'hide' => array(
						'eltd_extra_service_pack'  => array(
							'',
							'add_to_price',
							'add_to_price_per_night',
							'add_to_price_per_person',
							'add_to_price_per_person_per_night',
							'subtract_from_price',
							'subtract_from_price_per_night',
						)
					)
				)
			)
		);

		albergo_elated_add_taxonomy_field(
			array(
				'name'        => 'eltd_extra_service_type',
				'type'        => 'selectblank',
				'label'       => esc_html__( 'Type', 'eltd-hotel' ),
				'description' => esc_html__( 'Choose type of Service Pack from the list.', 'eltd-hotel' ),
				'parent'      => $extra_service_type_fields,
				'options'     => array(
					'optional' => esc_html__( 'Optional', 'eltd-hotel' ),
					'mandatory' => esc_html__( 'Mandatory', 'eltd-hotel' ),
				),
				'args'    => array(
					'select2'  => true
				)
			)
		);
	}

	add_action('albergo_elated_custom_taxonomy_fields', 'eltd_hotel_room_taxonomy_extra_services_fields');
}