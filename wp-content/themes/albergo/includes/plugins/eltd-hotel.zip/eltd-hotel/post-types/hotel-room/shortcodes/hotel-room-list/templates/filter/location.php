<?php
$city_set           = isset( $params['room_location'] ) && $params['room_location'] !== '';
$hide_active_filter = isset( $params['hide_active_filter'] ) && $params['hide_active_filter'] === 'yes';
$locations             = eltd_hotel_get_taxonomy_list( 'location-tag' );
?>
<?php if ( ! $city_set || ( $city_set && ! $hide_active_filter ) ) { ?>
    <div class="eltd-filter-section eltd-filter-section-12 eltd-section-location">
        <div class="eltd-filter-location-holder" data-location="<?php echo esc_attr($params['room_location']) ?>">
            <label for="eltd-filter-location"><?php esc_html_e( 'Choose a location', 'eltd-hotel' ) ?></label>
            <select id="eltd-filter-location" name="eltd-filter-location" class="eltd-filter-location">
                <option value="">All</option>
				<?php foreach ( $locations as $key => $location ) { ?>
                    <option <?php echo ($params['room_location'] == $key) ? 'selected' : ''; ?>
                            value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $location ); ?></option>
				<?php } ?>
            </select>
        </div>
    </div>
<?php } ?>