<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/image', '', $params ); ?>
<div class="eltd-hrl-item-content">
    <div class="eltd-hrl-item-content-holder">
        <div class="eltd-hrl-item-content-inner">
			<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/title', '', $params ); ?>
			<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/price-gallery' ); ?>
			<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/excerpt', '', $params ); ?>
        </div>
    </div>
</div>