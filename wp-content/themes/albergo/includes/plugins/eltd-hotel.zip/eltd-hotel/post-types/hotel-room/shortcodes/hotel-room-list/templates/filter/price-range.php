<?php
$min_price = isset($room_min_price) && !empty($room_min_price) ? $room_min_price : 0;
$max_price = isset($room_max_price) && !empty($room_max_price) ? $room_max_price : eltd_hotel_get_hotel_room_max_price_value();
$currency = eltd_hotel_room_get_currency();
?>
<div class="eltd-filter-section eltd-filter-section-12 eltd-section-price">
    <div class="eltd-filter-price-holder" data-currency="<?php echo esc_attr($currency) ?>" data-max-price-setting="<?php echo esc_attr(eltd_hotel_get_hotel_room_max_price_value()); ?>">
        <div class="eltd-range-slider-wrapper">
            <div class="eltd-range-slider"></div>
        </div>
        <div class="eltd-rangle-slider-response-holder">
            <span id="eltd-min-price-value" data-min-price="<?php echo esc_attr($min_price); ?>"><?php echo esc_attr($currency) . esc_html($min_price); ?></span>
            <span id="eltd-max-price-label"><?php esc_html_e(' - ', 'eltd-hotel'); ?></span>
            <span id="eltd-max-price-value" data-max-price="<?php echo esc_attr($max_price); ?>"><?php echo esc_attr($currency) . esc_html($max_price); ?></span>
        </div>
    </div>
</div>