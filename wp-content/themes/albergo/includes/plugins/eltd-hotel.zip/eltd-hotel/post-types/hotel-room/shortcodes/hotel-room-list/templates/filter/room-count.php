<?php
$number_of_rooms = eltd_hotel_get_hotel_room_max_rooms();
if($number_of_rooms !== '') { ?>
    <div class="eltd-filter-section eltd-filter-section-12 eltd-section-room-count">
        <div class="eltd-filter-room-count-holder" data-room-count="<?php echo esc_attr($params['room_number_of_rooms']) ?>">
            <label for="eltd-filter-room-count"><?php esc_html_e( 'Rooms', 'eltd-hotel' ) ?></label>
            <select id="eltd-filter-room-count" name="eltd-filter-room-count" class="eltd-filter-room-count">
				<?php for ( $i = 1; $i <= $number_of_rooms; $i++ ) {?>
                    <option <?php echo ($params['room_number_of_rooms'] == $i) ? 'selected' : ''; ?>
                            value="<?php echo esc_attr( $i ); ?>"><?php echo esc_attr( $i ); ?></option>
				<?php } ?>
            </select>
        </div>
    </div>
<?php } ?>