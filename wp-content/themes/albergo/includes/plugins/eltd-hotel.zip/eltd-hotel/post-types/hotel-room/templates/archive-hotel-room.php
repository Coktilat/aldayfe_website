<?php

get_header();

albergo_elated_get_title();

eltd_hotel_room_get_search_page();

get_footer();