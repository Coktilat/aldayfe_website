<?php

get_header();

albergo_elated_get_title();

eltd_hotel_room_get_single_room();

get_footer();