<?php
$amenity_set        = isset($params['amenity-tag']) && $params['amenity-tag'] !== '';
$hide_active_filter = isset($params['hide_active_filter']) && $params['hide_active_filter'] === 'yes';
$amenities           = eltd_hotel_get_taxonomy_list('amenity-tag');
$room_amenities  = explode(',', $room_amenities);
?>
<?php if( !$amenity_set || ( $amenity_set && !$hide_active_filter)) { ?>
<div class="eltd-filter-section eltd-filter-section-12 eltd-section-amenities">
    <div class="eltd-filter-amenities-holder">
        <div class="eltd-filter-amenities-wrapper clearfix">
            <?php foreach ($amenities as $key => $amenity) { ?>
                <div class="eltd-amenity-item">
                    <input type="checkbox" <?php echo !empty($room_amenities) && in_array($key, $room_amenities) ? 'checked' : ''; ?> class="eltd-amenity-cb" data-id="<?php echo esc_attr($key); ?>" id="eltd-amenity-<?php echo esc_attr($key); ?>" name="eltd-amenities[]" value="" />
                    <label class="eltd-checkbox-label" for="eltd-amenity-<?php echo esc_attr($key); ?>">
                        <span class="eltd-checkbox-frame icon_check"></span>
                        <span class="eltd-label-text">
                            <?php echo esc_html($amenity); ?>
                        </span>
                    </label>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<?php } ?>