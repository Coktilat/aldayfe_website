<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/image', '', $params ); ?>
<div class="eltd-hrl-item-content">
	<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/title', '', $params ); ?>
	<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/price'); ?>
	<?php echo eltd_hotel_get_shortcode_module_template_part( 'hotel-room', 'hotel-room-list', 'parts/excerpt', '', $params ); ?>
</div>