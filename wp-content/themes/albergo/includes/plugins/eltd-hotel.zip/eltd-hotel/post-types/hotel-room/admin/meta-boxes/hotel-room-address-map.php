<?php
if(!function_exists('eltd_hotel_map_hotel_room_address_meta')) {
    function eltd_hotel_map_hotel_room_address_meta($meta_box) {

	    /* get all location */
	    $hotel_locations = eltd_hotel_room_get_locations();

	    $default_value = '';
	    if(isset($hotel_locations[0])){
		    $default_value = $hotel_locations[0];
	    }

        $hotel_room_address_container = albergo_elated_add_admin_container(array(
            'type'            => 'container',
            'name'            => 'hotel_room_address_container',
            'parent'          => $meta_box
        ));

        albergo_elated_add_admin_section_title(array(
            'title'           => esc_html__('Address', 'eltd-hotel'),
            'name'            => 'hotel_room_address_container_title',
            'parent'          => $hotel_room_address_container
        ));

	    albergo_elated_add_meta_box_field(array(
		    'name'        => 'eltd_hotel_room_location_meta',
		    'type'        => 'select',
		    'label'       => esc_html__('Location', 'eltd-hotel'),
		    'description' => esc_html__('Choose location for Single Room', 'eltd-hotel'),
		    'default_value' => $default_value,
		    'parent'      => $hotel_room_address_container,
		    'options'     => $hotel_locations,
		    'args'        => array(
			    'select2' => true,
		    ),
	    ));

	    albergo_elated_add_meta_box_field(array(
		    'name'        => 'eltd_hotel_room_address_country_meta',
		    'type'        => 'text',
		    'label'       => esc_html__('Country', 'eltd-hotel'),
		    'parent'      => $hotel_room_address_container,
	    ));

        albergo_elated_add_meta_box_field(array(
            'name'        => 'eltd_hotel_room_full_address_meta',
            'type'        => 'address',
            'label'       => esc_html__('Full Address', 'eltd-hotel'),
            'parent'      => $hotel_room_address_container,
            'args'        => array(
                'latitude_field' => 'eltd_hotel_room_full_address_latitude',
                'longitude_field' => 'eltd_hotel_room_full_address_longitude'
            )
        ));

        albergo_elated_add_meta_box_field(array(
            'name'        => 'eltd_hotel_room_full_address_latitude',
            'type'        => 'text',
            'label'       => esc_html__('Latitude', 'eltd-hotel'),
            'parent'      => $hotel_room_address_container,
            'args'        => array(
                'col_width' => 3,
                'custom_class' => 'eltd-address-elements',
                'input-data' => array(
                    'data-geo' => 'lat'
                )
            )
        ));

        albergo_elated_add_meta_box_field(array(
            'name'        => 'eltd_hotel_room_full_address_longitude',
            'type'        => 'text',
            'label'       => esc_html__('Longitude', 'eltd-hotel'),
            'parent'      => $hotel_room_address_container,
            'args'        => array(
                'col_width' => 3,
                'custom_class' => 'eltd-address-elements',
                'input-data' => array(
                    'data-geo' => 'lng'
                )
            )
        ));

        albergo_elated_add_meta_box_field(array(
            'name'        => 'eltd_hotel_room_simple_address_meta',
            'type'        => 'text',
            'label'       => esc_html__('Simple Address', 'eltd-hotel'),
            'parent'      => $hotel_room_address_container,
            'args'        => array(
                'col_width' => 3
            )
        ));

        albergo_elated_add_meta_box_field(array(
            'name'        => 'eltd_hotel_room_email_meta',
            'type'        => 'text',
            'label'       => esc_html__('Email', 'eltd-hotel'),
            'parent'      => $hotel_room_address_container,
            'args'        => array(
                'col_width' => 3
            )
        ));

	    albergo_elated_add_meta_box_field(array(
		    'name'        => 'eltd_hotel_room_phone_meta',
		    'type'        => 'text',
		    'label'       => esc_html__('Phone', 'eltd-hotel'),
		    'parent'      => $hotel_room_address_container,
		    'args'        => array(
			    'col_width' => 3
		    )
	    ));
    }

    add_action('eltd_hotel_room_action_meta_fields', 'eltd_hotel_map_hotel_room_address_meta', 30, 1);
}