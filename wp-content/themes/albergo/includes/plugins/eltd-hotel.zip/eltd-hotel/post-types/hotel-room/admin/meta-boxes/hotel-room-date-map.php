<?php
if(!function_exists( 'eltd_hotel_room_map_date_meta' )) {
    function eltd_hotel_room_map_date_meta($meta_box) {

	    $hotel_room_date_container = albergo_elated_add_admin_container(array(
            'type'            => 'container',
            'name'            => 'hotel_date_container',
            'parent'          => $meta_box
        ));

        albergo_elated_add_admin_section_title(array(
            'title'           => esc_html__('Reserved Dates', 'eltd-hotel'),
            'description' => esc_html__('Insert reserved date for hotel room', 'eltd-hotel'),
            'name'            => 'hotel_date_container_title',
            'parent'          => $hotel_room_date_container
        ));

	    albergo_elated_add_repeater_field(
            array(
                'name'        => 'eltd_room_date_meta',
                'parent'      => $hotel_room_date_container,
                'button_text' => '',
                'fields'      => array_merge(
	                array(
		                array(
			                'type'        => 'date',
			                'name'        => 'date_begin',
			                'label'       => esc_html__( 'Date (Begin)', 'eltd-hotel' ),
			                'col_width'   => '3',
			                'args'        => array(
				                'col_width' => 12,
			                ),
		                ),
		                array(
			                'type'        => 'date',
			                'name'        => 'date_end',
			                'label'       => esc_html__( 'Date (End)', 'eltd-hotel' ),
			                'col_width'   => '3',
			                'args'        => array(
				                'col_width' => 12,
			                ),
		                ),
		                array(
			                'type'        => 'text',
			                'name'        => 'number_of_room',
			                'label'       => esc_html__( 'Number', 'eltd-hotel' ),
			                'col_width'   => '3'
		                ),
		                array(
			                'type'        => 'text',
			                'name'        => 'adults',
			                'label'       => esc_html__( 'Adults', 'eltd-hotel' ),
			                'col_width'   => '3'
		                ),
		                array(
			                'type'        => 'text',
			                'name'        => 'children',
			                'label'       => esc_html__( 'Children', 'eltd-hotel' ),
			                'col_width'   => '3'
		                ),
		                array(
			                'type'        => 'text',
			                'name'        => 'order_id',
			                'label'       => esc_html__( 'Order ID', 'eltd-hotel' ),
			                'col_width'   => '3'
		                ),
		                array(
			                'type'        => 'textarea',
			                'name'        => 'additional_info',
			                'label'       => esc_html__( 'Additional Info', 'eltd-hotel' ),
			                'col_width'   => '12'
		                ),
	                )
                )
            )
        );

    }

    add_action('eltd_hotel_room_action_meta_fields', 'eltd_hotel_room_map_date_meta', 20, 1);
}