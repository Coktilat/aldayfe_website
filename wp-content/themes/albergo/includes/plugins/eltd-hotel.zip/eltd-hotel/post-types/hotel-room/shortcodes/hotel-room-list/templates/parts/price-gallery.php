<?php extract( apply_filters( 'albergo_elated_hotel_single_price_params', array() ) ); ?>
<?php if ( $price ) { ?>
    <div class="eltd-hrl-price">
        <span class="eltd-hrl-price-currency"><?php echo esc_attr( $currency ) ?></span><span><?php echo esc_attr( $price ) ?></span>
        <span class="eltd-hrl-price-pn"> <?php  echo esc_attr( ' / NIGHT', 'albergo' ) ?></span>
    </div>
<?php }
