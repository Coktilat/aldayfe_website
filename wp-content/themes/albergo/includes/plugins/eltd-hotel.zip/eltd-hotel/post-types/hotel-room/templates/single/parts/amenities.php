<?php $amenities = eltd_hotel_room_get_hotel_room_taxonomy( 'amenity-tag' );
if ( isset( $amenities ) && count( $amenities ) > 0 ) { ?>
    <div class="eltd-hotel-room-amenity eltd-hotel-room-label-items-holder">
        <div class="eltd-hotel-room-amenity-label eltd-hotel-room-label-style">
            <h4>
				<?php esc_html_e( 'Amenities', 'eltd-hotel' ); ?>
            </h4>
        </div>
        <div class="eltd-hotel-room-amenity-items eltd-hotel-room-items-style clearfix">
			<?php foreach ( $amenities as $amenity ) { ?>
                <div class="eltd-tag-item">
                    <h6 class="eltd-hr-amenity-title">
						<?php echo esc_html( $amenity->name ); ?>
                    </h6>
                    <?php if($amenity->description != '') { ?>
                        <p>
                            <?php echo esc_html( $amenity->description ); ?>
                        </p>
                    <?php } ?>
                </div>
			<?php } ?>
        </div>
    </div>
<?php }