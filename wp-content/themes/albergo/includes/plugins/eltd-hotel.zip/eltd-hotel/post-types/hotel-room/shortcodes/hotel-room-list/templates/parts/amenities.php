<?php $amenities = eltd_hotel_room_get_hotel_room_taxonomy( 'amenity-tag' );
if(is_array($amenities) && !empty($amenities)) { ?>
    <span class="eltd-hrl-types">
    <?php foreach($amenities as $amenity) { ?>
        <span class="eltd-hrl-type">
            <?php echo esc_html($amenity->name); ?>
        </span>
    <?php  } ?>
    </span>
<?php }