<div class="eltd-hotel-room-description eltd-hotel-room-label-items-holder">
	<div class="eltd-hotel-room-description-label eltd-hotel-room-label-style">
		<h4>
			<?php esc_html_e('Room details', 'eltd-hotel'); ?>
		</h4>
	</div>
	<div class="eltd-hotel-room-description-items eltd-hotel-room-items-style clearfix">
		<?php the_content(); ?>
	</div>
</div>