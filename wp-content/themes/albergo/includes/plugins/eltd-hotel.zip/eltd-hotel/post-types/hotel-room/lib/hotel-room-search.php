<?php
namespace ElatedHotel\CPT\HotelRoom\Lib;

/**
 * Class HotelRoomSearch
 * @package EltdHotel\CPT\HotelRoom\Lib
 */
class HotelRoomSearch {
	/**
	 * @var private instance of current class
	 */
	private static $instance;

	/**
	 * Array of hotel type (standard, gallery or divided)
	 * @var
	 */
	private $hotelType;

	/**
	 * Check in string
	 * @var
	 */
	private $checkIn;

	/**
	 * Number of columns
	 * @var
	 */
	private $columns;

	/**
	 * Number of columns
	 * @var
	 */
	private $imageProportion;

	/**
	 * Check out string
	 * @var
	 */
	private $checkOut;

	/**
	 * Rooms number string
	 * @var
	 */
	private $rooms;

	/**
	 * Location
	 * @var
	 */
	private $location;

	/**
	 * Number adults
	 * @var
	 */
	private $adults;

	/**
	 * Number of children
	 * @var
	 */
	private $children;

	/**
	 * For which property to sort results
	 * @var
	 */
	private $orderBy;

	/**
	 * Whether to sort them ascending or descending
	 * @var
	 */
	private $orderType;

	/**
	 * Whether to sort option
	 * @var
	 */
	private $sortOption;

	/**
	 * Current page in pagination
	 * @var
	 */
	private $currentPage;

	/**
	 * How much hotel rooms per page
	 * @var
	 */
	private $roomsPerPage;

	/**
	 * Private constuct because of Singletone
	 */
	private function __construct() {
		$this->setPropertiesFromRequest();
	}

	/**
	 * Private sleep because of Singletone
	 */
	private function __wakeup() {
	}

	/**
	 * Private clone because of Singletone
	 */
	private function __clone() {
	}

	/**
	 * @return mixed
	 */
	public function getCurrentPage() {
		return $this->currentPage;
	}

	/**
	 * @return mixed
	 */
	public function getHotelTypes() {
		return $this->hotelType;
	}

	/**
	 * @return mixed
	 */
	public function getNumberOfColumns() {
		return $this->columns;
	}

	/**
	 * @return mixed
	 */
	public function getImageProportion() {
		return $this->imageProportion;
	}

	/**
	 * @return mixed
	 */
	public function getCheckIn() {
		return $this->checkIn;
	}

	/**
	 * @return mixed
	 */
	public function getCheckOut() {
		return $this->checkOut;
	}

	/**
	 * @return mixed
	 */
	public function getRooms() {
		return $this->rooms;
	}

	/**
	 * @return mixed
	 */
	public function getLocations() {
		return $this->location;
	}

	/**
	 * @return mixed
	 */
	public function getAdults() {
		return $this->adults;
	}

	/**
	 * @return mixed
	 */
	public function getChildren() {
		return $this->children;
	}

	/**
	 * @return mixed
	 */
	public function getOrderBy() {
		return $this->orderBy;
	}

	/**
	 * @return mixed
	 */
	public function getOrderType() {
		return $this->orderType;
	}

	/**
	 * @return mixed
	 */
	public function getSortOption() {
		return $this->sortOption;
	}

	/**
	 * @return mixed
	 */
	public function getHotelRoomsPerPage() {
		return $this->roomsPerPage;
	}

	/**
	 * Returns current instance of class
	 * @return HotelRoomSearch
	 */
	public static function getInstance() {
		if(self::$instance == null) {
			return new self;
		}

		return self::$instance;
	}

	/**
	 * Hooks form handled method to WP ajax actions
	 */
	public function initialize() {

	}

	/**
	 * Sets properties from parsed request.
	 * These properties are later used in other methods
	 * for accessing current current request data
	 */
	private function setPropertiesFromRequest() {
		$request = $this->getCurrentRequest();

		$defaultViewType  = 'gallery';
		$defaultOrderBy   = 'date';
		$defaultOrderType = 'desc';

		if(eltd_hotel_theme_installed()) {
			$defaultViewType    = albergo_elated_options()->getOptionValue('hotel_room_search_default_view_type');
			$numberOfColumns    = albergo_elated_options()->getOptionValue('hotel_room_search_columns');
			$imageProportion    = albergo_elated_options()->getOptionValue('hotel_room_search_image_proportion');
			$orderingOption     = albergo_elated_options()->getOptionValue('hotel_room_search_default_ordering');
		}

		$this->hotelType          = isset($request['type']) ? $request['type'] : $defaultViewType ;
		$this->columns            = isset($request['columns']) ? $request['columns'] : $numberOfColumns ;
		$this->imageProportion    = isset($imageProportion) ? $imageProportion :  '';
		$this->checkIn            = empty($request['min_date']) ? '' : $request['min_date'];
		$this->checkOut           = empty($request['max_date']) ? '' : $request['max_date'];
		$this->rooms              = empty($request['rooms_number']) ? '' : $request['rooms_number'];
		$this->location           = empty($request['location']) ? '' : $request['location'];
		$this->adults             = empty($request['adults']) ? '' : $request['adults'];
		$this->children           = empty($request['children']) ? '' : $request['children'];
		$this->orderBy            = empty($request['order_by']) ? $defaultOrderBy : $request['order_by'];
		$this->orderType          = empty($request['order_type']) ? $defaultOrderType : $request['order_type'];
		$this->sortOption         = isset($orderingOption) ? $orderingOption : '';
		$this->currentPage        = empty($request['page']) ? '' : $request['page'];

		if(eltd_hotel_theme_installed()) {
			$this->roomsPerPage = albergo_elated_options()->getOptionValue('hotel_room_per_page');

		} else {
			$this->roomsPerPage = apply_filters('eltd_hotel_room_search_per_page', 12);
		}
	}

	/**
	 * Builds 'get' http method query string from provided request
	 *
	 * @param array $request
	 *
	 * @return mixed
	 */
	private function buildQueryString($request) {
		return http_build_query($request);
	}

	/**
	 * Parses current request and returns it as array.
	 * It first checks if $_GET has fields property.
	 * If it has than it is an AJAX request.
	 * If it does'nt has 'fields' property than it assumes
	 * that it is normal 'get' request and it returns
	 * $_GET super global
	 *
	 * @return array
	 */
	private function getCurrentRequest() {
		$request = array();

		if(empty($_GET['fields'])) {
			$request = $_GET;

			return $request;
		} else {
			parse_str($_GET['fields'], $request);

			return $request;
		}
	}
}