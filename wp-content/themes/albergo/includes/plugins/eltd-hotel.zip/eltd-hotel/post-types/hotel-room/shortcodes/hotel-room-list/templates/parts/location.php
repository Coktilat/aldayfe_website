<?php extract( apply_filters( 'albergo_elated_hotel_single_location_params', array() ) ); ?>
<div class="eltd-hrl-address">
    <span class="eltd-hrl-city">
	    <?php if ( $location != '' ) { ?>
            <a href="<?php echo get_term_link( $location->term_id ); ?>" target="_self">
				<?php echo esc_html( $location->name ); ?>
			</a>
	    <?php } ?>
    </span>
    <span class="eltd-hrl-dash">&ndash;</span>
	<?php if ( isset( $email ) && ( $email != '' ) ) { ?>
        <span class="eltd-hrl-city"><?php echo esc_html( $email ); ?></span>
	<?php }
	if ( isset( $simple_address ) && ( $simple_address != '' ) ) { ?>
        <span class="eltd-hrl-city"><?php echo esc_html( $simple_address ); ?></span>
	<?php }
	if ( isset( $country ) && ( $country != '' ) ) { ?>
        <span class="eltd-hrl-city"><?php echo esc_html( $country ); ?></span>
	<?php }
	if ( isset( $phone ) && ( $phone != '' ) ) { ?>
        <span class="eltd-hrl-city"><?php echo esc_html( $phone ); ?></span>
	<?php } ?>
</div>