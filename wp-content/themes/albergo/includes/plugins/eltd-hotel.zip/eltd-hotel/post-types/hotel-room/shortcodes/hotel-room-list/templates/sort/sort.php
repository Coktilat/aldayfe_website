<?php  if(isset($params['enable_sort']) && $params['enable_sort'] === 'yes') { ?>
    <div class="eltd-hrl-sort-part">
        <div class="eltd-hrl-sort-part-inner">
			<?php
			foreach (eltd_hotel_room_get_room_sorting_options() as $key => $value) { ?>
                <div class="eltd-hrl-sort-part-item <?php if($sort_option == $key) echo 'eltd-hrl-sort-part-item-active' ?>" data-sort="<?php echo esc_attr($key) ?>">
                    <span><?php echo esc_html($value) ?></span>
                </div>
			<?php }

			?>
        </div>
    </div>
<?php } ?>