<?php

if(!function_exists('eltd_hotel_activation')) {
	/**
	 * Triggers when plugin is activated. It calls flush_rewrite_rules
	 * and defines eltd_hotel_on_activate action
	 */
	function eltd_hotel_activation() {
		do_action('eltd_hotel_on_activate');

		// ElatedHotel\PostTypesRegister::getInstance()->register();
		flush_rewrite_rules();
	}

	register_activation_hook(__FILE__, 'eltd_hotel_activation');
}

if(!function_exists('eltd_hotel_text_domain')) {
	/**
	 * Loads plugin text domain so it can be used in translation
	 */
	function eltd_hotel_text_domain() {
		load_plugin_textdomain('eltd-hotel', false, ELTD_HOTEL_REL_PATH.'/languages');
	}

	add_action('plugins_loaded', 'eltd_hotel_text_domain');
}

if(!function_exists('eltd_hotel_version_class')) {
    /**
     * Adds plugins version class to body
     * @param $classes
     * @return array
     */
    function eltd_hotel_version_class($classes) {
        $classes[] = 'eltd-hotel-'.ELTD_HOTEL_VERSION;

        return $classes;
    }

    add_filter('body_class', 'eltd_hotel_version_class');
}

if(!function_exists('eltd_hotel_theme_installed')) {
    /**
     * Checks whether theme is installed or not
     * @return bool
     */
    function eltd_hotel_theme_installed() {
        return defined('ELATED_ROOT');
    }
}

if(!function_exists('eltd_hotel_is_wpml_installed')) {
	/**
	 * Function that checks if WPML plugin is installed
	 * @return bool
	 *
	 * @version 0.1
	 */
	function eltd_hotel_is_wpml_installed() {
		return defined('ICL_SITEPRESS_VERSION');
	}
}

if ( ! function_exists( 'eltd_hotel_woocommerce_integration_installed' ) ) {
	//is Eltd Woocommerce Integration?
	function eltd_hotel_woocommerce_integration_installed() {
		return defined( 'ELTD_WOOCOMMERCE_CHECKOUT_INTEGRATION' );
	}
}

if(!function_exists('eltd_hotel_get_shortcode_module_template_part')) {
	/**
	 * Loads module template part.
	 *
	 * @param string $post_type name of the post type
	 * @param string $shortcode name of the shortcode folder
	 * @param string $template name of the template to load
	 * @param string $slug
	 * @param array $params array of parameters to pass to template
	 * @param array $additional_params array of additional parameters to pass to template
	 *
	 * @return html
	 */
	function eltd_hotel_get_shortcode_module_template_part($post_type, $shortcode,$template, $slug = '', $params = array(), $additional_params = array()) {

		//HTML Content from template
		$html = '';
		$template_path = ELTD_HOTEL_CPT_PATH.'/'.$post_type.'/shortcodes/'.$shortcode.'/'.'templates';

		$temp = $template_path.'/'.$template;
		if(is_array($params) && count($params)) {
			extract($params);
		}

		if(is_array($additional_params) && count($additional_params)) {
			extract($additional_params);
		}

		$template = '';

		if (!empty($temp)) {
			if (!empty($slug)) {
				$template = "{$temp}-{$slug}.php";

				if(!file_exists($template)) {
					$template = $temp.'.php';
				}
			} else {
				$template = $temp.'.php';
			}
		}

		if ($template) {
			ob_start();
			include($template);
			$html = ob_get_clean();
		}

		return $html;
	}
}

if(!function_exists('eltd_hotel_get_template_part')) {
	/**
	 * Loads template part with parameters. If file with slug parameter added exists it will load that file, else it will load file without slug added.
	 * Child theme friendly function
	 *
	 * @param string $template name of the template to load without extension
	 * @param string $slug
	 * @param array $params array of parameters to pass to template
	 * @param bool $return whether to return it as a string
	 *
	 * @return mixed
	 */
	function eltd_hotel_get_template_part($template, $slug = '', $params = array(), $return = false) {
		//HTML Content from template
		$html = '';
		$template_path = ELTD_HOTEL_MODULE_PATH;

		$temp = $template_path.'/'.$template;
		if(is_array($params) && count($params)) {
			extract($params);
		}

		$template = '';

		if($temp !== '') {

			if($slug !== '') {
				$template = "{$temp}-{$slug}.php";

				if ( ! file_exists( $template ) ) {
					$template = $temp . '.php';
				}
			} else {
				$template = $temp . '.php';
			}
		}

		if($template) {
			if($return) {
				ob_start();
			}

			include($template);

			if($return) {
				$html = ob_get_clean();
			}

		}

		if($return) {
			return $html;
		}
	}
}


if(!function_exists('eltd_hotel_get_cpt_single_module_template_part')) {
	/**
	 * Loads module template part.
	 *
	 * @param string $cpt_name name of the cpt folder
	 * @param string $template name of the template to load
	 * @param string $slug
	 * @param array $params array of parameters to pass to template
	 *
	 * @return html
	 */
	function eltd_hotel_get_cpt_single_module_template_part($template, $cpt_name, $slug = '', $params = array()) {

		//HTML Content from template
		$html = '';
		$template_path = ELTD_HOTEL_CPT_PATH.'/'.$cpt_name;

		$temp = $template_path.'/'.$template;

		if(is_array($params) && count($params)) {
			extract($params);
		}

		$template = '';

		if (!empty($temp)) {
			if (!empty($slug)) {
				$template = "{$temp}-{$slug}.php";

				if(!file_exists($template)) {
					$template = $temp.'.php';
				}
			} else {
				$template = $temp.'.php';
			}
		}

		if (!empty($template)) {
			ob_start();
			include($template);
			$html = ob_get_clean();
		}

		print $html;
	}
}



if(!function_exists('eltd_hotel_return_cpt_single_module_template_part')) {
	/**
	 * Loads module template part.
	 *
	 * @param string $cpt_name name of the cpt folder
	 * @param string $template name of the template to load
	 * @param string $slug
	 * @param array $params array of parameters to pass to template
	 *
	 * @return string
	 */
	function eltd_hotel_return_cpt_single_module_template_part($template, $cpt_name, $slug = '', $params = array()) {

		//HTML Content from template
		$html = '';
		$template_path = ELTD_HOTEL_CPT_PATH.'/'.$cpt_name;

		$temp = $template_path.'/'.$template;

		if(is_array($params) && count($params)) {
			extract($params);
		}

		$template = '';

		if (!empty($temp)) {
			if (!empty($slug)) {
				$template = "{$temp}-{$slug}.php";

				if(!file_exists($template)) {
					$template = $temp.'.php';
				}
			} else {
				$template = $temp.'.php';
			}
		}

		if (!empty($template)) {
			ob_start();
			include($template);
			$html = ob_get_clean();
		}

		return $html;
	}
}



/**
 * Get property county taxonomy values
 * return value is array in provided format.
 *
 * @param $taxonomy string - queried taxonomy
 * @param $first_empty boolean - if is true, first element in key_value return array will be empty
 * @param $return_type string - format of returned array (can be key_value, object)
 *
 * @return array
 */
if ( ! function_exists( 'eltd_hotel_get_taxonomy_list' ) ) {
	function eltd_hotel_get_taxonomy_list($taxonomy = '', $first_empty = false, $return_type = 'key_value') {
		$property_taxonomy_array = array();
		$property_taxonomy_array['key_value'] = array();
		$property_taxonomy_array['obj'] = array();

		if($taxonomy !== '') {

			$args = array(
				'taxonomy' => $taxonomy,
				'hide_empty' => false
			);

			$property_taxonomies = get_terms($args);

			if (is_array($property_taxonomies) && count($property_taxonomies)) {
				if ($first_empty) {
					$property_taxonomy_array['key_value'][''] = '';
				}
				foreach ($property_taxonomies as $property_taxonomy) {

					$property_taxonomy_array['key_value'][$property_taxonomy->term_id] = $property_taxonomy->name;
					$property_taxonomy_array['obj'][] = $property_taxonomy;

				}

			}
		}

		return $property_taxonomy_array[$return_type];
	}
}



if ( ! function_exists( 'eltd_hotel_get_countries_list' ) ) {
	function eltd_hotel_get_countries_list() {

		$countries = array(
			'AF' => esc_html__( 'Afghanistan', 'eltd-hotel' ),
			'AX' => esc_html__( '&#197;land Islands', 'eltd-hotel' ),
			'AL' => esc_html__( 'Albania', 'eltd-hotel' ),
			'DZ' => esc_html__( 'Algeria', 'eltd-hotel' ),
			'AS' => esc_html__( 'American Samoa', 'eltd-hotel' ),
			'AD' => esc_html__( 'Andorra', 'eltd-hotel' ),
			'AO' => esc_html__( 'Angola', 'eltd-hotel' ),
			'AI' => esc_html__( 'Anguilla', 'eltd-hotel' ),
			'AQ' => esc_html__( 'Antarctica', 'eltd-hotel' ),
			'AG' => esc_html__( 'Antigua and Barbuda', 'eltd-hotel' ),
			'AR' => esc_html__( 'Argentina', 'eltd-hotel' ),
			'AM' => esc_html__( 'Armenia', 'eltd-hotel' ),
			'AW' => esc_html__( 'Aruba', 'eltd-hotel' ),
			'AU' => esc_html__( 'Australia', 'eltd-hotel' ),
			'AT' => esc_html__( 'Austria', 'eltd-hotel' ),
			'AZ' => esc_html__( 'Azerbaijan', 'eltd-hotel' ),
			'BS' => esc_html__( 'Bahamas', 'eltd-hotel' ),
			'BH' => esc_html__( 'Bahrain', 'eltd-hotel' ),
			'BD' => esc_html__( 'Bangladesh', 'eltd-hotel' ),
			'BB' => esc_html__( 'Barbados', 'eltd-hotel' ),
			'BY' => esc_html__( 'Belarus', 'eltd-hotel' ),
			'BE' => esc_html__( 'Belgium', 'eltd-hotel' ),
			'PW' => esc_html__( 'Belau', 'eltd-hotel' ),
			'BZ' => esc_html__( 'Belize', 'eltd-hotel' ),
			'BJ' => esc_html__( 'Benin', 'eltd-hotel' ),
			'BM' => esc_html__( 'Bermuda', 'eltd-hotel' ),
			'BT' => esc_html__( 'Bhutan', 'eltd-hotel' ),
			'BO' => esc_html__( 'Bolivia', 'eltd-hotel' ),
			'BQ' => esc_html__( 'Bonaire, Saint Eustatius and Saba', 'eltd-hotel' ),
			'BA' => esc_html__( 'Bosnia and Herzegovina', 'eltd-hotel' ),
			'BW' => esc_html__( 'Botswana', 'eltd-hotel' ),
			'BV' => esc_html__( 'Bouvet Island', 'eltd-hotel' ),
			'BR' => esc_html__( 'Brazil', 'eltd-hotel' ),
			'IO' => esc_html__( 'British Indian Ocean Territory', 'eltd-hotel' ),
			'VG' => esc_html__( 'British Virgin Islands', 'eltd-hotel' ),
			'BN' => esc_html__( 'Brunei', 'eltd-hotel' ),
			'BG' => esc_html__( 'Bulgaria', 'eltd-hotel' ),
			'BF' => esc_html__( 'Burkina Faso', 'eltd-hotel' ),
			'BI' => esc_html__( 'Burundi', 'eltd-hotel' ),
			'KH' => esc_html__( 'Cambodia', 'eltd-hotel' ),
			'CM' => esc_html__( 'Cameroon', 'eltd-hotel' ),
			'CA' => esc_html__( 'Canada', 'eltd-hotel' ),
			'CV' => esc_html__( 'Cape Verde', 'eltd-hotel' ),
			'KY' => esc_html__( 'Cayman Islands', 'eltd-hotel' ),
			'CF' => esc_html__( 'Central African Republic', 'eltd-hotel' ),
			'TD' => esc_html__( 'Chad', 'eltd-hotel' ),
			'CL' => esc_html__( 'Chile', 'eltd-hotel' ),
			'CN' => esc_html__( 'China', 'eltd-hotel' ),
			'CX' => esc_html__( 'Christmas Island', 'eltd-hotel' ),
			'CC' => esc_html__( 'Cocos (Keeling) Islands', 'eltd-hotel' ),
			'CO' => esc_html__( 'Colombia', 'eltd-hotel' ),
			'KM' => esc_html__( 'Comoros', 'eltd-hotel' ),
			'CG' => esc_html__( 'Congo (Brazzaville)', 'eltd-hotel' ),
			'CD' => esc_html__( 'Congo (Kinshasa)', 'eltd-hotel' ),
			'CK' => esc_html__( 'Cook Islands', 'eltd-hotel' ),
			'CR' => esc_html__( 'Costa Rica', 'eltd-hotel' ),
			'HR' => esc_html__( 'Croatia', 'eltd-hotel' ),
			'CU' => esc_html__( 'Cuba', 'eltd-hotel' ),
			'CW' => esc_html__( 'Cura&ccedil;ao', 'eltd-hotel' ),
			'CY' => esc_html__( 'Cyprus', 'eltd-hotel' ),
			'CZ' => esc_html__( 'Czech Republic', 'eltd-hotel' ),
			'DK' => esc_html__( 'Denmark', 'eltd-hotel' ),
			'DJ' => esc_html__( 'Djibouti', 'eltd-hotel' ),
			'DM' => esc_html__( 'Dominica', 'eltd-hotel' ),
			'DO' => esc_html__( 'Dominican Republic', 'eltd-hotel' ),
			'EC' => esc_html__( 'Ecuador', 'eltd-hotel' ),
			'EG' => esc_html__( 'Egypt', 'eltd-hotel' ),
			'SV' => esc_html__( 'El Salvador', 'eltd-hotel' ),
			'GQ' => esc_html__( 'Equatorial Guinea', 'eltd-hotel' ),
			'ER' => esc_html__( 'Eritrea', 'eltd-hotel' ),
			'EE' => esc_html__( 'Estonia', 'eltd-hotel' ),
			'ET' => esc_html__( 'Ethiopia', 'eltd-hotel' ),
			'FK' => esc_html__( 'Falkland Islands', 'eltd-hotel' ),
			'FO' => esc_html__( 'Faroe Islands', 'eltd-hotel' ),
			'FJ' => esc_html__( 'Fiji', 'eltd-hotel' ),
			'FI' => esc_html__( 'Finland', 'eltd-hotel' ),
			'FR' => esc_html__( 'France', 'eltd-hotel' ),
			'GF' => esc_html__( 'French Guiana', 'eltd-hotel' ),
			'PF' => esc_html__( 'French Polynesia', 'eltd-hotel' ),
			'TF' => esc_html__( 'French Southern Territories', 'eltd-hotel' ),
			'GA' => esc_html__( 'Gabon', 'eltd-hotel' ),
			'GM' => esc_html__( 'Gambia', 'eltd-hotel' ),
			'GE' => esc_html__( 'Georgia', 'eltd-hotel' ),
			'DE' => esc_html__( 'Germany', 'eltd-hotel' ),
			'GH' => esc_html__( 'Ghana', 'eltd-hotel' ),
			'GI' => esc_html__( 'Gibraltar', 'eltd-hotel' ),
			'GR' => esc_html__( 'Greece', 'eltd-hotel' ),
			'GL' => esc_html__( 'Greenland', 'eltd-hotel' ),
			'GD' => esc_html__( 'Grenada', 'eltd-hotel' ),
			'GP' => esc_html__( 'Guadeloupe', 'eltd-hotel' ),
			'GU' => esc_html__( 'Guam', 'eltd-hotel' ),
			'GT' => esc_html__( 'Guatemala', 'eltd-hotel' ),
			'GG' => esc_html__( 'Guernsey', 'eltd-hotel' ),
			'GN' => esc_html__( 'Guinea', 'eltd-hotel' ),
			'GW' => esc_html__( 'Guinea-Bissau', 'eltd-hotel' ),
			'GY' => esc_html__( 'Guyana', 'eltd-hotel' ),
			'HT' => esc_html__( 'Haiti', 'eltd-hotel' ),
			'HM' => esc_html__( 'Heard Island and McDonald Islands', 'eltd-hotel' ),
			'HN' => esc_html__( 'Honduras', 'eltd-hotel' ),
			'HK' => esc_html__( 'Hong Kong', 'eltd-hotel' ),
			'HU' => esc_html__( 'Hungary', 'eltd-hotel' ),
			'IS' => esc_html__( 'Iceland', 'eltd-hotel' ),
			'IN' => esc_html__( 'India', 'eltd-hotel' ),
			'ID' => esc_html__( 'Indonesia', 'eltd-hotel' ),
			'IR' => esc_html__( 'Iran', 'eltd-hotel' ),
			'IQ' => esc_html__( 'Iraq', 'eltd-hotel' ),
			'IE' => esc_html__( 'Ireland', 'eltd-hotel' ),
			'IM' => esc_html__( 'Isle of Man', 'eltd-hotel' ),
			'IL' => esc_html__( 'Israel', 'eltd-hotel' ),
			'IT' => esc_html__( 'Italy', 'eltd-hotel' ),
			'CI' => esc_html__( 'Ivory Coast', 'eltd-hotel' ),
			'JM' => esc_html__( 'Jamaica', 'eltd-hotel' ),
			'JP' => esc_html__( 'Japan', 'eltd-hotel' ),
			'JE' => esc_html__( 'Jersey', 'eltd-hotel' ),
			'JO' => esc_html__( 'Jordan', 'eltd-hotel' ),
			'KZ' => esc_html__( 'Kazakhstan', 'eltd-hotel' ),
			'KE' => esc_html__( 'Kenya', 'eltd-hotel' ),
			'KI' => esc_html__( 'Kiribati', 'eltd-hotel' ),
			'KW' => esc_html__( 'Kuwait', 'eltd-hotel' ),
			'KG' => esc_html__( 'Kyrgyzstan', 'eltd-hotel' ),
			'LA' => esc_html__( 'Laos', 'eltd-hotel' ),
			'LV' => esc_html__( 'Latvia', 'eltd-hotel' ),
			'LB' => esc_html__( 'Lebanon', 'eltd-hotel' ),
			'LS' => esc_html__( 'Lesotho', 'eltd-hotel' ),
			'LR' => esc_html__( 'Liberia', 'eltd-hotel' ),
			'LY' => esc_html__( 'Libya', 'eltd-hotel' ),
			'LI' => esc_html__( 'Liechtenstein', 'eltd-hotel' ),
			'LT' => esc_html__( 'Lithuania', 'eltd-hotel' ),
			'LU' => esc_html__( 'Luxembourg', 'eltd-hotel' ),
			'MO' => esc_html__( 'Macao S.A.R., China', 'eltd-hotel' ),
			'MK' => esc_html__( 'Macedonia', 'eltd-hotel' ),
			'MG' => esc_html__( 'Madagascar', 'eltd-hotel' ),
			'MW' => esc_html__( 'Malawi', 'eltd-hotel' ),
			'MY' => esc_html__( 'Malaysia', 'eltd-hotel' ),
			'MV' => esc_html__( 'Maldives', 'eltd-hotel' ),
			'ML' => esc_html__( 'Mali', 'eltd-hotel' ),
			'MT' => esc_html__( 'Malta', 'eltd-hotel' ),
			'MH' => esc_html__( 'Marshall Islands', 'eltd-hotel' ),
			'MQ' => esc_html__( 'Martinique', 'eltd-hotel' ),
			'MR' => esc_html__( 'Mauritania', 'eltd-hotel' ),
			'MU' => esc_html__( 'Mauritius', 'eltd-hotel' ),
			'YT' => esc_html__( 'Mayotte', 'eltd-hotel' ),
			'MX' => esc_html__( 'Mexico', 'eltd-hotel' ),
			'FM' => esc_html__( 'Micronesia', 'eltd-hotel' ),
			'MD' => esc_html__( 'Moldova', 'eltd-hotel' ),
			'MC' => esc_html__( 'Monaco', 'eltd-hotel' ),
			'MN' => esc_html__( 'Mongolia', 'eltd-hotel' ),
			'ME' => esc_html__( 'Montenegro', 'eltd-hotel' ),
			'MS' => esc_html__( 'Montserrat', 'eltd-hotel' ),
			'MA' => esc_html__( 'Morocco', 'eltd-hotel' ),
			'MZ' => esc_html__( 'Mozambique', 'eltd-hotel' ),
			'MM' => esc_html__( 'Myanmar', 'eltd-hotel' ),
			'NA' => esc_html__( 'Namibia', 'eltd-hotel' ),
			'NR' => esc_html__( 'Nauru', 'eltd-hotel' ),
			'NP' => esc_html__( 'Nepal', 'eltd-hotel' ),
			'NL' => esc_html__( 'Netherlands', 'eltd-hotel' ),
			'NC' => esc_html__( 'New Caledonia', 'eltd-hotel' ),
			'NZ' => esc_html__( 'New Zealand', 'eltd-hotel' ),
			'NI' => esc_html__( 'Nicaragua', 'eltd-hotel' ),
			'NE' => esc_html__( 'Niger', 'eltd-hotel' ),
			'NG' => esc_html__( 'Nigeria', 'eltd-hotel' ),
			'NU' => esc_html__( 'Niue', 'eltd-hotel' ),
			'NF' => esc_html__( 'Norfolk Island', 'eltd-hotel' ),
			'MP' => esc_html__( 'Northern Mariana Islands', 'eltd-hotel' ),
			'KP' => esc_html__( 'North Korea', 'eltd-hotel' ),
			'NO' => esc_html__( 'Norway', 'eltd-hotel' ),
			'OM' => esc_html__( 'Oman', 'eltd-hotel' ),
			'PK' => esc_html__( 'Pakistan', 'eltd-hotel' ),
			'PS' => esc_html__( 'Palestinian Territory', 'eltd-hotel' ),
			'PA' => esc_html__( 'Panama', 'eltd-hotel' ),
			'PG' => esc_html__( 'Papua New Guinea', 'eltd-hotel' ),
			'PY' => esc_html__( 'Paraguay', 'eltd-hotel' ),
			'PE' => esc_html__( 'Peru', 'eltd-hotel' ),
			'PH' => esc_html__( 'Philippines', 'eltd-hotel' ),
			'PN' => esc_html__( 'Pitcairn', 'eltd-hotel' ),
			'PL' => esc_html__( 'Poland', 'eltd-hotel' ),
			'PT' => esc_html__( 'Portugal', 'eltd-hotel' ),
			'PR' => esc_html__( 'Puerto Rico', 'eltd-hotel' ),
			'QA' => esc_html__( 'Qatar', 'eltd-hotel' ),
			'RE' => esc_html__( 'Reunion', 'eltd-hotel' ),
			'RO' => esc_html__( 'Romania', 'eltd-hotel' ),
			'RU' => esc_html__( 'Russia', 'eltd-hotel' ),
			'RW' => esc_html__( 'Rwanda', 'eltd-hotel' ),
			'BL' => esc_html__( 'Saint Barth&eacute;lemy', 'eltd-hotel' ),
			'SH' => esc_html__( 'Saint Helena', 'eltd-hotel' ),
			'KN' => esc_html__( 'Saint Kitts and Nevis', 'eltd-hotel' ),
			'LC' => esc_html__( 'Saint Lucia', 'eltd-hotel' ),
			'MF' => esc_html__( 'Saint Martin (French part)', 'eltd-hotel' ),
			'SX' => esc_html__( 'Saint Martin (Dutch part)', 'eltd-hotel' ),
			'PM' => esc_html__( 'Saint Pierre and Miquelon', 'eltd-hotel' ),
			'VC' => esc_html__( 'Saint Vincent and the Grenadines', 'eltd-hotel' ),
			'SM' => esc_html__( 'San Marino', 'eltd-hotel' ),
			'ST' => esc_html__( 'S&atilde;o Tom&eacute; and Pr&iacute;ncipe', 'eltd-hotel' ),
			'SA' => esc_html__( 'Saudi Arabia', 'eltd-hotel' ),
			'SN' => esc_html__( 'Senegal', 'eltd-hotel' ),
			'RS' => esc_html__( 'Serbia', 'eltd-hotel' ),
			'SC' => esc_html__( 'Seychelles', 'eltd-hotel' ),
			'SL' => esc_html__( 'Sierra Leone', 'eltd-hotel' ),
			'SG' => esc_html__( 'Singapore', 'eltd-hotel' ),
			'SK' => esc_html__( 'Slovakia', 'eltd-hotel' ),
			'SI' => esc_html__( 'Slovenia', 'eltd-hotel' ),
			'SB' => esc_html__( 'Solomon Islands', 'eltd-hotel' ),
			'SO' => esc_html__( 'Somalia', 'eltd-hotel' ),
			'ZA' => esc_html__( 'South Africa', 'eltd-hotel' ),
			'GS' => esc_html__( 'South Georgia/Sandwich Islands', 'eltd-hotel' ),
			'KR' => esc_html__( 'South Korea', 'eltd-hotel' ),
			'SS' => esc_html__( 'South Sudan', 'eltd-hotel' ),
			'ES' => esc_html__( 'Spain', 'eltd-hotel' ),
			'LK' => esc_html__( 'Sri Lanka', 'eltd-hotel' ),
			'SD' => esc_html__( 'Sudan', 'eltd-hotel' ),
			'SR' => esc_html__( 'Suriname', 'eltd-hotel' ),
			'SJ' => esc_html__( 'Svalbard and Jan Mayen', 'eltd-hotel' ),
			'SZ' => esc_html__( 'Swaziland', 'eltd-hotel' ),
			'SE' => esc_html__( 'Sweden', 'eltd-hotel' ),
			'CH' => esc_html__( 'Switzerland', 'eltd-hotel' ),
			'SY' => esc_html__( 'Syria', 'eltd-hotel' ),
			'TW' => esc_html__( 'Taiwan', 'eltd-hotel' ),
			'TJ' => esc_html__( 'Tajikistan', 'eltd-hotel' ),
			'TZ' => esc_html__( 'Tanzania', 'eltd-hotel' ),
			'TH' => esc_html__( 'Thailand', 'eltd-hotel' ),
			'TL' => esc_html__( 'Timor-Leste', 'eltd-hotel' ),
			'TG' => esc_html__( 'Togo', 'eltd-hotel' ),
			'TK' => esc_html__( 'Tokelau', 'eltd-hotel' ),
			'TO' => esc_html__( 'Tonga', 'eltd-hotel' ),
			'TT' => esc_html__( 'Trinidad and Tobago', 'eltd-hotel' ),
			'TN' => esc_html__( 'Tunisia', 'eltd-hotel' ),
			'TR' => esc_html__( 'Turkey', 'eltd-hotel' ),
			'TM' => esc_html__( 'Turkmenistan', 'eltd-hotel' ),
			'TC' => esc_html__( 'Turks and Caicos Islands', 'eltd-hotel' ),
			'TV' => esc_html__( 'Tuvalu', 'eltd-hotel' ),
			'UG' => esc_html__( 'Uganda', 'eltd-hotel' ),
			'UA' => esc_html__( 'Ukraine', 'eltd-hotel' ),
			'AE' => esc_html__( 'United Arab Emirates', 'eltd-hotel' ),
			'GB' => esc_html__( 'United Kingdom (UK)', 'eltd-hotel' ),
			'US' => esc_html__( 'United States (US)', 'eltd-hotel' ),
			'UM' => esc_html__( 'United States (US) Minor Outlying Islands', 'eltd-hotel' ),
			'VI' => esc_html__( 'United States (US) Virgin Islands', 'eltd-hotel' ),
			'UY' => esc_html__( 'Uruguay', 'eltd-hotel' ),
			'UZ' => esc_html__( 'Uzbekistan', 'eltd-hotel' ),
			'VU' => esc_html__( 'Vanuatu', 'eltd-hotel' ),
			'VA' => esc_html__( 'Vatican', 'eltd-hotel' ),
			'VE' => esc_html__( 'Venezuela', 'eltd-hotel' ),
			'VN' => esc_html__( 'Vietnam', 'eltd-hotel' ),
			'WF' => esc_html__( 'Wallis and Futuna', 'eltd-hotel' ),
			'EH' => esc_html__( 'Western Sahara', 'eltd-hotel' ),
			'WS' => esc_html__( 'Samoa', 'eltd-hotel' ),
			'YE' => esc_html__( 'Yemen', 'eltd-hotel' ),
			'ZM' => esc_html__( 'Zambia', 'eltd-hotel' ),
			'ZW' => esc_html__( 'Zimbabwe', 'eltd-hotel' )
		);

		return $countries;
	}
}



