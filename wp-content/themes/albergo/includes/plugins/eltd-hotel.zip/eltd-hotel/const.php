<?php

define('ELTD_HOTEL_VERSION', '1.0.3');
define('ELTD_HOTEL_ABS_PATH', dirname(__FILE__));
define('ELTD_HOTEL_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('ELTD_HOTEL_URL_PATH', plugin_dir_url( __FILE__ ));
define('ELTD_HOTEL_CPT_PATH', ELTD_HOTEL_ABS_PATH.'/post-types');
define('ELTD_HOTEL_SHORTCODES_PATH', ELTD_HOTEL_ABS_PATH.'/modules/shortcodes');
define('ELTD_HOTEL_ASSETS_URL_PATH', ELTD_HOTEL_URL_PATH.'assets');
define('ELTD_HOTEL_MODULE_PATH', ELTD_HOTEL_ABS_PATH.'/modules');
define('ELTD_HOTEL_CPT_URL_PATH', ELTD_HOTEL_URL_PATH.'post-types');