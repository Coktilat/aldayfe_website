<?php

require_once 'database-table-setup.php';
require_once 'review-ratings-table-setup.php';
require_once 'tables-setup.php';