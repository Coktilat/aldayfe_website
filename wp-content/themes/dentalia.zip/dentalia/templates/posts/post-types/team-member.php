<?php get_template_part( 'templates/parts/team', 'part_excerpt' ); ?>
	<div class="entry-content">
		<?php the_content(); ?>	
	</div>
