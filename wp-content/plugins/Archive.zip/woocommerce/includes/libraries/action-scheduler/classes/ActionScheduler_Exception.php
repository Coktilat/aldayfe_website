<?php

/**
 * ActionScheduler Exception Interface.
 *
 * Facilitates catching Exceptions unique to Action Scheduler.
 *
 * @package Prospress\ActionScheduler
 * @since %VERSION%
 */
interface ActionScheduler_Exception {}
